<?php

class ControladorInicio{

    static public function ctrReportes(){
      $tabla = "registros";
      $datos = ModeloInicio::mdlReportes($tabla);

      return $datos;
    }

    static public function ctrMostrarDispositivosAsignados($sede){
        $tabla = "dispositivos";
        $datos = ModeloInicio::mdlMostrarDispositivosAsignados($sede, $tabla);

        return $datos;
    }

    static public function ctrCantidadAccesoriosAsignados($sede){
      $tabla = "dispositivos";

      $datos = ModeloInicio::mdlCantidadAccesoriosAsignados($sede, $tabla);
      return $datos;
    }

    /* Mostrar dispositivos por departamento */
    static public function ctrMostrarDispositivosDepartamento(){
      $tabla = "dispositivos";
      $datos = ModeloInicio::mdlMostrarDispositivosDepartamento($tabla);

      return $datos;
    }

    /* Mostrar dispositivos por departamento */
    static public function ctrMostrarDispositivosRegion(){
      $tabla = "dispositivos";
      $datos = ModeloInicio::mdlMostrarDispositivosRegion($tabla);

      return $datos;
    }

    /* Mostrar dispositivos por sede */
    static public function ctrMostrarDispositivosSede($item, $valor){
      $tabla = "dispositivos";
      $datos = ModeloInicio::mdlMostrarDispositivosSede($tabla, $item, $valor);

      return $datos;
    }

    /* Gráfico de líneas */
    static public function ctrMostrarGraficoLineas($sede){
      $tabla = "dispositivos";

      $respuesta = ModeloInicio::mdlMostrarGraficoLineas($sede, $tabla);
      return $respuesta;
    }

    /* Gráfico de barras */
    static public function ctrMostrarGraficoBarras($sede){
      $tabla = "dispositivos";

      $respuesta = ModeloInicio::mdlMostrarGraficoBarras($sede, $tabla);
      return $respuesta;
    }

    /* Gráfico de donas */
    static public function ctrMostrarGraficoDonas(){
      $tabla = "dispositivos";

      $respuesta = ModeloInicio::mdlMostrarGraficoDonas($tabla);
      return $respuesta;
    }

    static public function ctrMostrarUltimosMovimientos($item, $valor, $sede){
      $tabla = "registros";

      $respuesta = ModeloInicio::mdlMostrarUltimosMovimientos($tabla, $item, $valor, $sede);
      return $respuesta;
    }

}
