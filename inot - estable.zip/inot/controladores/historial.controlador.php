<?php

class ControladorHistorial{

  static public function ctrMostrarHistorial($imei, $serie, $inventario){
    $tabla = "registros";

    $resultado = ModeloHistorial::mdlMostrarHistorial($tabla, $imei, $serie, $inventario);
    return $resultado;
  }

}
