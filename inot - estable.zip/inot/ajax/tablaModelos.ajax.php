<?php
 
require_once "../controladores/administradores.controlador.php";
require_once "../modelos/administradores.modelo.php";

class TablaAdministradores{

    public function mostrarAdministradores(){

        $item = null;
        $valor = null;
        $modelos = ControladorAdministradores::ctrMostrarModelos(null, null);

        echo json_encode(array("data"=>$modelos));
    }

}


$activar = new TablaAdministradores();
$activar->mostrarAdministradores();
