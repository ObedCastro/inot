<?php

require_once "../controladores/dispositivos.controlador.php";
require_once "../controladores/inicio.controlador.php";

require_once "../modelos/dispositivos.modelo.php";
require_once "../modelos/inicio.modelo.php";


class AjaxDispositivos{

    public $idDispositivo;
    public function ajaxMostrarDispositivo(){
        $item = "iddispositivo";
        $valor = $this->idDispositivo;

        $respuesta = ControladorDispositivos::ctrMostrarDispositivos($item, $valor);
        $ultimosMovimientos = ControladorInicio::ctrMostrarUltimosMovimientos("dispositivo_id", $valor, null);

        echo json_encode(array($respuesta, $ultimosMovimientos));
    }

    public $idDispositivoRecuperar;
    public function ajaxMostrarDispositivoRecuperar(){
        $item = "iddispositivo";
        $consultor = $_POST["consultorResposable"];
        $valor = $this->idDispositivoRecuperar;

        $respuesta = ControladorDispositivos::ctrMostrarDispositivoRecuperar($item, $valor, $consultor);
        echo json_encode($respuesta);
    }

    //REGISTRA UN NUEVO DISPOSITIVO
    public function ajaxRegistrarNuevoDispositivo(){
        
        if(isset($_POST["tipoDispositivo"]) && !empty($_POST["tipoDispositivo"]) && 
           isset($_POST["marcaDispositivo"]) && !empty($_POST["marcaDispositivo"]) && 
           isset($_POST["modeloDispositivo"]) && !empty($_POST["modeloDispositivo"])){

                $imei = empty($_POST["imeiDispositivo"]) ? null : $_POST["imeiDispositivo"];
                $inventario = empty($_POST["inventarioDispositivo"]) ? null : $_POST["inventarioDispositivo"];
                $hostname = empty($_POST["hostnameDispositivo"]) ? null : $_POST["hostnameDispositivo"];
                $telefono = empty($_POST["telefonoDispositivo"]) ? null : $_POST["telefonoDispositivo"];
                $caja = empty($_POST["cajaDispositivo"]) ? null : $_POST["cajaDispositivo"];
                $correlativo = empty($_POST["correlativoDispositivo"]) ? null : $_POST["correlativoDispositivo"];
                
                $datos = array(
                    "tipo"=>$_POST["tipoDispositivo"],
                    "marca"=>$_POST["marcaDispositivo"],
                    "modelo"=>$_POST["modeloDispositivo"],
                    "imei"=>$imei,
                    "serie"=>$_POST["serieDispositivo"],
                    "inventario"=>$inventario,
                    "hostname"=>$hostname,
                    "caja"=>$caja,
                    "correlativo"=>$correlativo,
                    "telefono"=>$telefono,
                    "sede"=>$_POST["sedeDispositivo"],
                    "fecha"=>$_POST["fechaRegistro"]
                );

            /* if($_POST["tipoDispositivo"] != "Laptop"){
                $datos = array(
                    "tipo"=>$_POST["tipoDispositivo"],
                    "marca"=>$_POST["marcaDispositivo"],
                    "modelo"=>$_POST["modeloDispositivo"],
                    "imei"=>$_POST["imeiDispositivo"],
                    "serie"=>$_POST["serieDispositivo"],
                    "telefono"=>$_POST["telefonoDispositivo"],
                    "sede"=>$_POST["sedeDispositivo"],
                    "fecha"=>$_POST["fechaRegistro"]
                );                
            }else{
                $datos = array(
                    "tipo"=>$_POST["tipoDispositivo"],
                    "marca"=>$_POST["marcaDispositivo"],
                    "modelo"=>$_POST["modeloDispositivo"],
                    "serie"=>$_POST["serieDispositivo"],
                    "sede"=>$_POST["sedeDispositivo"],
                    "fecha"=>$_POST["fechaRegistro"]
                ); 
            } */

            $accesorios = array(
                "Cubo"=>"0",
                "Cable"=>"0",
                "Funda"=>"0",
                "Lapiz"=>"0",
                "Powerbank"=>"0",
                "Maletin"=>"0",
                "Cargador"=>"0",
                "Mouse"=>"0",
                "Mousepad"=>"0"
            );


            $respuesta = ControladorDispositivos::ctrRegistrarDispositivo($datos, $accesorios);
            echo json_encode($respuesta);  
        }
        
    }

    //MUESTRA LA INFORMACIÓN DEL DISPOSITIVO, ANTES DE MODIFICARLO
    public $idEditarDispositivo;
    public function ajaxEditarDispositivo(){
        $item = "iddispositivo";
        $valor = $this->idEditarDispositivo;

        $respuesta = ControladorDispositivos::ctrMostrarDispositivos($item, $valor);
        echo json_encode($respuesta);
    }

    //MODIFICA LA INFORMACIÓN DEL DISPOSITIVO
    public $idDispositivoModificar;
    public function ajaxModificarInfoDispositivo(){
        $item = "iddispositivo";
        $valor = $this->idDispositivoModificar;

        if(isset($_POST["editarTipoDispositivo"]) && !empty($_POST["editarTipoDispositivo"]) && 
           isset($_POST["editarMarcaDispositivo"]) && !empty($_POST["editarMarcaDispositivo"]) && 
           isset($_POST["editarModeloDispositivo"]) && !empty($_POST["editarModeloDispositivo"]) && 
           isset($_POST["editarSerieDispositivo"]) && !empty($_POST["editarSerieDispositivo"]) && 
           isset($_POST["editarSedeDispositivo"]) && !empty($_POST["editarSedeDispositivo"])){
            
            /* if($_POST["editarTipoDispositivo"] == "Teléfono" || $_POST["editarTipoDispositivo"] == "Tablet" || $_POST["editarTipoDispositivo"] == "Laptop" || $_POST["editarTipoDispositivo"] == "Proyector" || $_POST["editarTipoDispositivo"] == "Impresora"){ */

                $imei = empty($_POST["editarImeiDispositivo"]) ? null : $_POST["editarImeiDispositivo"];
                $inventario = empty($_POST["editarInventarioDispositivo"]) ? null : $_POST["editarInventarioDispositivo"];
                $hostname = empty($_POST["editarHostnameDispositivo"]) ? null : $_POST["editarHostnameDispositivo"];
                
                $accesorios = json_encode(array(
                    "Cubo"=> isset($_POST["Cubo"]) && !empty($_POST["Cubo"]) ? "1" : "0",
                    "Cable"=>isset($_POST["Cable"]) && !empty($_POST["Cable"]) ? "1" : "0",
                    "Funda"=>isset($_POST["Funda"]) && !empty($_POST["Funda"]) ? "1" : "0",
                    "Lapiz"=>isset($_POST["Lapiz"]) && !empty($_POST["Lapiz"]) ? "1" : "0",
                    "Powerbank"=>isset($_POST["Powerbank"]) && !empty($_POST["Powerbank"]) ? "1" : "0",
                    "Maletin"=>isset($_POST["Maletin"]) && !empty($_POST["Maletin"]) ? "1" : "0",
                    "Cargador"=>isset($_POST["Cargador"]) && !empty($_POST["Cargador"]) ? "1" : "0",
                    "Mouse"=>isset($_POST["Mouse"]) && !empty($_POST["Mouse"]) ? "1" : "0",
                    "Mousepad"=>isset($_POST["Mousepad"]) && !empty($_POST["Mousepad"]) ? "1" : "0"
                ));

                $dispositivo = ControladorDispositivos::ctrMostrarDispositivos($item, $valor);
                if($dispositivo["estadodispositivo"] != '2'){
                    $datos = array(
                        "tipo"=>$_POST["editarTipoDispositivo"],
                        "marca"=>$_POST["editarMarcaDispositivo"],
                        "modelo"=>$_POST["editarModeloDispositivo"],
                        "imei"=>$imei,
                        "serie"=>$_POST["editarSerieDispositivo"],
                        "inventario"=>$inventario,
                        "hostname"=>$hostname,
                        "caja"=>$_POST["editarCajaDispositivo"],
                        "correlativo"=>$_POST["editarCorrelativoDispositivo"],
                        "telefono"=>$_POST["editarTelefonoDispositivo"],
                        "sede"=>$_POST["editarSedeDispositivo"],
                        "comentario"=>$_POST["comentarioDispositivo"]
                    );
                } else{
                    $datos = array(
                        "tipo"=>$_POST["editarTipoDispositivo"],
                        "marca"=>$_POST["editarMarcaDispositivo"],
                        "modelo"=>$_POST["editarModeloDispositivo"],
                        "imei"=>$imei,
                        "serie"=>$_POST["editarSerieDispositivo"],
                        "inventario"=>$inventario,
                        "hostname"=>$hostname,
                        "accesorios"=>$accesorios,
                        "caja"=>$_POST["editarCajaDispositivo"],
                        "correlativo"=>$_POST["editarCorrelativoDispositivo"],
                        "telefono"=>$_POST["editarTelefonoDispositivo"],
                        "sede"=>$_POST["editarSedeDispositivo"],
                        "comentario"=>$_POST["comentarioDispositivo"]
                    );
                }
                
            /* } */

            $respuesta = ControladorDispositivos::ctrModificarDispositivo($item, $valor, $datos);
            echo json_encode($respuesta);
        }

    }

    public $idEstadoDispositivo;
    public function cambiarEstadoDispositivoAI(){
        $item = "iddispositivo";
        $valor = $_POST["id"];

        if(isset($_POST["estado"]) && !empty($_POST["estado"])){
            $dato = $_POST["estado"];

            // SUBIR IMAGEN
            if($_SERVER['REQUEST_METHOD'] === 'POST') {
                if(isset($_FILES['image']) && $_FILES['image']['error'] === 0 && isset($_POST['description'])) {
                    $description = $_POST['description'];  
                    $uploadDirectory = $_SERVER['DOCUMENT_ROOT']."/inot/vistas/assets/img/cambioestados/";
    
                    if(!file_exists($uploadDirectory)) {
                        mkdir($uploadDirectory, 0777, true);
                    }
    
                    $fileName = basename($_FILES['image']['name']);
                    $filePath = $uploadDirectory . $fileName;
    
                    // Mover la imagen a la carpeta de destino
                    if(move_uploaded_file($_FILES['image']['tmp_name'], $filePath)) {
    
                        $rutaguardar = "vistas/assets/img/cambioestados/".$fileName;
                        $respuesta = ControladorDispositivos::ctrCambiarEstadoDispositivoAI($dato, $description, $rutaguardar, $item, $valor);
                        echo json_encode($respuesta);
                    } 
                } else{
                    $respuesta = ControladorDispositivos::ctrCambiarEstadoDispositivoAI($dato, $description, null, $item, $valor);
                    echo json_encode($respuesta);
                }
            }

        }

    }

    public $idEliminarDispositivo;
    public function eliminarDispositivo(){
        $item = "iddispositivo";
        $valor = $this->idEliminarDispositivo;

        $respuesta = ControladorDispositivos::ctrEliminarDispositivo($item, $valor);

        echo json_encode($respuesta);
    }

}


//Comprobando si se ha recibido el valor id, pasarlo en la variable y ejecutar el metodo
if(isset($_POST["idDispositivo"])){
    $mostrar = new AjaxDispositivos();
    $mostrar->idDispositivo = $_POST["idDispositivo"];
    $mostrar->ajaxMostrarDispositivo();
}

//PARA MOSTRAR LA INFORMACION DEL DISPOSITIVO A RECUPERAR
if(isset($_POST["idDispositivoRecuperar"])){
    $recuperar = new AjaxDispositivos();
    $recuperar->idDispositivoRecuperar = $_POST["idDispositivoRecuperar"];
    $recuperar->ajaxMostrarDispositivoRecuperar();
}

//PARA REGISTRAR NUEVO DISPOSITIVO
if(isset($_POST["nuevo"])){
    $registrar = new AjaxDispositivos();
    $registrar->ajaxRegistrarNuevoDispositivo();
}

//MUESTRA LA INFORMACIÓN DEL DISPOSITIVO ANTES DE MODIFICARLA
if(isset($_POST["idEditarDispositivo"])){
    $editar = new AjaxDispositivos();
    $editar->idEditarDispositivo = $_POST["idEditarDispositivo"];
    $editar->ajaxEditarDispositivo();
}

//MODIFICA LA INFORMACIÓN DEL DISPOSITIVO
if(isset($_POST["idEditarDispositivo_"])){
    $modificar = new AjaxDispositivos();
    $modificar->idDispositivoModificar = $_POST["idEditarDispositivo_"];
    $modificar->ajaxModificarInfoDispositivo();
}

/* CAMBIAR ESTADO DE DISPOSITIVO (ACTIVO - INACTIVO) */
/* if(isset($_POST["idEstadoDispositivo"])){
    $mestado = new AjaxDispositivos();
    $mestado->idEstadoDispositivo = $_POST["idEstadoDispositivo"];
    $mestado->cambiarEstadoDispositivoAI();
} */

//PARA ELIMINAR DISPOSITIVO
if(isset($_POST["idEliminarDispositivo"])){
    $eliminar = new AjaxDispositivos();
    $eliminar->idEliminarDispositivo = $_POST["idEliminarDispositivo"];
    $eliminar->eliminarDispositivo();
}








if(isset($_POST["description"])){
    $mestado = new AjaxDispositivos();
    $mestado->cambiarEstadoDispositivoAI();
}
