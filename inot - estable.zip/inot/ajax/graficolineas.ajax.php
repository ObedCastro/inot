<?php

session_start();

require_once "../controladores/inicio.controlador.php";
require_once "../modelos/inicio.modelo.php";

class AjaxGraficoLineas{

  public function ajaxMostrarGraficoLineas(){

    if(isset($_POST["url"]) && $_POST["url"] == "inicio-sede"){
      $sede = $_SESSION["sedeasignada"];
    } else{
      $sede = "";
    }

    $resultado = ControladorInicio::ctrMostrarGraficoLineas($sede);

    echo json_encode($resultado);
  }

}



$mostrarGraficoLineas = new AjaxGraficoLineas();
$mostrarGraficoLineas->ajaxMostrarGraficoLineas();
