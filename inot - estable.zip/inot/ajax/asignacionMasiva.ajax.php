<?php

require_once "../modelos/conexion.php";

class AsignacionMasiva{

    public function asignar(){

        if(isset($_FILES["file"]) && $_FILES["file"]["error"] == 0){ 
            $csvFile = $_FILES["file"]["tmp_name"];
            $csvName = $_FILES["file"]["name"];
            $extension = pathinfo($csvName, PATHINFO_EXTENSION);

            if ($extension !== 'csv') {
                echo json_encode("El archivo debe ser de tipo .csv");
                return;
            }

            $totalLineas = count(file($csvFile))-1;
            $asignados = 0;
            $noAsignados = [];

            $sql = "UPDATE dispositivos SET estadodispositivo = ?, responsabledispositivo = ?, asignadordispositivo = ?, fechaasignacion = STR_TO_DATE(?, '%d/%m/%Y %H:%i:%s'), accesorios = ? WHERE imeidispositivo = ? AND sededispositivo = ?";
 
            $stmt = Conexion::conectar()->prepare($sql);

            if(($handle = fopen($csvFile, "r")) !== false){

                fgetcsv($handle, 1000, ";"); // Lee y descarta la primera línea (cabecera)

                $lineNumber = 2; 
                while(($data = fgetcsv($handle, 1000, ";")) !== false){

                    if(!isset($data[0]) || !isset($data[1]) || !isset($data[7]) || !isset($data[8])){
                        $lineNumber++;
                        continue;
                    }

                    if(empty($data[0]) || empty($data[1]) || empty($data[7]) || empty($data[8])){
                        $noAsignados[] = 'El registro en la línea : '.$lineNumber.' no está completo y no se ha cargado.';
                        $lineNumber++;
                        continue;
                    }

                    $cubo = ($data[2] == "0" || $data[2] == "1") ? $data[2] : '0';  
                    $cable = ($data[3] == "0" || $data[3] == "1") ? $data[3] : '0';  
                    $funda = ($data[4] == "0" || $data[4] == "1") ? $data[4] : '0';  
                    $lapiz = ($data[5] == "0" || $data[5] == "1") ? $data[5] : '0';  
                    $powerbank = ($data[6] == "0" || $data[6] == "1") ? $data[6] : '0';  

                    $accesorios = json_encode(array("Cubo" => "$cubo", "Cable" => "$cable", "Funda" => "$funda", "Lapiz" => $lapiz, "Powerbank" => "$powerbank", "Maletin" => "0", "Cargador" => "0", "Mouse" => "0", "Mousepad" => "0"));

                    /* Comprobar si el usuario a quien se desea asignar, existe en la base de datos */
                    $buscarResponsable = Conexion::conectar()->prepare("SELECT idconsultor, sedeconsultor FROM consultores WHERE duiconsultor = ?");
                    $buscarResponsable->execute([$data[0]]);
                    $responsable = $buscarResponsable->fetch();

                    if (!$responsable) {
                        $noAsignados[] = 'No se encontró el CARNET: ' . $data[0] . ', Línea: ' . $lineNumber;
                        $lineNumber++;
                        continue;
                    }
                    
                    /* Comprobar si el dispositivo y el consultor, pertenecen a la misma sede */
                    $buscarSedeDispositivo = Conexion::conectar()->prepare("SELECT sededispositivo FROM dispositivos WHERE imeidispositivo = ?");
                    $buscarSedeDispositivo->execute([$data[1]]);
                    $sedeDispositivo = $buscarSedeDispositivo->fetchColumn();

                    if (!empty($sedeDispositivo) && $sedeDispositivo != $responsable["sedeconsultor"]) {
                        $noAsignados[] = 'El dispositivo '.(string)$data[1].', Linea: '.$lineNumber.', debe pertenecer a la misma sede que el consultor.';
                        $lineNumber++;
                        continue;
                    } else if(empty($sedeDispositivo)){
                        $noAsignados[] = 'No se encontró el dispositivo '.(string)$data[1].', Linea: '.$lineNumber;
                        $lineNumber++;
                        continue;
                    }

                    /* Obtener el TI que realiza la asignación */
                    $buscarAsignador = Conexion::conectar()->prepare("SELECT nombre FROM administradores WHERE usuario = ?");
                    $buscarAsignador->execute([$data[8]]);
                    $asignador = $buscarAsignador->fetchColumn();

                    if(empty($asignador)){
                        $noAsignados[] = 'No se encontró el usuario TI '.$data[8].', Linea: '.$lineNumber;
                        $lineNumber++;
                        continue;
                    }

                    /* Comprobar si un dispositivo ya se encuentra asignado */
                    $stmt_check = Conexion::conectar()->prepare("SELECT COUNT(*) FROM dispositivos WHERE imeidispositivo = ? AND estadodispositivo = ?");
                    $stmt_check->execute([(string)$data[1], '2']);
                    $tieneasignacion = $stmt_check->fetchColumn() > 0;

                    if ($tieneasignacion) {
                        $noAsignados[] = 'IMEI: '.(string)$data[1].', Linea: '.$lineNumber.', ya tiene asignación';
                        $lineNumber++;
                        continue;
                    }

                    $stmt->bindValue(1, '2', PDO::PARAM_STR); //Estado
                    $stmt->bindValue(2, $responsable["idconsultor"], PDO::PARAM_STR); //Responsable a quién se le asigna
                    $stmt->bindValue(3, $asignador, PDO::PARAM_STR); //Asignador
                    $stmt->bindValue(4, $data[7].' 00:00:00', PDO::PARAM_STR); //Fecha de asignación
                    $stmt->bindValue(5, $accesorios, PDO::PARAM_STR); //Accesorios
                    $stmt->bindValue(6, (string)$data[1], PDO::PARAM_STR); //IMEI a asignar
                    $stmt->bindValue(7, $responsable["sedeconsultor"], PDO::PARAM_STR); //Sede del consultor
    
                    if($stmt->execute()){
                        $asignados += $stmt->rowCount();
                    } else{
                        $noAsignados[] = 'IMEI: '.(string)$data[1].', Linea: '.$lineNumber;
                    }

                    $lineNumber++;
                }

                fclose($handle);

                if($asignados < 1){
                    echo json_encode(array(
                        "cantidad" => $asignados,
                        "total" => $totalLineas,
                        "icono" => "info",
                        "titulo" => "Atención",
                        "noAsignados" => count($noAsignados)<1 ? "" : implode("<br>", $noAsignados),
                        "mensaje" => "No fue posible asignar ningún dispositivo, por favor revise el formato del archivo o bien los dispositivos que desea registrar, ya se encuentran asignados."
                    ));
                } else{
                    echo json_encode(array(
                        "cantidad" => $asignados,
                        "total" => $totalLineas,
                        "icono" => "success",
                        "titulo" => "Éxito",
                        "noAsignados" => count($noAsignados)<1 ? "" : implode("<br>", $noAsignados),
                        "mensaje" => "Dispositivos asignados con éxito."
                    ));
                }
            } else{
                echo json_encode(array(
                    "icono" => "info",
                    "titulo" => "Atención",
                    "mensaje" => "El archivo no tiene el formato esperado. Por favor verificar y volver a subir."
                ));
            }
        } else{
            echo "No se ha subido ningún archivo o existe un error en el archivo.";
        }        

    }

}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $cargar = new AsignacionMasiva();
    $cargar->asignar();
}
