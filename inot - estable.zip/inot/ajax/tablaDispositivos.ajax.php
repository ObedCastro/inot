<?php

session_start();

require_once "../controladores/dispositivos.controlador.php";
require_once "../controladores/consultores.controlador.php";

require_once "../modelos/dispositivos.modelo.php";
require_once "../modelos/consultores.modelo.php";

class TablaDispositivos{

    //Mostrar la tabla de dispositivos
    public function mostrarTabla(){
        $item = null;
        $valor = null;

        $dispositivos = ControladorDispositivos::ctrMostrarDispositivos($item, $valor);

        $datosJson = '{
            "data": [';

            for($i=0; $i<count($dispositivos); $i++){

                $tipoDispositivo = "<div class='d-flex justify-content-evenly'><div class='d-flex flex-column justify-content-center'><h6 class='mb-0 text-sm'>".$dispositivos[$i]['tipodispositivo']."</h6></div></div>";
                $marcaDispositivo = "<p class='text-xs mb-0'>".$dispositivos[$i]['marcadispositivo']."</p>";

                //Comprobar el estado del dispositivo
                $edispositivo = $dispositivos[$i]['estadodispositivo'];
                if($edispositivo == "1"){
                    $colorElemento = "bg-light text-dark";
                    $textoMostrar = "Disponible";
                    $boton = "btnAsignarDispositivo";
                    $modal = "data-bs-toggle='modal' data-bs-target='#modalAsignarDispositivo'";
                    $textoAsignarRecepcionar = "ASIGNAR ESTE DISPOSITIVO";
                } else if($edispositivo == "2"){
                    $colorElemento = "alert-success";
                    $textoMostrar = "Asignado";
                    $boton = "btnRecuperarDispositivo";
                    $modal = "data-bs-toggle='modal' data-bs-target='#modalRecuperarDispositivo'";
                    $textoAsignarRecepcionar = "RECEPCIONAR ESTE DISPOSITIVO";
                } else if($edispositivo == "3"){
                    $colorElemento = "alert-danger";
                    $textoMostrar = "Dañado";
                    $boton = "";
                    $modal = "";
                    $textoAsignarRecepcionar = "";
                } else if($edispositivo == "4"){
                    $colorElemento = "alert-warning";
                    $textoMostrar = "Robo/Extravío";
                    $boton = "";
                    $modal = "";
                    $textoAsignarRecepcionar = "";
                } else if($edispositivo == "5"){
                    $colorElemento = "alert-dark";
                    $textoMostrar = "Inactivo";
                    $boton = "";
                    $modal = "";
                    $colorEstado = "text-warning";
                    $textoAsignarRecepcionar = "";
                }

                $modeloDispositivo = "<span class='text-secondary text-xs'>".$dispositivos[$i]['modelodispositivo']."</span>";
                $serieDispositivo = "<span class='text-secondary text-xs'>".$dispositivos[$i]['seriedispositivo']."</span>";
                $imeiDispositivo = "<span class='text-secondary text-xs'>".$dispositivos[$i]['imeidispositivo']."</span>";
                
                /* if($dispositivos[$i]['imeidispositivo']){
                    $imeiDispositivo = "<span class='text-secondary text-xs'>".$dispositivos[$i]['imeidispositivo']."</span>";
                } else{
                    $imeiDispositivo = "<span class='text-secondary text-xs'>".$dispositivos[$i]['seriedispositivo']."</span>";
                } */

                $inventarioDispositivo = "<span class='text-secondary text-xs'>".$dispositivos[$i]['inventariodispositivo']."</span>";

                $hostnameDispositivo = "<span class='text-secondary text-xs'>".$dispositivos[$i]['hostnamedispositivo']."</span>";
                $cajadispositivo = "<span class='text-secondary text-xs'>".$dispositivos[$i]['cajadispositivo']."</span>";
                $correlativodispositivo = "<span class='text-secondary text-xs'>".$dispositivos[$i]['correlativodispositivo']."</span>";
                
                $sedeDispositivo = "<span class='text-secondary text-xs col-sede' data-bs-toggle='tooltip' data-bs-placement='top' title='".$dispositivos[$i]['sede']."'>".$dispositivos[$i]['sede']."</span>";

                //--------------------------------------------------------------------------------------------
                //BOTON PARA ASIGNAR O DESASIGNAR DISPOSITIVOS

                if($_SESSION["perfil"] != "3"){
                    $estadodispositivo = "<span idDispositivo='".$dispositivos[$i]['iddispositivo']."' consultor='".$dispositivos[$i]['responsabledispositivo']."' style='cursor:pointer;' ".$modal." class='".$boton." badge badge-sm ".$colorElemento."'><span data-bs-toggle='tooltip' data-bs-placement='top' title='".$textoAsignarRecepcionar."'>".$textoMostrar."</span></span>";
                } else{
                    $estadodispositivo = "<span class='badge badge-sm ".$colorElemento."'><span data-bs-toggle='tooltip' data-bs-placement='top' title='".$textoAsignarRecepcionar."'>".$textoMostrar."</span></span>";
                }

                //--------------------------------------------------------------------------------------------
                //Obtener el nombre del responsable del dispoaisivo
                $respuesta2 = ControladorConsultores::ctrMostrarConsultores("idconsultor", $dispositivos[$i]["responsabledispositivo"]);

                if($respuesta2 > 0){
                    $consultor = $respuesta2["nombreconsultor"];

                    $carnet = $respuesta2["duiconsultor"];
                } else{
                    $consultor = "------";
                    $carnet = "------";
                }
                $resposableDispositivo = "<span class='text-secondary text-xs col-responsable' data-bs-toggle='tooltip' data-bs-placement='top' title='".$consultor."'>".$consultor."</span>";
                $carnetConsultor = "<span class='text-secondary text-xs col-estatus'>".$carnet."</span>";

                //--------------------------------------------------------------------------------------------
                //BOTONES PARA LA TABLA

                $botonVerDetalleDispositivo = "<a idDispositivo='".$dispositivos[$i]['iddispositivo']."' style='cursor:pointer;' class='text-secondary p-1 btnMostrarDispositivos mb-0' data-bs-toggle='modal' data-bs-target='#modalVerDetalleDispositivo'><i class='fa fa-eye fs-6 p-1' data-bs-toggle='tooltip' data-bs-placement='top' title='Ver más información'></i></a>";

                    if($_SESSION["perfil"] != "3"){
        
                        $botonEditarDispositivo = "<a idEditarDispositivo='".$dispositivos[$i]['iddispositivo']."' style='cursor:pointer;' class='text-secondary p-1 btnEditarDispositivo mb-0' data-bs-toggle='modal' data-bs-target='#modalEditarDispositivos'><i class='fa fa-pencil fs-6 p-1' data-bs-toggle='tooltip' data-bs-placement='top' title='Modificar la información'></i></a>";

                        /* Mostrar botones de eliminar y cambiar estado, solamente si el dispositivo no está asignado */
                        if($respuesta2 < 1){

                            if($dispositivos[$i]['estadodispositivo'] == '1'){
                                $botonCambiarEstado = "<a idEstadoDispositivo='".$dispositivos[$i]['iddispositivo']."' estadod='1' style='cursor:pointer;' class='text-secondary p-1 btnCambiarEstado mb-0'><i class='fa fa-toggle-on fs-6 p-1 text-success' data-bs-toggle='tooltip' data-bs-placement='top' title='Cambiar estado a INACTIVO'></i></a>";
                            } else if($dispositivos[$i]['estadodispositivo'] == '5'){
                                $botonCambiarEstado = "<a idEstadoDispositivo='".$dispositivos[$i]['iddispositivo']."' estadod='5' style='cursor:pointer;' class='text-secondary p-1 btnCambiarEstado mb-0'><i class='fa fa-toggle-off fs-6 p-1 text-danger' data-bs-toggle='tooltip' data-bs-placement='top' title='Cambiar estado a ACTIVO'></i></a>";
                            } else{
                                $botonCambiarEstado = "<a estadod='0' style='cursor:auto;' class='text-secondary p-1 mb-0'><i class='fa fa-toggle-on fs-6 p-1 text-secondary''></i></a>";
                            }

                            $botonEliminarDispositivo = "<a idEliminarDispositivo='".$dispositivos[$i]['iddispositivo']."' style='cursor:pointer;' class='text-secondary p-1 btnEliminarDispositivo mb-0'><i class='fa fa-trash fs-6 p-1' data-bs-toggle='tooltip' data-bs-placement='top' title='Eliminar dispositivo'></i></a>";
                        } else{
                            $botonEliminarDispositivo = "<a class='text-secondary p-1 mb-0'><i class='fa fa-trash btn-eliminar-disabled fs-6 p-1'></i></a>";

                            $botonCambiarEstado = "<a estadod='0' style='cursor:auto;' class='text-secondary p-1 mb-0'><i class='fa fa-toggle-on fs-6 p-1 text-secondary''></i></a>";
                        }
                    } else{
                        $botonEditarDispositivo = "";
                        $botonEliminarDispositivo = "";
                    }

                    if($dispositivos[$i]['estadodispositivo'] == '5'){
                        $botonEditarDispositivo = "<a onclick='alerta();' class='text-secondary p-1 mb-0 btnEditarDispositivo'><i class='fa fa-pencil fs-6 p-1' data-bs-toggle='tooltip' data-bs-placement='top' title='No se puede modificar esta información'></i></a>";
                    }
                //--------------------------------------------------------------------------------------------

                $acciones = "<ul class='navbar-nav justify-content-evenly'>".
                                "<li class='nav-item pe-2 d-flex justify-content-center'>".
                                    "<div class='nav-link text-body p-0'>".
                                        $botonVerDetalleDispositivo.
                                        $botonEditarDispositivo.
                                        $botonCambiarEstado.
                                        $botonEliminarDispositivo.
                                    "</div>".
                                "</li>".
                            "</ul>";

                $datosJson .= '[
                            "'.$tipoDispositivo.'",
                            "'.$marcaDispositivo.'",
                            "'.$modeloDispositivo.'",
                            "'.$serieDispositivo.'",
                            "'.$imeiDispositivo.'",
                            "'.$inventarioDispositivo.'",
                            "'.$hostnameDispositivo.'",
                            "'.$cajadispositivo.'",
                            "'.$correlativodispositivo.'",
                            "'.$sedeDispositivo.'",
                            "'.$estadodispositivo.'",
                            "'.$resposableDispositivo.'",
                            "'.$carnetConsultor.'",
                            "'.$acciones.'"
                ],';
            }

            $datosJson = substr($datosJson, 0, -1);
                $datosJson .= ']
            }';

        echo $datosJson;
        
        }
}

$activar = new TablaDispositivos();
$activar->mostrarTabla();
