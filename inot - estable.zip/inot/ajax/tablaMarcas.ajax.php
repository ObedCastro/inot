<?php
 
require_once "../controladores/administradores.controlador.php";
require_once "../modelos/administradores.modelo.php";

class TablaAdministradores{

    public function mostrarAdministradores(){

        $item = null;
        $valor = null;
        $marcas = ControladorAdministradores::ctrMostrarMarcas(null, null);

        echo json_encode(array("data"=>$marcas));
    }

}


$activar = new TablaAdministradores();
$activar->mostrarAdministradores();
