<?php

session_start();

require_once "../controladores/inicio.controlador.php";
require_once "../modelos/inicio.modelo.php";

class AjaxGraficoBarras{

    public function ajaxMostrarGraficoBarras(){
      if(isset($_POST["url"]) && $_POST["url"] == "inicio-sede"){
        $sede = $_SESSION["sedeasignada"];
      } else{
        $sede = "";
      }

      $resultado = ControladorInicio::ctrMostrarGraficoBarras($sede);
  
      echo json_encode($resultado);
    }

}

$mostrarGraficoBarras = new AjaxGraficoBarras();
$mostrarGraficoBarras->ajaxMostrarGraficoBarras();