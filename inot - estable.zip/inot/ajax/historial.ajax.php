<?php

require_once "../controladores/historial.controlador.php";
require_once "../modelos/historial.modelo.php";

class AjaxHistorial{

    public $imei;
    public $serie;
    public $inventario;

    public function ajaxMostrarHistorial(){
        $item_imei = $this->imei;
        $item_serie = $this->serie;
        $item_inventario = $this->inventario;

        $respuesta = ControladorHistorial::ctrMostrarHistorial($item_imei, $item_serie, $item_inventario);

        echo json_encode($respuesta);

    }

}





if(isset($_POST["imei"]) || isset($_POST["serie"]) || isset($_POST["inventario"])){
    $historial = new AjaxHistorial();
    $historial->imei = isset($_POST["imei"]) ? $_POST["imei"] : "";
    $historial->serie = isset($_POST["serie"]) ? $_POST["serie"] : "";
    $historial->inventario = isset($_POST["inventario"]) ? $_POST["inventario"] : "";
    $historial->ajaxMostrarHistorial();
  }