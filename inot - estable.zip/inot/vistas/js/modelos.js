/* la variable "localhost" está definida en el archivo base */

let tablaModelos = new DataTable('#datatableModelos', {
    ajax: localhost + 'ajax/tablaModelos.ajax.php',
    columns: [
      {
        data: null,
        render: function (data, type, row, meta) {
          return meta.row + 1;
        },
        orderable: false, 
        className: 'dt-body-center'
      },
      {
        data: 'nombremodelo',
        render: function (data) {
          return '<span class="text-secondary text-xs font-weight-bold">'+data+'</span>';
        }
      },
      {
        data: 'idmodelo',
        render: function (data) {
          return '<span class="icon-options"><i data-bs-toggle="tooltip" data-bs-placement="top" title="Eliminar este registro" class="fa fa-trash btnEliminarmodelo" idEliminarModelo="'+data+'"></i></span>';
        }
      },
    ],
    language: {
        "decimal": "",
        "emptyTable": "No hay información",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
        "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
        "infoFiltered": "(Filtrado de _MAX_ total entradas)",
        "infoPostFix": "",
        "thousands": ",",
        "lengthMenu": "Mostrar _MENU_ Entradas",
        "loadingRecords": "Cargando...",
        "processing": "Procesando...",
        "search": "Buscar:",
        "zeroRecords": "Sin resultados encontrados",
        "paginate": {
            "first": "Primero",
            "last": "Ultimo",
            "next": "Siguiente",
            "previous": "Anterior"
        }
    },
});