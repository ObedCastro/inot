/* la variable "localhost" está definida en el archivo base */ 

let tablaSedes = new DataTable('#datatableSedes', {
    ajax: localhost+'ajax/tablaSedes.ajax.php',
    columns: [
      /* {
        data: null,
        render: function (data, type, row, meta) {
          return meta.row + 1;
        },
        orderable: false, 
        className: 'dt-body-center text-xs'
      }, */
      {
        data: 'idsede',
        render: function (data) {
          return '<span class="text-secondary text-xs font-weight-bold d-flex justify-content-center">'+data+'</span>';
        }
      },
      {
        data: 'nombresede',
        render: function (data) {
          return '<span class="text-secondary text-xs font-weight-bold">'+data+'</span>';
        }
      },
      {
        data: 'departamentosede',
        render: function (data) {
          return '<span class="text-secondary text-xs font-weight-bold">'+data+'</span>';
        }
      },
      {
        data: 'regionsede',
        render: function (data) {
          return '<span class="text-secondary text-xs font-weight-bold">'+data+'</span>';
        }
      },
      {
        data: 'idsede',
        render: function (data) {
          return '<div class="d-flex justify-content-center align-items-center"><span class="icon-options" style="cursor: pointer;"><i data-bs-toggle="tooltip" data-bs-placement="top" title="Eliminar este registro" class="fa fa-trash btnEliminarSede" idEliminarSede='+data+'></i></span><span class="icon-options" style="cursor: pointer;" data-bs-toggle="modal" data-bs-target="#modalEditarSede"><i data-bs-toggle="tooltip" data-bs-placement="top" title="Modificar" class="fa fa-edit btnEditarSede" idEditarSede_='+data+'></i></span></div>';
        }
      },
    ],
    language: {
        "decimal": "",
        "emptyTable": "No hay información",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
        "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
        "infoFiltered": "(Filtrado de _MAX_ total entradas)",
        "infoPostFix": "",
        "thousands": ",",
        "lengthMenu": "Mostrar _MENU_ Entradas",
        "loadingRecords": "Cargando...",
        "processing": "Procesando...",
        "search": "Buscar:",
        "zeroRecords": "Sin resultados encontrados",
        "paginate": {
            "first": "Primero",
            "last": "Ultimo",
            "next": "Siguiente",
            "previous": "Anterior"
        }
    },
});
