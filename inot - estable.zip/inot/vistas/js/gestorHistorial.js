$(".detalles-dispositivos").hide();

$("#formBuscarhistorial input[type='text']").focus(function(){
    $('#formBuscarhistorial input[type="text"]').not(this).val('').prop('disabled', true);
})

$('#formBuscarhistorial input[type="text"]').blur(function() {
    $('#formBuscarhistorial input[type="text"]').not(this).prop('disabled', false);
  });


$("#formBuscarhistorial").on("submit", function(e){
    e.preventDefault();

    var busqueda_imei = $("#historialImei").val();
    var busqueda_serie = $("#historialSerie").val();
    var busqueda_inventario = $("#historialInventario").val();

    if(busqueda_imei != "" || busqueda_serie != "" || busqueda_inventario != ""){
        $.ajax({
            url: localhost+'ajax/historial.ajax.php',
            type: 'POST',
            data: {
                imei: busqueda_imei,
                serie: busqueda_serie,
                inventario: busqueda_inventario
            },
            success: function(respuesta) {
                console.log(JSON.parse(respuesta));
                var datos = JSON.parse(respuesta);
                if(datos[0] != ""){
                    $(".detalles-dispositivos").show();
                    $("#mostrarTipoDispositivo").text(datos[0].tipodispositivo);
                    $("#mostrarMarcaDispositivo").text(datos[0].marcadispositivo);
                    $("#mostrarModeloDispositivo").text(datos[0].modelodispositivo);
                    $("#mostrarImeiDispositivo").text(datos[0].imeidispositivo);
                    $("#mostrarSerieDispositivo").text(datos[0].seriedispositivo);
                    $("#mostrarInventarioDispositivo").text(datos[0].inventariodispositivo);
                    $("#mostrarHostnameDispositivo").text(datos[0].hostnamedispositivo);
                    $("#mostrarTelefonoDispositivo").text(datos[0].telefonodispositivo);
                    $("#fechaRegistro").text(datos[0].fecharegistro);
                    $("#fechaModificacion").text(datos[0].fechamodificacion);
                }
                
                if(datos[1] != ""){
                    
                    $(".historial-timeline").empty();
                    
                    datos[1].forEach(datos => {
                        var dateParts = datos.fecha_asignacion.split(" ")[0].split("-");
                        var formattedDate = dateParts[2] + "/" + dateParts[1] + "/" + dateParts[0];
                        
                        var estatusconsultor = "";
                        switch(datos.estatusconsultor){
                            case "1": estatusconsultor = "Consultor BID"; break;
                            case "2": estatusconsultor = "Banco Central de Reserva"; break;
                            case "3": estatusconsultor = "ONEC"; break;
                            case "4": estatusconsultor = "Consultor"; break;
                            default: estatusconsultor = "";
                        }

                        var receptor = datos.nombre_receptor != null ? datos.nombre_receptor: "<span class='text-warning'>NO SE HA REALIZADO RECEPCIÓN DE ESTE DISPOSITIVO</span>";
                        
                        //PARA MOSTRAR LOS ACCESORIOS ENTREGADOS
                        entregados = [];
                        var accesorios_entregados = JSON.parse(datos.accesorios_entregados);
                        for(const key in accesorios_entregados){
                            if (accesorios_entregados.hasOwnProperty(key)){
                                const value = accesorios_entregados[key];
                                
                                if (value === "1") {
                                    entregados.push('<span>'+key+'</span>');
                                }
                                
                            }
                        }
          
                        //PARA MOSTRAR LOS ACCESORIOS RECUPERADOS
                        recuperados = [];
                        var accesorios_recuperados = JSON.parse(datos.accesorios_recuperados);
                        for(const key in accesorios_recuperados){
                            if (accesorios_recuperados.hasOwnProperty(key)){
                                const value = accesorios_recuperados[key];
                                
                                if (value === "1") {
                                    recuperados.push('<span>'+key+'</span>');
                                }
                                
                            }
                        }
                        
                        var acc_asig = entregados.length < 1 ? '<p class="text-danger opacity-4">Sin accesorios asignados</p>' : entregados.join(" ");
                        var acc_rec = recuperados.length < 1 ? '<p class="text-danger opacity-4">Sin accesorios recuperados</p>' : recuperados.join(" ");
                        var comentario = datos.comentario != '' ? '<span class="text-bold">COMENTARIO:</span> '+datos.comentario : ' ';
                        
                        $(".historial-timeline").append(
                            '<div class="timeline-contenedor mb-3">'+
                            '<span class="timeline-date">'+
                            '<span class="badge text-bg-primary">'+formattedDate+'</span>'+
                            '</span>'+
                            '<div class="timeline-block">'+
                            '<span class="timeline-step">'+
                            '<i class="ni ni-bell-55 text-success text-gradient"></i>'+
                            '</span>'+
                            '<div class="row">'+
                            '<div class="col-md-5">'+
                            '<div class="timeline-content">'+
                            '<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Movimiento</p>'+
                            '<p class="mb-0"><span class="text-dark text-sm font-weight-bold">Asignado por:</span> '+datos.nombre_asignador+
                            '<p class="mb-0"><span class="text-dark text-sm font-weight-bold">Recuperado por:</span> '+receptor+'</p>'+
                            '<p class="mb-0"><span class="text-dark text-sm font-weight-bold">Usuario responsable:</span> '+datos.nombreconsultor+'</p>'+
                            '<p class="mb-0"><span class="text-dark text-sm font-weight-bold">Tipo de contrato:</span> '+estatusconsultor+'</p>'+
                            '<p class="mb-0"><span class="text-dark text-sm font-weight-bold">Sede del usuario:</span> '+datos.sede+'</p>'+
                            '<p class="mb-0"><span class="text-dark text-sm font-weight-bold">Cargo del usuario:</span> '+datos.cargoconsultor+'</p>'+
                            '<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">'+datos.fecha_asignacion+'</p>'+
                            '</div>'+
                            '</div>'+
                            '<div class="col-md-7">'+
                            '<div class="timeline-content">'+
                            '<div class="contenedor-accesorios">'+
                            '<p class="text-dark text-sm font-weight-bold mb-0">ACCESORIOS ENTREGADOS</p>'+
                            '<p id="result_a" class="text-dark text-sm font-weight-bold mb-0">'+acc_asig +'</p>'+
                            '<p class="text-dark text-sm font-weight-bold mb-0 mt-3">ACCESORIOS RECUPERADOS</p>'+
                            '<p id="result_r" class="text-dark text-sm mb-0">'+acc_rec +'</p>'+
                            '<span>'+comentario+'</span'+
                            '</div>'+
                            '</div>'+
                            '</div>'+
                            '</div>'+
                            '</div>'+
                            '</div>'
                        );
                        
                    });
                } else{
                      $(".historial-timeline").empty();
                      $(".historial-timeline").append('<span class="alert alert-danger d-block text-center mt-2">Sin historial que mostrar.<span>');
                      
                    }
                }
            });
        } else{
            Swal.fire({
                icon: "error",
                title: "Filtro de búsqueda",
                text: "No es posible realizar la búsqueda con campos vacíos.",
                showConfirmButton: true
            });
            $(".historial-timeline").empty();
        }
        
    })