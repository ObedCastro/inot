<!-- Modal -->
<div class="modal fade" id="modalAsignacionMasiva" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-success">
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill cursor-pointer btn-cerrar-modal" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-remove text-white"></i></span>
        <p class="modal-title text-white" id="exampleModalLabel"><i class="fa fa-cloud-upload"></i> Asignación masiva de dispositivos</p>
        <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
      </div>
      <div class="modal-body">
        <form id="asignarDispositivosMasivamente" enctype="multipart/form-data">
            <div class="mb-3 text-center">
                <label for="file" class="form-label">Buscar en un directorio</label>
                <input class="form-control" type="file" id="file" name="file" accept=".csv">
            </div>

            <div class="text-center btns-cargar">
              <button type="button" class="btn btn-outline-secondary btn_refresh" data-bs-dismiss="modal">Cancelar</button>
              <button type="submit" class="btn btn-success">Cargar datos</button>
            </div>
        </form>

        <div class="text-center">
          <button type="submit" id="btnFormatoAsignacionMasiva" class="btn btn-link text-black mb-0">Descargar Formato CSV para asignar DMC masivamente <br> <i class="fa fa-file-csv text-success fs-5"></i>
          </button><br>
          <small class="mt-0"><strong>NOTA: </strong>Eliminar el registro de ejemplo en el formato, antes de subir el archivo.</small>
        </div>

      </div>
    </div>
  </div>
</div>


