<?php

  /* Mostrar accesorios asignados actualmente */

  $ancho_grafico_lineas = "col-lg-5";
  
  if($ruta[0] == "inicio-sede"){
    $ancho_grafico_lineas = "col-lg-7";

    $accesorios = ControladorInicio::ctrCantidadAccesoriosAsignados($_SESSION["sedeasignada"]);
    
    echo '<div class="col-lg-2">
      <div class="card z-index-2">
        <div class="card-header pb-0">
          <h6>Accesorios asignados en sede</h6>
          <p class="text-sm mb-0">
          </p>
        </div>
        <div class="card-body p-1">
          <div class="container border-radius-lg">
                <div class="row">';

                $arrayAccesorios = array_column($accesorios, 'accesorios');
                $contador = [];

                foreach ($arrayAccesorios as $json_accesorios) {
                  $items = json_decode($json_accesorios, true);
              
                  foreach ($items as $clave => $valor) {
                      if ($valor === "1") {
                          if (!isset($contador[$clave])) {
                              $contador[$clave] = 0;
                          }
                          $contador[$clave]++;
                      }
                  }
                }
                
                  foreach ($contador as $accesorio => $cantidad) {
                    echo '<div class="col-12 d-flex align-items-center justify-content-between items-accesorios">
                            <div class="d-flex">
                              <div class="icon icon-shape icon-xxs shadow border-radius-sm bg-gradient-primary justify-content-center text-center me-2 d-flex align-items-center">
                                <svg width="10px" height="10px" viewBox="0 0 40 40" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                  <title>settings</title>
                                  <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <g transform="translate(-2020.000000, -442.000000)" fill="#FFFFFF" fill-rule="nonzero">
                                      <g transform="translate(1716.000000, 291.000000)">
                                        <g transform="translate(304.000000, 151.000000)">
                                          <polygon class="color-background" opacity="0.596981957" points="18.0883333 15.7316667 11.1783333 8.82166667 13.3333333 6.66666667 6.66666667 0 0 6.66666667 6.66666667 13.3333333 8.82166667 11.1783333 15.315 17.6716667"></polygon>
                                          <path class="color-background" d="M31.5666667,23.2333333 C31.0516667,23.2933333 30.53,23.3333333 30,23.3333333 C29.4916667,23.3333333 28.9866667,23.3033333 28.48,23.245 L22.4116667,30.7433333 L29.9416667,38.2733333 C32.2433333,40.575 35.9733333,40.575 38.275,38.2733333 L38.275,38.2733333 C40.5766667,35.9716667 40.5766667,32.2416667 38.275,29.94 L31.5666667,23.2333333 Z" opacity="0.596981957"></path>
                                          <path class="color-background" d="M33.785,11.285 L28.715,6.215 L34.0616667,0.868333333 C32.82,0.315 31.4483333,0 30,0 C24.4766667,0 20,4.47666667 20,10 C20,10.99 20.1483333,11.9433333 20.4166667,12.8466667 L2.435,27.3966667 C0.95,28.7083333 0.0633333333,30.595 0.00333333333,32.5733333 C-0.0583333333,34.5533333 0.71,36.4916667 2.11,37.89 C3.47,39.2516667 5.27833333,40 7.20166667,40 C9.26666667,40 11.2366667,39.1133333 12.6033333,37.565 L27.1533333,19.5833333 C28.0566667,19.8516667 29.01,20 30,20 C35.5233333,20 40,15.5233333 40,10 C40,8.55166667 39.685,7.18 39.1316667,5.93666667 L33.785,11.285 Z"></path>
                                        </g>
                                      </g>
                                    </g>
                                  </g>
                                </svg>
                              </div>
                              <p class="text-xs mt-1 mb-0 px-2 font-weight-bold" style="width: 100px;">'.htmlspecialchars($accesorio).'</p>
                            </div>
                            <h4 class="font-weight-bolder my-0">'.htmlspecialchars($cantidad).'</h4>
                          </div>';
                  }                    

                echo '</div>
          </div>
        </div>
      </div>
    </div>';
  }

?>



<div class="<?php echo $ancho_grafico_lineas; ?> mb-lg-0 mb-4">
  <div class="card z-index-2">
    <h6 class="ms-2 mt-4 mb-0"> Dispositivos por modelo </h6>
    <div class="card-body p-3">

      <!-- Gráfico de líneas -->
      <div class="bg-gradient-dark border-radius-lg py-3 pe-1 mb-3">
        <div class="chart">
          <canvas id="chart-bars" class="chart-canvas" height="130"></canvas>
        </div>
      </div>

      <!-- Muestra totales por departamento -->
      <!-- <h6 class="ms-2 mt-4 mb-0"> Dispositivos por departamentos </h6>
      <div class="container border-radius-lg">
        <div class="row">
          
          <?php
            $dispositivosDepartamento = ControladorInicio::ctrMostrarDispositivosDepartamento();
            $colorIcon = array("bg-gradient-primary", "bg-gradient-success", "bg-gradient-warning", "bg-gradient-danger", "bg-gradient-dark", "bg-gradient-secondary", "bg-gradient-primary", "bg-gradient-success", "bg-gradient-warning", "bg-gradient-danger", "bg-gradient-dark", "bg-gradient-secondary");

            $dispositivosRegion = ControladorInicio::ctrMostrarDispositivosRegion();            

            foreach ($dispositivosDepartamento as $key => $value) {
              $departamento = $value["departamento"];
              $totalDepartamento = $value["total"];

              $detalleRegiones = "";

              foreach ($dispositivosRegion as $region) {
                if($region["departamento"] == $departamento){
                  $detalleRegiones .= "<p class='my-1 d-flex justify-content-left'>".$region["region"]." &#8594;  <span class='badge bg-success'> Total: ".$region["total"]."</span></p>";
                }
              }

              echo '<br>';

              echo '<div class="col-3 py-3 ps-0" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-html="true" title="'.$detalleRegiones.'">
                <div class="d-flex mb-2">
                  <div class="icon icon-shape icon-xxs shadow border-radius-sm '.$colorIcon[$key].' text-center me-2 d-flex align-items-center justify-content-center">
                  <svg width="16px" height="16px" viewBox="0 0 42 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> <title></title> <g id="Basic-Elements" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Rounded-Icons" transform="translate(-1869.000000, -293.000000)" fill="#FFFFFF" fill-rule="nonzero"> <g id="Icons-with-opacity" transform="translate(1716.000000, 291.000000)"> <g id="office" transform="translate(153.000000, 2.000000)"> <path class="color-background" d="M12.25,17.5 L8.75,17.5 L8.75,1.75 C8.75,0.78225 9.53225,0 10.5,0 L31.5,0 C32.46775,0 33.25,0.78225 33.25,1.75 L33.25,12.25 L29.75,12.25 L29.75,3.5 L12.25,3.5 L12.25,17.5 Z" id="Path" opacity="0.6"></path> <path class="color-background" d="M40.25,14 L24.5,14 C23.53225,14 22.75,14.78225 22.75,15.75 L22.75,38.5 L19.25,38.5 L19.25,22.75 C19.25,21.78225 18.46775,21 17.5,21 L1.75,21 C0.78225,21 0,21.78225 0,22.75 L0,40.25 C0,41.21775 0.78225,42 1.75,42 L40.25,42 C41.21775,42 42,41.21775 42,40.25 L42,15.75 C42,14.78225 41.21775,14 40.25,14 Z M12.25,36.75 L7,36.75 L7,33.25 L12.25,33.25 L12.25,36.75 Z M12.25,29.75 L7,29.75 L7,26.25 L12.25,26.25 L12.25,29.75 Z M35,36.75 L29.75,36.75 L29.75,33.25 L35,33.25 L35,36.75 Z M35,29.75 L29.75,29.75 L29.75,26.25 L35,26.25 L35,29.75 Z M35,22.75 L29.75,22.75 L29.75,19.25 L35,19.25 L35,22.75 Z"></path> </g> </g> </g> </g> </svg>
                  </div>
    
                </div>
                <p class="text-xs mt-1 mb-0 font-weight-bold">'.$value["departamento"].'</p>
                <h4 class="font-weight-bolder">'.$value["total"].'</h4>
                <div class="progress w-75">
                  <div class="progress-bar bg-dark w-'.$value["total"].'" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>';
              
            }
          ?>
          
        </div>
      </div> -->
    </div>
  </div>
</div>