<?php

if($ruta[0] != "inicio-sede"){
  echo '<div class="col-lg-4">
    <div class="card z-index-2">
      <div class="card-header pb-0">
        <h6>Dispositivos por sede</h6>
        <p class="text-sm mb-0">
        </p>
      </div>
      <div class="card-body p-2">
  
        <div class="btn-group">
          <button class="btn btn-secondary btn-sm dropdown-toggle btn-leyendas" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            Ver leyendas
          </button>
  
          <ul class="dropdown-menu" id="leyendasPersonalizadas"></ul>
        </div>
  
        <div class="chart display: flex; justify-content: space-between;">
          <canvas id="chart-doughnut" class="chart-canvas"></canvas>
        </div>
      </div>
    </div>
  </div>';
}
?>


<div class="col-lg-3">
  <div class="card z-index-2">
    <div class="card-header pb-0">
      <h6>Dispositivos por tipo</h6>
    </div>

    <div class="card-body p-3 pt-0">
    <span class="text-secondary">Seleccione una sede.</span>
      <select class="form-select" aria-label="Default select example" id="selectMostrarPorSede">
        <?php
          if($ruta[0] == "inicio-sede"){
            $sedes = ControladorSedes::ctrMostrarSedes('idsede', $_SESSION["sedeasignada"]);
            echo '<option value="'.$sedes["idsede"].'">'.$sedes["nombresede"].' '.$sedes["departamentosede"].'</option>';
          } else{
            $sedes = ControladorSedes::ctrMostrarSedes(null, null);
            foreach ($sedes as $key => $value) {
              echo '<option value="'.$value["idsede"].'">'.$value["nombresede"].' '.$value["departamentosede"].'</option>';
            }
          }

        ?>
      </select>

      <!-- Muestra dispositivos por tipo -->
      <div class="row mt-3 mostrarProgress">
        <!-- Contenido se rellena desde jquery -->
      </div>
    </div>
  </div>
</div>