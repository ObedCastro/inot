<!-- Error 404 Template 1 - Bootstrap Brain Component -->
<section class="py-3 py-md-5 min-vh-100 d-flex justify-content-center align-items-center">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="text-center">
          <h2 class="d-flex justify-content-center align-items-center gap-2 mb-4">
            <span class="display-1 fw-bold">404</span>
          </h2>
          <h3 class="h2 mb-2">Oops! Algo ha ido mal.</h3>
          <p class="mb-5">La página a la que está intentando acceder, no fue encontrada.</p>
          <a class="btn bsb-btn-5xl btn-dark rounded-pill px-5 fs-6 m-0" href="#" id="rinicio" role="button">Regresar al inicio</a>
        </div>
      </div>
    </div>
  </div>
</section>

<script>
  document.getElementById('rinicio').href = localhost+"inicio";
</script>