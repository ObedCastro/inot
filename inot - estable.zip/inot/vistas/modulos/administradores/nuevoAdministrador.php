<div class="modal fade" id="modalNuevoAdmin" tabindex="-1" aria-labelledby="modalNuevoAdminLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill cursor-pointer btn-cerrar-modal" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-remove text-white"></i></span>
        <h1 class="modal-title fs-5 text-white" id="modalNuevoAdminLabel"><i class="fa fa-user"></i>Registrar nuevo administrador</h1>
        <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
      </div>
      <div class="modal-body">

        <form method="POST" id="formularioNuevoAdmin" class="needs-validation" novalidate>
          <input type="hidden" name="nuevo" value="nuevo">
          <div class="row">
            <div class="mb-3 col-md-6">
              <label for="nombreAdmin" class="form-label">Nombre <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="nombreAdmin" name="nombreAdmin" onkeypress="return ((event.charCode >= 65 && event.charCode <= 90) || (event.charCode >= 97 && event.charCode <= 122) || event.charCode == 32 || event.charCode == 225 || event.charCode == 233 || event.charCode == 237 || event.charCode == 243 || event.charCode == 250 || event.charCode == 193 || event.charCode == 201 || event.charCode == 205 || event.charCode == 211 || event.charCode == 218)"
              minlength="10" maxlength="50" required>
              <div class="invalid-feedback">El nombre es requerido</div>
            </div>
            <div class="mb-3 col-md-6">
              <label for="emailAdmin" class="form-label">Email <span class="text-danger">*</span></label>
              <input type="email" class="form-control" id="emailAdmin" name="emailAdmin" required>
              <div class="invalid-feedback">El email es requerido</div>
            </div>
          </div>

          <div class="row">
            <div class="mb-3 col-md-4">
              <label for="usuarioAdmin" class="form-label">Usuario <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="usuarioAdmin" name="usuarioAdmin" onkeypress="return (event.charCode >= 97 && event.charCode <= 122)" minlength="3" maxlength="15" aria-describedby="emailHelp" required>
              <div class="invalid-feedback">Debe colocar el usuario</div>
            </div>
            <div class="mb-3 col-md-4">
              <label for="passwordAdmin" class="form-label">Contraseña <span class="text-danger">*</span></label>
              <input type="password" class="form-control" id="passwordAdmin" name="passwordAdmin" aria-describedby="emailHelp" required>
              <div class="invalid-feedback">Contraseña obligatoria</div>
            </div>
            <div class="mb-3 col-md-4">
              <label for="perfilAdmin" class="form-label">Perfil <span class="text-danger">*</span></label>
              <select id="perfilAdmin" name="perfilAdmin" class="form-select" aria-label="Default select example" required>
                  <option value=""></option>
                  <option value="1">Administrador</option>
                  <option value="2">Usuario</option>
                  <option value="3">Solo ver</option>
              </select>
              <div class="invalid-feedback">Seleccione el perfil para el usuario</div>
            </div>
          </div>
          
          <div class="row">
            <div class="mb-3 col-md-6">
              <label for="cargoAdmin" class="form-label">Cargo <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="cargoAdmin" name="cargoAdmin" onkeypress="return ((event.charCode >= 65 && event.charCode <= 90) || (event.charCode >= 97 && event.charCode <= 122) || event.charCode == 32 || event.charCode == 225 || event.charCode == 233 || event.charCode == 237 || event.charCode == 243 || event.charCode == 250 || event.charCode == 193 || event.charCode == 201 || event.charCode == 205 || event.charCode == 211 || event.charCode == 218)"
              required>
              <div class="invalid-feedback">El cargo es requerido</div>
            </div>

            <div class="mb-3 col-md-6">
              <label for="sedeAdmin" class="form-label">Sede signada <span class="text-danger">*</span></label>
              <select id="sedeAdmin" name="sedeAdmin" class="form-select" aria-label="Default select example" required>
                <option value=""></option>
                <?php 
                  $sedes = ControladorSedes::ctrMostrarSedes(null, null);
                  foreach ($sedes as $key => $sede) {
                    echo '<option value="'.$sede['idsede'].'">'.$sede['nombresede'].' '.$sede['departamentosede'].'</option>';
                  }
                ?>
              </select>
              <div class="invalid-feedback">La sede es requerida</div>
            </div>

            <div class="mb-5 col-md-6">
              <label for="tipoContrato" class="form-label">Tipo de contrato<span class="text-danger">*</span></label>
              <!-- <input type="text" class="form-control" id="tipoContrato" name="tipoContrato" required> -->
              <select class="form-select" aria-label="Default select example" id="tipoContrato" name="tipoContrato" required>
                <option value=""></option>
                <option value="Consultor BID">Consultor BID</option>
                <option value="Banco Central de Reserva">Banco Central de Reserva</option>
                <option value="ONEC">ONEC</option>
                <option value="Consultor">Consultor</option>
              </select>
              <div class="invalid-feedback">El tipo de contrato es requerido</div>
            </div>

            <div class="mb-5 col-md-6">
              <label for="sedesAdminNuevo" class="form-label">Sedes que administra</label>
              <select id="sedesAdminNuevo" name="sedesAdminNuevo" class="form-select sede-multiple" multiple required>
                <?php 
                  $sedes = ControladorSedes::ctrMostrarSedes(null, null);
                  foreach ($sedes as $key => $sede) {
                    echo '<option value="'.$sede['idsede'].'">'.$sede['nombresede'].' '.$sede['departamentosede'].'</option>';
                  }
                ?>
              </select>
            </div>
          </div>

          <div class="text-end modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary" name="opcion">Guardar</button>
          </div>

        </form>

      </div>
    </div>
  </div>
</div>