<div class="container-fluid py-2">
      <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0 d-flex justify-content-between">
              <h6>Administrar Consultores</h6>

              <?php
                if($_SESSION["perfil"] != "3"){
                  echo '<div>
                    <button type="button" class="btn btn-outline-primary btnNuevoConsultor" data-bs-toggle="modal" data-bs-target="#modalConsultores">
                    <i class="fa fa-plus me-sm-1 cursor-pointer"></i>
                      Nuevo Consultor
                    </button>

                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalCargarDataConsultores">
                    <i class="fa fa-cloud-upload mx-2"></i>
                      Cargar desde CSV
                    </button>
                  </div>';
                }
              ?>
              <!-- Button trigger modal -->
              <!-- <div>
                <button type="button" class="btn btn-outline-primary btnNuevoConsultor" data-bs-toggle="modal" data-bs-target="#modalConsultores">
                <i class="fa fa-plus me-sm-1 cursor-pointer"></i>
                  Nuevo Consultor
                </button>

                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalCargarDataConsultores">
                <i class="fa fa-plus me-sm-1 cursor-pointer"></i>
                  Cargar desde CSV
                </button>
              </div> -->
            </div>

            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive px-4">
                <table id="datatableConsultores" class="table align-items-center mb-0 tablaConsultores display">
                  <thead>
                    <tr>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Nombre</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">DUI</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Cargo</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Contacto</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Sede</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Registrado en</th>

                      <?php
                        if($_SESSION["perfil"] != "3"){
                          echo '<th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Acción</th>';
                        }
                      ?>
                      
                    </tr>
                  </thead>

                  <!--<tbody>
                  </tbody>-->

                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<?php
  //MODAL PARA REGISTRAR NUEVO Consultor
  include "vistas/modulos/consultores/nuevoConsultor.php";

  //MODAL PARA MODIFICAR INFORMACIÓN DEL Consultor
  include "vistas/modulos/consultores/modificarConsultor.php";

  //MODAL PARA CARGAR DATOS DESDE CSV
  include "vistas/modulos/consultores/modalCargarDataConsultores.php";
  
?>
