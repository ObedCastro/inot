<nav aria-label="breadcrumb">
  <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
    <li class="breadcrumb-item"><a class="opacity-6 text-dark text-bold" href="inicio">Dashboard Vista General de Equipos Informáticos en <span class="badge text-bg-warning">ZONA ORIENTE</span></a></li>
    <!--<li class="breadcrumb-item text-sm text-dark active" aria-current="page">Submenu</li>-->
  </ol>
  <!--<h6 class="font-weight-bolder mb-0">Dashboard</h6>-->
</nav> 