<!-- Navbar --> 
<nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
      <div class="container-fluid py-1 px-3">
        <?php
          include "header/migasDePan.php";
        ?>
        <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
          <ul class="navbar-nav justify-content-xl-end justify-content-lg-between justify-content-sm-between collapseAside" style="width:100%"> 
            <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </a>
            </li>

            <!-- REPORTES --> 
             <?php $reportes = ControladorInicio::ctrReportes(); ?>
            <li class="nav-item dropdown d-flex align-items-center mx-5">
              <a href="javascript:;" class="nav-link text-body p-0" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                  <i class="fa fa-bell cursor-pointer" aria-hidden="true"></i> Reportes
                  <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><?php echo count($reportes); ?></span>
                  </a>
              <ul class="dropdown-menu dropdown-menu-end px-2 py-3 me-sm-n4" aria-labelledby="dropdownMenuButton">
                <?php
                  if(count($reportes) > 0){
                    foreach ($reportes as $key => $value) {
                      if($value["tipo"] == "Teléfono" || $value["tipo"] == "Tablet"){
                        $var1 = " IMEI: ";
                        $identificador = $value["imei"];
                      } else{
                        $var1 = " Serie: ";
                        $identificador = $value["serie"];
                      }

                      echo '<li class="mb-2" id="'.$value["dispositivo"].'">
                        <a class="dropdown-item border-radius-md" href="javascript:;">
                          <div class="d-flex py-1">
                            <div class="d-flex flex-column justify-content-center">
                              <h6 class="text-sm font-weight-normal mb-1">
                                <span class="font-weight-bold">Dispositivo dañado |</span>'.$var1.$identificador.' <i class="fa fa-copy px-2" onclick="Copiar(\''.$identificador.'\')" data-bs-toggle="tooltip" data-bs-placement="top" title="Copiar"></i>
                              </h6>
                              <p class="text-xs text-secondary mb-0 ">
                                '.$value["tipo"].' '.$value["marca"].' '.$value["modelo"].'
                              </p>
                              <p class="text-xs text-secondary mb-0 ">
                                Asignada a: '.$value["responsable"].'
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>';
                    }
                  } else{
                    echo '<li class="mb-2"">
                          <a class="dropdown-item border-radius-md" href="javascript:;">
                            <div class="d-flex py-1">
                              <div class="d-flex flex-column justify-content-center">
                                <p class="text-xs text-secondary mb-0 ">
                                  No hay información para mostrar.
                                </p>
                              </div>
                            </div>
                          </a>
                        </li>';
                  }
                ?>
              </ul>
            </li>

            <!-- Informacion de perfil de usuario -->
            <li class="nav-item dropdown dropdown-toggle pe-2 d-flex align-items-center navPerfil">
              <a href="javascript:;" class="nav-link text-body p-0 dropdownCambioPassword" id="dropdownCambioPassword" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling">
                  <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION["nombre"]; ?></span>
                  <?php
                    $admin = ControladorAdministradores::ctrMostrarAdministradores('id', $_SESSION["id"]);
                    echo '<img src="'.$url.'vistas/assets/img/'.$admin["foto"].'" class="card-img-top imgPerfil" alt="Foto de perfil">';
                  ?>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar -->


    <div class="offcanvas offcanvas-end" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling" aria-labelledby="offcanvasScrollingLabel">
      <div class="offcanvas-header">
        <p class="offcanvas-title text-center text-lg text-bold" id="offcanvasScrollingLabel" style="width:100%">Información de usuario</p>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"><i class="fa fa-times text-danger"></i></button>
      </div>
      <div class="offcanvas-body text-center d-flex justify-content-center">
        <?php include "header/perfilUsuario.php"; ?>
      </div>
    </div>
