<?php 
 
require_once "conexion.php";

class ModeloFaltantes{

    //PARA LA DATA DE LA TABLA
    static public function mdlMostrarFaltantes($tabla, $item, $valor){

        $sqlSedesAdmin = "SELECT sedesadmin FROM administradores WHERE id = ?";
        $sedesStmt = Conexion::conectar()->prepare($sqlSedesAdmin);
        $sedesStmt->execute([$_SESSION["id"]]);
        $result = $sedesStmt->fetch(PDO::FETCH_ASSOC);

        $sedesadmin = [];

        if ($result && !empty($result['sedesadmin'])) {
            $decoded = json_decode($result['sedesadmin'], true);
            if (is_array($decoded)) {
                $sedesadmin = array_map('intval', $decoded);
            }
        }

        $sedeClause = '';
        if ($_SESSION["perfil"] != "1" && !empty($sedesadmin)) {
            $ids = implode(',', $sedesadmin); 
            $sedeClause = "AND d.sededispositivo IN ($ids)";
        }

        $sql = "SELECT 
                    c.nombreconsultor AS consultor, 
                    s.nombresede AS sede, 
                    d.tipodispositivo AS dispositivo, 
                    d.imeidispositivo AS imei, 
                    d.seriedispositivo AS serie, 
                    r.id AS idregistro, 
                    r.fecha_asignacion AS fecha_asignacion, 
                    r.fecha_recepcion AS fecha_recepcion, 
                    r.accesorios_entregados AS entregado, 
                    r.accesorios_recuperados AS recuperado, 
                    r.comentario AS comentario, 
                    CONCAT('[', r.accesorios_entregados, ',', r.accesorios_recuperados, ']') AS acc  
                FROM $tabla r 
                INNER JOIN consultores c ON c.idconsultor = r.usuario_campo_id 
                INNER JOIN sedes s ON s.idsede = r.sede_id 
                INNER JOIN dispositivos d ON d.iddispositivo = r.dispositivo_id 
                WHERE r.accesorios_entregados <> r.accesorios_recuperados 
                    AND r.fecha_recepcion IS NOT NULL 
                    $sedeClause";

        $stmt = Conexion::conectar()->prepare($sql);

        if ($stmt->execute()) {
            return $stmt->fetchAll();
        } else {
            return ["Error" => "No ha sido posible obtener la información"];
        }


        /* $sede = "AND d.sededispositivo =".$_SESSION["sedeasignada"];
        $agregar = $_SESSION["perfil"] == "1" ? "" : $sede;
        //$sql = "SELECT * FROM $tabla WHERE accesorios_entregados <> accesorios_recuperados";
        $sql = "SELECT c.nombreconsultor as consultor, s.nombresede as sede, d.tipodispositivo as dispositivo, d.imeidispositivo as imei, d.seriedispositivo as serie, r.id as idregistro, r.fecha_asignacion as fecha_asignacion, r.fecha_recepcion as fecha_recepcion, r.accesorios_entregados as entregado, r.accesorios_recuperados as recuperado, r.comentario as comentario, CONCAT('[', r.accesorios_entregados,',', r.accesorios_recuperados,']') as acc  FROM $tabla r 
        INNER JOIN consultores c ON c.idconsultor = r.usuario_campo_id 
        INNER JOIN sedes s ON s.idsede = r.sede_id 
        INNER JOIN dispositivos d ON d.iddispositivo = r.dispositivo_id 
        WHERE r.accesorios_entregados <> r.accesorios_recuperados AND r.fecha_recepcion IS NOT NULL $agregar";

        $stmt = Conexion::conectar()->prepare($sql);
        
        if($stmt->execute()){
            return $stmt->fetchAll();
        } else{
            return array("Error" => "No ha sido posible obtener la información");
        } */
    }

    //PARA MOSTRAR ACCESORIOS A RECUPERAR
    static public function mdlMostrarAccesoriosFaltantes($tabla, $item, $valor){
        $sql = "SELECT id, accesorios_entregados, accesorios_recuperados FROM $tabla WHERE $item = :$item";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        $stmt->execute();

        if($stmt->execute()){
            return $stmt->fetch();
        } else{
            return array("Error" => "No ha sido posible obtener la información");
        }

    }

    //PARA GUARDAR LOS ACCESORIOS RECUPERADOS
    static public function mdlRecuperarFaltantes($tabla, $item, $valor, $accesorios){

        $acc_rec = json_encode($accesorios);

        try{
            $sql = "UPDATE $tabla SET accesorios_recuperados = :accesorios_recuperados WHERE $item = :$item";
            $stmt = Conexion::conectar()->prepare($sql);
            $stmt->bindParam(":accesorios_recuperados", $acc_rec , PDO::PARAM_STR);
            $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
            
            if($stmt->execute()){
                return "ok";
            }    

        } catch(PDOException $e){
            return $e;
        }
      

    }

}