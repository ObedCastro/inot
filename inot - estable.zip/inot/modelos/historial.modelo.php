<?php

require_once "conexion.php";

class ModeloHistorial{

  static public function mdlMostrarHistorial($tabla, $imei, $serie, $inventario){

    try{
      if($imei != ""){
        $sqldispositivo = "SELECT * FROM dispositivos WHERE imeidispositivo = '$imei'";
      } else if($serie != ""){
        $sqldispositivo = "SELECT * FROM dispositivos WHERE seriedispositivo = '$serie'";
      } else if($inventario != ""){
        $sqldispositivo = "SELECT * FROM dispositivos WHERE inventariodispositivo = '$inventario'";
      }
  
      
        $sql = "SELECT r.*, c.nombreconsultor, c.cargoconsultor, c.estatusconsultor, CONCAT(s.nombresede,', ',s.departamentosede) as sede FROM $tabla r 
        INNER JOIN dispositivos d ON r.dispositivo_id = d.iddispositivo 
        INNER JOIN consultores c ON r.usuario_campo_id = c.idconsultor
        INNER JOIN sedes s ON c.sedeconsultor = s.idsede
        WHERE 1=1";
  
        if($imei != ""){
          $sql .= " AND d.imeidispositivo = '$imei'";
        } else if($serie != ""){
          $sql .= " AND d.seriedispositivo = '$serie'";
        } else if($inventario != ""){
          $sql .= " AND d.inventariodispositivo = '$inventario'";
        }
  
        $sql .= " ORDER BY r.fecha_asignacion DESC";
  
        $stmtdispositivo = Conexion::conectar()->prepare($sqldispositivo);
        $stmt = Conexion::conectar()->prepare($sql);
  
        $stmtdispositivo->execute();
        $stmt->execute();
  
        return array($stmtdispositivo->fetch(), $stmt->fetchAll());
    } catch(PDOException $e){
      return "Error: ".$e;
    }
  }

}
