<?php
require_once "conexion.php";

class ModeloInicio{

    //MUESTRA LOS REPORTES DE DAÑOS DE DMC
    static public function mdlReportes($tabla){
      if($_SESSION["perfil"] != "1"){
        $sqlSedesAdmin = "SELECT sedesadmin FROM administradores WHERE id = ?";
        $sedesStmt = Conexion::conectar()->prepare($sqlSedesAdmin);
        $sedesStmt->execute([$_SESSION["id"]]);
        $result = $sedesStmt->fetch(PDO::FETCH_ASSOC);

        $sedesadmin = [];

        if ($result && !empty($result['sedesadmin'])) {
            $decoded = json_decode($result['sedesadmin'], true);
            if (is_array($decoded)) {
                $sedesadmin = array_map('intval', $decoded);
            }
        }

        $sedeClause = '';
        if ($_SESSION["perfil"] != "1" && !empty($sedesadmin)) {
            $ids = implode(',', $sedesadmin); 
            $sedeClause = "AND r.sede_id IN ($ids)";
        }

        $sql = "SELECT 
                    r.nombre_asignador AS asignador, 
                    r.nombre_receptor AS receptor, 
                    r.sede_id AS sede, 
                    r.dispositivo_id AS dispositivo, 
                    d.tipodispositivo AS tipo, 
                    d.marcadispositivo AS marca, 
                    d.modelodispositivo AS modelo, 
                    d.imeidispositivo AS imei, 
                    d.seriedispositivo AS serie, 
                    c.nombreconsultor AS responsable 
                FROM $tabla r 
                INNER JOIN dispositivos d 
                    ON d.iddispositivo = r.dispositivo_id 
                  AND r.comentario <> '' 
                INNER JOIN consultores c 
                    ON c.idconsultor = r.usuario_campo_id 
                WHERE d.estadodispositivo = '3' 
                    $sedeClause";

        /* $sql = "SELECT r.nombre_asignador as asignador, r.nombre_receptor as receptor, r.sede_id as sede, r.dispositivo_id as dispositivo, d.tipodispositivo as tipo, d.marcadispositivo as marca, d.modelodispositivo as modelo, d.imeidispositivo as imei, d.seriedispositivo as serie, c.nombreconsultor as responsable FROM $tabla r INNER JOIN dispositivos d ON d.iddispositivo = r.dispositivo_id AND r.comentario <> '' INNER JOIN consultores c ON c.idconsultor = r.usuario_campo_id WHERE d.estadodispositivo = '3' and r.sede_id = ".$_SESSION["sedeasignada"]; */
        
      } else{
        $sql = "SELECT r.nombre_asignador as asignador, r.nombre_receptor as receptor, r.sede_id as sede, r.dispositivo_id as dispositivo, d.tipodispositivo as tipo, d.marcadispositivo as marca, d.modelodispositivo as modelo, d.imeidispositivo as imei, d.seriedispositivo as serie, c.nombreconsultor as responsable FROM $tabla r INNER JOIN dispositivos d ON d.iddispositivo = r.dispositivo_id AND r.comentario <> '' INNER JOIN consultores c ON c.idconsultor = r.usuario_campo_id WHERE d.estadodispositivo = '3'";
      }

      $stmt = Conexion::conectar()->prepare($sql);
      $stmt->execute();
      return $stmt->fetchAll();
    }
 
    //OBTIENE EL TOTAL DE CADA DISPOSITIVO Y LOS QUE ESTAN ASIGNADOS ACTUALMENTE
    static public function mdlMostrarDispositivosAsignados($sede, $tabla){

      if(!empty($sede)){
        $filtro_sede = " AND sededispositivo = $sede";
      } else {
        $filtro_sede = "";
      }

      $sql1 = "SELECT COUNT(CASE WHEN estadodispositivo = 2 THEN 1 END) as telefonosAsignados, COUNT(tipodispositivo) as totalTelefonos FROM $tabla WHERE tipodispositivo='Teléfono'".$filtro_sede;
      $stmt1 = Conexion::conectar()->prepare($sql1);
      $stmt1->execute();

      $sql2 = "SELECT COUNT(CASE WHEN estadodispositivo = 2 THEN 1 END) as tabletsAsignadas, COUNT(tipodispositivo) as totalTablets FROM $tabla WHERE tipodispositivo='Tablet'".$filtro_sede;
      $stmt2 = Conexion::conectar()->prepare($sql2);
      $stmt2->execute();

      $sql3 = "SELECT COUNT(CASE WHEN estadodispositivo = 2 THEN 1 END) as laptopsAsignadas, COUNT(tipodispositivo) as totalLaptops FROM $tabla WHERE tipodispositivo='Laptop'".$filtro_sede;
      $stmt3 = Conexion::conectar()->prepare($sql3);
      $stmt3->execute();

      $sql4 = "SELECT COUNT(tipodispositivo) as totalInventario FROM $tabla WHERE '1' = '1'".$filtro_sede;
      $stmt4 = Conexion::conectar()->prepare($sql4);
      $stmt4->execute();

      return array($stmt1->fetch(), $stmt2->fetch(), $stmt3->fetch(), $stmt4->fetch());
    }

    //OBTIENE EL TOTAL DE DISPOSITIVOS POR DEPARTAMENTO
    static public function mdlMostrarDispositivosDepartamento($tabla){
      $sql = "SELECT s.departamentosede AS departamento, count(d.tipodispositivo) as total FROM dispositivos d
      INNER JOIN sedes s ON d.sededispositivo = s.idsede GROUP BY s.departamentosede ORDER BY s.departamentosede";
      //$sql = "SELECT count(tipodispositivo) as total FROM $tabla group by sededispositivo order by sededispositivo";
      $stmt = Conexion::conectar()->prepare($sql);
      $stmt->execute();

      return $stmt->fetchAll();
    }

    //OBTIENE EL TOTAL DE DISPOSITIVOS POR REGIÓN
    static public function mdlMostrarDispositivosRegion($tabla){
      $sql = "SELECT s.departamentosede as departamento, s.regionsede AS region, count(d.tipodispositivo) as total FROM dispositivos d
      INNER JOIN sedes s ON d.sededispositivo = s.idsede GROUP BY s.regionsede, s.departamentosede ORDER BY s.regionsede, s.departamentosede";
      //$sql = "SELECT count(tipodispositivo) as total FROM $tabla group by sededispositivo order by sededispositivo";
      $stmt = Conexion::conectar()->prepare($sql);
      $stmt->execute();

      return $stmt->fetchAll();
    }

    //OBTIENE CANTIDAD DE DISPOSITIVOS POR SEDE
    static public function mdlMostrarDispositivosSede($tabla, $item, $valor){
      $sql = "SELECT count(d.tipodispositivo) as cantidad, d.tipodispositivo AS tipo, s.nombresede as sede FROM $tabla d INNER JOIN sedes s ON s.idsede = d.sededispositivo WHERE $item = :$item GROUP BY d.tipodispositivo, s.nombresede";

      $stmt = Conexion::conectar()->prepare($sql);
      $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
      $stmt->execute();

      return $stmt->fetchAll();
    }

    /* OBTIENE LA CANTIDAD DE ACCESORIOS ASIGNADOS ACTUALMENTE */
    static public function mdlCantidadAccesoriosAsignados($sede, $tabla){
      $sql = "SELECT accesorios FROM $tabla WHERE sededispositivo = :sededispositivo AND estadodispositivo = '2' AND accesorios IS NOT NULL";
      $stmt = Conexion::conectar()->prepare($sql);
      $stmt->bindParam(":sededispositivo", $sede, PDO::PARAM_STR);
      $stmt->execute();

      return $stmt->fetchAll();
    }

    //OBTIENE LOS VALORES PARA ALIMENTAR EL GRAFICO DE LINEAS
    static public function mdlMostrarGraficoLineas($sede, $tabla){
      if(!empty($sede)){
        $filtro_sede = " AND sededispositivo = $sede";
      } else{
        $filtro_sede = "";
      }

      $sql = "SELECT count(tipodispositivo) AS total, MONTH(fechaasignacion) AS mes FROM $tabla WHERE fechaasignacion >= CURDATE() - INTERVAL 6 MONTH AND estadodispositivo = '2' $filtro_sede GROUP BY mes ORDER BY mes";
      $stmt = Conexion::conectar()->prepare($sql);
      $stmt->execute();

      return $stmt->fetchAll();
    }
    
    //OBTIENE LOS VALORES PARA ALIMENTAR EL GRAFICO DE BARRAS
    static public function mdlMostrarGraficoBarras($sede, $tabla){
      
      if(!empty($sede)){
        $filtro_sede = " WHERE sededispositivo = $sede";
      } else{
        $filtro_sede = "";
      }

      $sql = "SELECT count(modelodispositivo) as total, modelodispositivo FROM $tabla $filtro_sede group by modelodispositivo order by modelodispositivo";
      $stmt = Conexion::conectar()->prepare($sql);
      $stmt->execute();

      return $stmt->fetchAll();
    }

    //OBTIENE LOS VALORES PARA ALIMENTAR EL GRÁFICO DE DONAS
    static public function mdlMostrarGraficoDonas($tabla){
      $sql = "SELECT COUNT(d.sededispositivo) AS cantidad, s.nombresede AS sede FROM $tabla d INNER JOIN sedes s ON s.idsede =  d.sededispositivo GROUP BY d.sededispositivo";

      $stmt = Conexion::conectar()->prepare($sql);
      $stmt->execute();
      
      return $stmt->fetchAll();
    }

    //MOSTRAR ULTIMOS 10 MOVIMIENTOS REALIZADOS CON DISPOSITIVOS
    static public function mdlMostrarUltimosMovimientos($tabla, $item, $valor, $sede){ 
      if($item != null){
        $sql = "SELECT r.*, c.nombreconsultor as consultor FROM $tabla r INNER JOIN consultores c ON r.usuario_campo_id = c.idconsultor WHERE r.$item = :$item order by r.fecha_modificacion DESC LIMIT 10";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetchAll();

      } else if($sede != null){
        $sql = "SELECT * FROM $tabla WHERE sede_id = :sede_id order by fecha_modificacion DESC LIMIT 5";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":sede_id", $sede, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetchAll();
        
      } else{
        $sql = "SELECT * FROM $tabla order by fecha_modificacion DESC LIMIT 5";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
      }

    }

}

