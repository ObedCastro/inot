$("#formBuscarhistorial").on("submit", function(e){
    e.preventDefault();

    var busqueda_imei = $("#historialImei").val();
    var busqueda_serie = $("#historialSerie").val();
    var busqueda_inventario = $("#historialInventario").val();

    $.ajax({
        url: localhost+'ajax/historial.ajax.php',
        type: 'POST',
        data: {
            imei: busqueda_imei,
            serie: busqueda_serie,
            inventario: busqueda_inventario
        },
        success: function(respuesta) {
            var datos = JSON.parse(respuesta);
            $("#mostrarTipoDispositivo").text(datos[0].tipodispositivo);
            $("#mostrarMarcaDispositivo").text(datos[0].marcadispositivo);
            $("#mostrarModeloDispositivo").text(datos[0].modelodispositivo);
            $("#mostrarImeiDispositivo").text(datos[0].imeidispositivo);
            $("#mostrarSerieDispositivo").text(datos[0].seriedispositivo);
            $("#mostrarInventarioDispositivo").text(datos[0].inventariodispositivo);
            $("#mostrarHostnameDispositivo").text(datos[0].hostnamedispositivo);
            $("#mostrarTelefonoDispositivo").text(datos[0].telefonodispositivo);
            $("#fechaRegistro").text(datos[0].fecharegistro);
            $("#fechaModificacion").text(datos[0].fechamodificacion);

            console.log(datos);
            
            if(datos[1] != ""){

                $(".historial-timeline").empty();
    
                datos[1].forEach(datos => {
                    var dateParts = datos.fecha_asignacion.split(" ")[0].split("-");
                    var formattedDate = dateParts[2] + "/" + dateParts[1] + "/" + dateParts[0];
    
                    var estatusconsultor = "";
                    switch(datos.estatusconsultor){
                        case "1": estatusconsultor = "Consultor BID"; break;
                        case "2": estatusconsultor = "Banco Central de Reserva"; break;
                        case "3": estatusconsultor = "ONEC"; break;
                        case "4": estatusconsultor = "Consultor"; break;
                        default: estatusconsultor = "";
                    }
    
                    if(datos.fecha_recepcion != null){
                        $(".historial-timeline").append(
                            '<div class="timeline-contenedor mb-3"><span class="timeline-date">'+
                            '<span class="badge text-bg-primary">'+formattedDate+'</span>'+
                            '</span>'+
                            '<div class="timeline-block">'+
                                '<span class="timeline-step">'+
                                    '<i class="ni ni-bell-55 text-success text-gradient"></i>'+
                                '</span>'+
                                '<div class="timeline-content">'+
                                    '<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Recepción</p>'+
                                    '<h6 class="text-dark text-sm font-weight-bold mb-0">'+datos.nombre_receptor+' ha realizado la recepción de este dispositivo, del usuario '+datos.nombreconsultor+' ('+estatusconsultor+'), destacado en la sede '+datos.sede+', con el cargo de '+datos.cargoconsultor+'.</h6>'+
                                    '<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">'+datos.fecha_recepcion+'</p>'+
                                '</div>'+
                            '</div></div>'
                        );
                    }
    
                    $(".historial-timeline").append(
                        '<div class="timeline-contenedor mb-3"><span class="timeline-date">'+
                        '<span class="badge text-bg-primary">'+formattedDate+'</span>'+
                        '</span>'+
                        '<div class="timeline-block">'+
                            '<span class="timeline-step">'+
                                '<i class="ni ni-bell-55 text-success text-gradient"></i>'+
                            '</span>'+
                            '<div class="timeline-content">'+
                                '<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Asignación</p>'+
                                '<h6 class="text-dark text-sm font-weight-bold mb-0">'+datos.nombre_asignador+' ha realizado la asignación de este dispositivo, del usuario '+datos.nombreconsultor+' ('+estatusconsultor+'), destacado en la sede '+datos.sede+', con el cargo de '+datos.cargoconsultor+'.</h6>'+
                                '<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">'+datos.fecha_asignacion+'</p>'+
                            '</div>'+
                        '</div></div>'
                    );
    
                });
            } else{
                $(".historial-timeline").empty();
                $(".historial-timeline").append('<span class="badge text-bg-secondary mt-2">Sin historial para este dispositivo.<span>');
                
            }
        }
    });
})