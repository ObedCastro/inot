/* la variable "localhost" está definida en el archivo base */

//Traducir datatable 
var tabla = $('#datatableConsultores').DataTable({
    "ajax": "ajax/tablaConsultores.ajax.php",
    "deferRender": true,
    "retrieve": true,
    "processing": true,
    language: {
        "decimal": "",
        "emptyTable": "No hay información",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
        "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
        "infoFiltered": "(Filtrado de _MAX_ total entradas)",
        "infoPostFix": "",
        "thousands": ",",
        "lengthMenu": "Mostrar _MENU_ Entradas",
        "loadingRecords": "Cargando...",
        "processing": "Procesando...",
        "search": "Buscar:",
        "zeroRecords": "Sin resultados encontrados",
        "paginate": {
            "first": "Primero",
            "last": "Ultimo",
            "next": "Siguiente",
            "previous": "Anterior"
        }
    }
});

/* PARA REGISTRAR NUEVO CONSULTOR */
$("#formNuevoConsultor").on("submit", function(e){

    e.preventDefault();
    var datos = $("#formNuevoConsultor").serialize();

    /* console.log(datos); */

    $.ajax({
        url: localhost + "ajax/consultores.ajax.php",
        method: "POST",
        data: datos,
        dataType: "json",
        success: function(respuesta){
            Swal.fire({
                position: "center",
                icon: respuesta.icono,
                title: respuesta.titulo,
                text: respuesta.mensaje,
                showConfirmButton: false,
                timer: 1500
              });

              $("#modalConsultores").modal("hide");
              tabla.ajax.reload();
        }
    });

});


//MUESTRA INFORMACIÓN DEL CONSULTOR, ANTES DE MODIFICAR
$(".tablaConsultores").on("click", ".btnEditarConsultor", function(){
    var idEditarConsultor = $(this).attr("idEditarConsultor");

    var datos = new FormData();
    datos.append("idEditarMostrar", idEditarConsultor);

    $.ajax({
        url: localhost + "ajax/consultores.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta){
            $("#editarNombreConsultor").val(respuesta.nombreconsultor);
            $("#editarDuiConsultor").val(respuesta.duiconsultor);
            $("#editarCargoConsultor").val(respuesta.cargoconsultor);
            $("#editarContactoConsultor").val(respuesta.contactoconsultor);
            $("#editarSedeConsultor").val(respuesta.sedeconsultor);
            $("#idEditarConsultor").val(respuesta.idconsultor);
        }
    })
});

//PARA MODIFICAR LA INFORMACIÓN DEL CONSULTOR
$("#formEditarConsultor").on("submit", function(e){
    e.preventDefault();
    var datosec = $("#formEditarConsultor").serialize();

    /* console.log(datosec); */

    $.ajax({
        url: localhost + "ajax/consultores.ajax.php",
        method: "POST",
        data: datosec,
        dataType: "json",
        success: function(respuesta){
            Swal.fire({
                position: "center",
                icon: respuesta.icono,
                title: respuesta.titulo,
                text: respuesta.mensaje,
                showConfirmButton: false,
                timer: 1500
              });

              $("#modalEditarConsultores").modal("hide");
              tabla.ajax.reload();
        }
    });
});


/* ELIMINAR CONSULTORES */
$(".tablaConsultores").on("click", ".btnEliminarConsultor", function(){
    Swal.fire({
        title: "Eliminar consultor",
        text: "¿Está seguro que desea eliminar este consultor?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Sí, eliminar",
        cancelButtonText: "Cancelar",
      }).then((result) => {
        if (result.isConfirmed) {
            var idEliminarConsultor = $(this).attr("idEliminarConsultor");

            var datos = new FormData();
            datos.append("idEliminarConsultor", idEliminarConsultor);

            $.ajax({
                url: localhost + "ajax/consultores.ajax.php",
                method: "POST",
                data: datos,
                cache: false,
                contentType: false,
                processData: false,
                dataType: "json",
                success: function(respuesta){
                    var icono = respuesta.success ? "success" : "error";
                    var mensaje = respuesta.success ? respuesta.success : respuesta.error;
                    Swal.fire({
                        position: "center",
                        icon: icono,
                        title: mensaje,
                        showConfirmButton: false,
                        timer: 1500
                      });

                      tabla.ajax.reload();
                },
                error: function(res){
                    Swal.fire({
                        position: "center",
                        icon: "error",
                        title: "No se pudo ejecutar la instrucción",
                        showConfirmButton: false,
                        timer: 1500
                      });
                }
            })
        }
      });
});



// VALIDACIÓN DE CAMPOS PARA NUEVO REGISTRO
(function () {
    'use strict'

      //Resetear formularios de modal, en cuanto el modal se oculte
      $("#modalConsultores").on("hidden.bs.modal", function () {
        $(this).find('form')[0].reset();
      });

    var forms = document.querySelectorAll('.needs-validation')

    Array.prototype.slice.call(forms).forEach(function (form) {
      function handleButtonClick(event) {
        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
          }
          form.classList.add('was-validated');
        }

        form.addEventListener('submit', handleButtonClick);

        function handleModalClose(){
          form.classList.remove('was-validated');
        }

        document.getElementById('modalConsultores').addEventListener('hidden.bs.modal', handleModalClose);
      })
  })();


//-------------------------------------------------------------------------------------------------------------
//CARGAR DATOS DE CONSULTORES DESDE CSV

$('#cargarDataConsultores').on('submit', function(e){
    e.preventDefault();
    var formData = new FormData(this);

    $.ajax({
        url: localhost + 'ajax/cargarDataConsultores.ajax.php',
        type: 'POST',
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta){
            Swal.fire({
                title: respuesta.titulo,
                text: respuesta.mensaje + " " + respuesta.cantidad+"/"+respuesta.total,
                icon: respuesta.icono,
                confirmButtonText: "Ok"
              }).then((result) => {
                if(result.isConfirmed){
                    parent.window.location.reload();
                }
              });
              
            $("#modalCargarDataConsultores").empty();
            $("#modalCargarDataConsultores").hide();
            tabla.ajax.reload();
        },
        error: function(){
            Swal.fire({
                title: "Atención",
                text: "Error, el archivo seleccionado no contiene el formato esperado.",
                icon: "error",
                confirmButtonText: "Ok"
              });
        }
    });
});

$(".btn_refreshC").click(function(){
  parent.window.location.reload();
});


//--------------------------------------------------------------------------------------------------------------
//DESCARGAR FORMATO EN CSV DE CONSULTORES
$("#btnFormatoConsultores").click(function(){
  let contenidoCSV = "data:text/csv;charset=utf-8,\uFEFF";
  contenidoCSV += "NOMBRE DEL CONSULTOR;DUI;CARGO;TELÉFONO;SEDE\n";
  contenidoCSV += "Obed Alberto Castro Orellana;12345678-9;Técnico de Soporte Informático;11112222;1\n";

  const encodedUri = encodeURI(contenidoCSV);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", "formato_consultores.csv");

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
});