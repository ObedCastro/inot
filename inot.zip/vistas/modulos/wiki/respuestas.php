<div class="modal fade" id="modalRespuestasWiki" tabindex="-1" aria-labelledby="modalRespuestasWikiLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
    <div class="modal-content respuestas">
      <div class="modal-header text-center bg-primary">
        <h5 class="modal-title text-white" id="modalRespuestasWikiLabel">COLABORACIONES</h5>
        <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
      </div>
      <div class="modal-body bodyModal">
        
        <div class="container text-center">
            <div class="container encabezadoProblema">
                <p class="text-lg tituloProblema mb-0 text-bold"></p><hr class="bg-secondary">
                <p class="descripcionProblema"></p>
            </div>
            <div class="container">
                <p class="mb-0 badge text-primary">SOLUCIÓN PROPUESTA</p>
                <div class="container solucionpropuesta">
                    <p class="solucionProblema mt-2 text-bold"></p>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="text-center">
                <!-- <p class="text-primary" data-bs-toggle="collapse" data-bs-target="#collapseWidthExample" aria-expanded="false" aria-controls="collapseWidthExample">Otros aportes <i class="fa fa-arrow-down" aria-hidden="true"></i></p> -->

                <button type="button" class="btn btn-primary position-relative" data-bs-toggle="collapse" data-bs-target="#collapseWidthExample" aria-expanded="false" aria-controls="collapseWidthExample">
                  Otros aportes <i class="fa fa-arrow-down" aria-hidden="true"></i>
                  <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    <span class="cantidad-aportes fs-6"></span>
                  </span>
                </button>
            </div>
            <div class="how-section1 collapse" id="collapseWidthExample">
                
            </div>

            <form method="post" id="formNuevaColaboracion">
                <input type="hidden" name="idWikiColabora" id="idWikiColabora">

                <?php
                  if($_SESSION["perfil"] != "3"){
                    echo '<div class="mb-2 row">
                        <label class="form-label col-md-12">Dar un aporte
                            <textarea style="height: 100px" class="form-control" placeholder="Detalle la solución que plantea." name="taColaboracion" id="taColaboracion" required></textarea>
                        </label>
                    </div>';
                  }
                ?>

                <div class="text-end">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
      </div>

      
    </div>
  </div>
</div>

