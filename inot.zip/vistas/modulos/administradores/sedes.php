<div class="modal fade" id="modalSedes" aria-hidden="true" aria-labelledby="modalSedesLabel" tabindex="-1">
  <div class="modal-dialog modal-dialog-scrollable modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h1 class="modal-title fs-5 text-white" id="modalSedesLabel"><i class="fa fa-gears"></i> GESTIONAR</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center">
        
      </div>
    </div>
  </div>
</div>

<!-- Modal para agregar una nueva sede -->
<div class="modal fade" id="modalNuevaSede" tabindex="-1" aria-labelledby="modalNuevaSedeLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h1 class="modal-title fs-5 text-white" id="modalNuevaSedeLabel">Registrar nueva sede</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <form method="POST" id="formularioNuevaSede" class="needs-validation" novalidate>
            <input type="hidden" value="nuevasede" name="nuevasede">
          <div class="row container">
              <label for="nombresede" class="form-label">Nombre de la sede <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="nombresede" name="nombresede" minlength="10" maxlength="100" required>
              <div class="invalid-feedback">El nombre de la sede es requerido</div>

              <label for="departamento" class="form-label pt-4">Departamento <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="departamento" name="departamento" required>
              <div class="invalid-feedback">El departamento es requerido</div>
          </div>

          <div class="text-end py-3">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary" name="opcion">Guardar</button>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

<!-- Modal para agregar un nuevo tipo de dispositivo -->
<div class="modal fade" id="modalNuevoTipo" tabindex="-1" aria-labelledby="modalNuevoTipoLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h1 class="modal-title fs-5 text-white" id="modalNuevoTipoLabel">Registrar nuevo tipo de dispositivo</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <form method="POST" id="formularioNuevoTipo" class="needs-validation" novalidate>
            <input type="hidden" value="nuevotipo" name="nuevotipo">
          <div class="row container">
              <label for="nombretipo" class="form-label">Tipo de dispositivo <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="nombretipo" name="nombretipo" minlength="5" maxlength="50" required>
              <div class="invalid-feedback">El nombre del tipo de dispositivo es requerido</div>
          </div>

          <div class="text-end py-3">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary" name="opcion">Guardar</button>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

<!-- Modal para agregar un nueva marca de dispositivo -->
<div class="modal fade" id="modalNuevaMarca" tabindex="-1" aria-labelledby="modalNuevaMarcaLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h1 class="modal-title fs-5 text-white" id="modalNuevaMarcaLabel">Registrar nueva marca de dispositivo</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <form method="POST" id="formularioNuevaMarca" class="needs-validation" novalidate>
            <input type="hidden" value="nuevamarca" name="nuevamarca">
          <div class="row container">
              <label for="nombremarca" class="form-label">Tipo de dispositivo <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="nombremarca" name="nombremarca" minlength="5" maxlength="30" required>
              <div class="invalid-feedback">El nombre de la marca de dispositivo es requerido</div>
          </div>

          <div class="text-end py-3">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary" name="opcion">Guardar</button>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

<!-- Modal para agregar un nuevo modelo de dispositivo -->
<div class="modal fade" id="modalNuevoModelo" tabindex="-1" aria-labelledby="modalNuevoModeloLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h1 class="modal-title fs-5 text-white" id="modalNuevoModeloLabel">Registrar nuevo modelo de dispositivo</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <form method="POST" id="formularioNuevoModelo" class="needs-validation" novalidate>
            <input type="hidden" value="nuevomodelo" name="nuevomodelo">
          <div class="row container">
              <label for="nombremodelo" class="form-label">Modelo de dispositivo <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="nombremodelo" name="nombremodelo" minlength="3" maxlength="50" required>
              <div class="invalid-feedback">El nombre de modelo de dispositivo es requerido</div>
          </div>

          <div class="text-end py-3">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary" name="opcion">Guardar</button>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>