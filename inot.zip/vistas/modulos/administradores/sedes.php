<div class="modal fade" id="modalSedes" aria-hidden="true" aria-labelledby="modalSedesLabel" tabindex="-1">
  <div class="modal-dialog modal-dialog-scrollable modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h1 class="modal-title fs-5 text-white" id="modalSedesLabel">GESTIONAR</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center">

        <!-- Nav tabs -->
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="sedes-tab" data-bs-toggle="tab" data-bs-target="#sedes" type="button" role="tab" aria-controls="sedes" aria-selected="true">Sedes</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tipos-tab" data-bs-toggle="tab" data-bs-target="#tipos" type="button" role="tab" aria-controls="tipos" aria-selected="false">Tipos de dispositivos</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="marcas-tab" data-bs-toggle="tab" data-bs-target="#marcas" type="button" role="tab" aria-controls="marcas" aria-selected="false">Marcas de dispositivos</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="modelos-tab" data-bs-toggle="tab" data-bs-target="#modelos" type="button" role="tab" aria-controls="modelos" aria-selected="false">Modelos de dispositivos</button>
            </li>
        </ul>

        <!-- Tab panes -->
        <div class="tab-content py-2">
            <div class="tab-pane active" id="sedes" role="tabpanel" aria-labelledby="sedes-tab">
                <button class="btn btn-success" data-bs-target="#modalNuevaSede" data-bs-toggle="modal"><i class="fa fa-plus"></i> Agregar nueva sede</button>
                <div class="table-responsive px-4">
                    <table id="" class="table align-items-center mb-0 tablaSede">
                        <thead>
                            <tr class="tabla-datos">
                            <th class="text-uppercase text-secondary text-xs font-weight-bolder">#</th>
                            <th class="text-uppercase text-secondary text-xs font-weight-bolder ps-2">Nombre de sede</th>
                            <th class="text-uppercase text-secondary text-xs font-weight-bolder ps-2">Departamento</th>
                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder">Acción</th>
                            </tr>
                        </thead>
            
                        <tbody>
                                <?php 
                                    $sedes = ControladorAdministradores::ctrMostrarSedes(null, null);
                                    foreach ($sedes as $key => $sede) {
                                        echo '<tr>';
                                        echo '<td>'.$sede["idsede"].'</td>';
                                        echo '<td>'.$sede["nombresede"].'</td>';
                                        echo '<td>'.$sede["departamentosede"].'</td>';
                                        echo '<td><i data-bs-toggle="tooltip" data-bs-placement="top" title="Eliminar este registro" class="fa fa-trash btnEliminarSede" idEliminarSede="'.$sede["idsede"].'"></i></td>';
                                        echo '</tr>';
                                    }
                                ?>
                        </tbody>    
                    </table>
                    <?php
                      if(empty($sedes) || $sedes == null){
                        echo '<div class="text-secondary">Aún no hay información para mostrar.</div>';
                      }
                    ?>
                </div>
            </div>

            <div class="tab-pane" id="tipos" role="tabpanel" aria-labelledby="tipos-tab">
                <button class="btn btn-success" data-bs-target="#modalNuevoTipo" data-bs-toggle="modal"><i class="fa fa-plus"></i> Agregar tipo</button>
                <div class="table-responsive px-4">
                    <table id="" class="table align-items-center mb-0 tablaTipo">
                        <thead>
                            <tr class="tabla-datos">
                            <th class="text-uppercase text-secondary text-xs font-weight-bolder">#</th>
                            <th class="text-uppercase text-secondary text-xs font-weight-bolder ps-2">Tipo de dispositivo</th>
                            <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder">Acción</th>
                            </tr>
                        </thead>
            
                        <tbody>
                                <?php 
                                    $tipos = ControladorAdministradores::ctrMostrarTipos(null, null);
                                    foreach ($tipos as $key => $tipo) {
                                        echo '<tr>';
                                        echo '<td>'.$tipo["idtipo"].'</td>';
                                        echo '<td>'.$tipo["nombretipo"].'</td>';
                                        echo '<td><i data-bs-toggle="tooltip" data-bs-placement="top" title="Eliminar este registro" class="fa fa-trash btnEliminarTipo" idEliminarTipo="'.$tipo["idtipo"].'"></i></td>';
                                        echo '</tr>';
                                    }
                                ?>
                        </tbody>    
                    </table>
                    <?php 
                      if(empty($tipos) || $tipos == null){
                        echo '<div class="text-secondary">Aún no hay información para mostrar.</div>';
                      }
                    ?>
                </div>
            </div>

            <div class="tab-pane" id="marcas" role="tabpanel" aria-labelledby="marcas-tab">
                <button class="btn btn-success" data-bs-target="#modalNuevaMarca" data-bs-toggle="modal"><i class="fa fa-plus"></i> Agregar Marca</button>
                <div class="table-responsive px-4">
                    <table id="" class="table align-items-center mb-0 tablaMarca">
                        <thead>
                            <tr class="tabla-datos">
                              <th class="text-uppercase text-secondary text-xs font-weight-bolder">#</th>
                              <th class="text-uppercase text-secondary text-xs font-weight-bolder ps-2">Marca de dispositivo</th>
                              <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder">Acción</th>
                            </tr>
                        </thead>
            
                        <tbody>
                                <?php 
                                    $marcas = ControladorAdministradores::ctrMostrarMarcas(null, null);
                                      foreach ($marcas as $key => $marca) {
                                          echo '<tr>';
                                          echo '<td>'.$marca["idmarca"].'</td>';
                                          echo '<td>'.$marca["nombremarca"].'</td>';
                                          echo '<td><i data-bs-toggle="tooltip" data-bs-placement="top" title="Eliminar este registro" class="fa fa-trash btnEliminarMarca" idEliminarMarca="'.$marca["idmarca"].'"></i></td>';
                                          echo '</tr>';
                                      }
                                      ?>
                        </tbody>    
                      </table>
                      <?php 
                      if(empty($marcas) || $marcas == null){
                        echo '<div class="text-secondary">Aún no hay información para mostrar.</div>';
                      }
                    ?>
                </div>
            </div>

            <div class="tab-pane" id="modelos" role="tabpanel" aria-labelledby="modelos-tab">
                <button class="btn btn-success" data-bs-target="#modalNuevoModelo" data-bs-toggle="modal"><i class="fa fa-plus"></i> Agregar Modelo</button>
                <div class="table-responsive px-4">
                    <table id="" class="table align-items-center mb-0 tablaModelo">
                        <thead>
                            <tr class="tabla-datos">
                              <th class="text-uppercase text-secondary text-xs font-weight-bolder">#</th>
                              <th class="text-uppercase text-secondary text-xs font-weight-bolder ps-2">Modelo de dispositivo</th>
                              <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder">Acción</th>
                            </tr>
                        </thead>
            
                        <tbody>
                                <?php 
                                    $modelos = ControladorAdministradores::ctrMostrarModelos(null, null);
                                    foreach ($modelos as $key => $modelo) {
                                        echo '<tr>';
                                        echo '<td>'.$modelo["idmodelo"].'</td>';
                                        echo '<td>'.$modelo["nombremodelo"].'</td>';
                                        echo '<td><i data-bs-toggle="tooltip" data-bs-placement="top" title="Eliminar este registro" class="fa fa-trash btnEliminarmodelo" idEliminarModelo="'.$modelo["idmodelo"].'"></i></td>';
                                        echo '</tr>';
                                    }
                                ?>
                        </tbody>    
                    </table>
                    <?php
                      if(empty($modelos) || $modelos == null){
                        echo '<div class="text-secondary">Aún no hay información para mostrar.</div>';
                      }
                    ?>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal para agregar una nueva sede -->
<div class="modal fade" id="modalNuevaSede" tabindex="-1" aria-labelledby="modalNuevaSedeLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h1 class="modal-title fs-5 text-white" id="modalNuevaSedeLabel">Registrar nueva sede</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <form method="POST" id="formularioNuevaSede" class="needs-validation" novalidate>
            <input type="hidden" value="nuevasede" name="nuevasede">
          <div class="row container">
              <label for="nombresede" class="form-label">Nombre de la sede <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="nombresede" name="nombresede" minlength="10" maxlength="100" required>
              <div class="invalid-feedback">El nombre de la sede es requerido</div>

              <label for="departamento" class="form-label pt-4">Departamento <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="departamento" name="departamento" required>
              <div class="invalid-feedback">El departamento es requerido</div>
          </div>

          <div class="text-end py-3">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary" name="opcion">Guardar</button>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

<!-- Modal para agregar un nuevo tipo de dispositivo -->
<div class="modal fade" id="modalNuevoTipo" tabindex="-1" aria-labelledby="modalNuevoTipoLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h1 class="modal-title fs-5 text-white" id="modalNuevoTipoLabel">Registrar nuevo tipo de dispositivo</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <form method="POST" id="formularioNuevoTipo" class="needs-validation" novalidate>
            <input type="hidden" value="nuevotipo" name="nuevotipo">
          <div class="row container">
              <label for="nombretipo" class="form-label">Tipo de dispositivo <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="nombretipo" name="nombretipo" minlength="5" maxlength="50" required>
              <div class="invalid-feedback">El nombre del tipo de dispositivo es requerido</div>
          </div>

          <div class="text-end py-3">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary" name="opcion">Guardar</button>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

<!-- Modal para agregar un nueva marca de dispositivo -->
<div class="modal fade" id="modalNuevaMarca" tabindex="-1" aria-labelledby="modalNuevaMarcaLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h1 class="modal-title fs-5 text-white" id="modalNuevaMarcaLabel">Registrar nueva marca de dispositivo</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <form method="POST" id="formularioNuevaMarca" class="needs-validation" novalidate>
            <input type="hidden" value="nuevamarca" name="nuevamarca">
          <div class="row container">
              <label for="nombremarca" class="form-label">Tipo de dispositivo <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="nombremarca" name="nombremarca" minlength="5" maxlength="30" required>
              <div class="invalid-feedback">El nombre de la marca de dispositivo es requerido</div>
          </div>

          <div class="text-end py-3">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary" name="opcion">Guardar</button>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

<!-- Modal para agregar un nuevo modelo de dispositivo -->
<div class="modal fade" id="modalNuevoModelo" tabindex="-1" aria-labelledby="modalNuevoModeloLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h1 class="modal-title fs-5 text-white" id="modalNuevoModeloLabel">Registrar nuevo modelo de dispositivo</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <form method="POST" id="formularioNuevoModelo" class="needs-validation" novalidate>
            <input type="hidden" value="nuevomodelo" name="nuevomodelo">
          <div class="row container">
              <label for="nombremodelo" class="form-label">Modelo de dispositivo <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="nombremodelo" name="nombremodelo" minlength="3" maxlength="50" required>
              <div class="invalid-feedback">El nombre de modelo de dispositivo es requerido</div>
          </div>

          <div class="text-end py-3">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary" name="opcion">Guardar</button>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>