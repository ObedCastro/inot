<div class="container-fluid py-2">

  <!-- Nav tabs -->
  <ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item" role="presentation">
      <button class="nav-link active" id="administradores-tab" data-bs-toggle="tab" data-bs-target="#administradores" type="button" role="tab" aria-controls="administradores" aria-selected="true">Usuarios</button>
    </li>
    <li class="nav-item" role="presentation">
      <button class="nav-link" id="sedes-tab" data-bs-toggle="tab" data-bs-target="#sedes" type="button" role="tab" aria-controls="sedes" aria-selected="true">Sedes</button>
    </li>
    <li class="nav-item" role="presentation">
      <button class="nav-link" id="tipos-tab" data-bs-toggle="tab" data-bs-target="#tipos" type="button" role="tab" aria-controls="tipos" aria-selected="false">Tipos de dispositivos</button>
    </li>
    <li class="nav-item" role="presentation">
      <button class="nav-link" id="marcas-tab" data-bs-toggle="tab" data-bs-target="#marcas" type="button" role="tab" aria-controls="marcas" aria-selected="false">Marcas de dispositivos</button>
    </li>
    <li class="nav-item" role="presentation">
      <button class="nav-link" id="modelos-tab" data-bs-toggle="tab" data-bs-target="#modelos" type="button" role="tab" aria-controls="modelos" aria-selected="false">Modelos de dispositivos</button>
    </li>
  </ul>

  <!-- Tab panes -->
  <div class="tab-content py-2">    
    <div class="tab-pane active" id="administradores" role="tabpanel" aria-labelledby="administradores-tab">
      <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0 d-flex justify-content-between">
              <h6></h6>
              <div class="d-flex">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalNuevoAdmin">
                <i class="fa fa-plus me-sm-1 cursor-pointer"></i>
                  Nuevo Usuario
                </button>
                <!-- <button class="btn btn-primary mx-2" type="button" data-bs-toggle="modal" data-bs-target="#modalSedes" >
                <i class="fa fa-gears mx-2"></i>
                  Otras opciones
                </button> -->
              </div>
            </div>

            <div class="card-body px-0 pt-0 pb-2 min-vh-25">
              <div class="table-responsive px-4">
                <table id="datatableAdmin" class="table align-items-center mb-0 tablaAdmin display">
                  <thead>
                    <tr>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Nombre</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Email</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Usuario</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Cargo</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Perfil</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Tipo de Contrato</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Acción</th>
                    </tr>
                  </thead>

                  <!--<tbody>
                  </tbody>-->

                </table>
              </div>
            </div>
          </div>
        </div>

      </div>   
    </div>

    <div class="tab-pane" id="sedes" role="tabpanel" aria-labelledby="sedes-tab">
      <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0 d-flex justify-content-end">
              <div class="d-flex">
                <button class="btn btn-success" data-bs-target="#modalNuevaSede" data-bs-toggle="modal"><i class="fa fa-plus"></i> Agregar nueva sede</button>
              </div>
            </div>
            
            <div class="card-body px-0 pt-0 pb-2 min-vh-25">
              <div class="table-responsive px-4">
                  <table id="datatableSedes" class="table align-items-center mb-0 tablaSede display">
                      <thead>
                          <tr class="tabla-datos">
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">#</th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Nombre de sede</th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Departamento</th>
                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder">Acción</th>
                          </tr>
                      </thead>
          
                      <!-- <tbody>
                      </tbody>  -->   
                  </table>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

    <div class="tab-pane" id="tipos" role="tabpanel" aria-labelledby="tipos-tab">
      <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0 d-flex justify-content-end">
              <div class="d-flex">
                <button class="btn btn-success" data-bs-target="#modalNuevoTipo" data-bs-toggle="modal"><i class="fa fa-plus"></i> Agregar tipo</button>
              </div>
            </div>

            <div class="card-body px-0 pt-0 pb-2 min-vh-25">
              <div class="table-responsive px-4">
                <table id="datatableTipos" class="table align-items-center mb-0 tablaTipo display">
                  <thead>
                    <tr class="tabla-datos">
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">#</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Tipo de dispositivo</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Acción</th>
                    </tr>
                  </thead>
        
                    <!-- <tbody>
                    </tbody>   -->  
                </table>
              </div>
            </div> 
          </div>
        </div>
      </div>         
    </div>

    <div class="tab-pane" id="marcas" role="tabpanel" aria-labelledby="marcas-tab">
      <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0 d-flex justify-content-end">
              <div class="d-flex">
                <button class="btn btn-success" data-bs-target="#modalNuevaMarca" data-bs-toggle="modal"><i class="fa fa-plus"></i> Agregar Marca</button>
              </div>
            </div>

            <div class="card-body px-0 pt-0 pb-2 min-vh-25">
              <div class="table-responsive px-4">
                <table id="datatableMarcas" class="table align-items-center mb-0 tablaMarca display">
                    <thead>
                        <tr class="tabla-datos">
                          <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">#</th>
                          <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Marca de dispositivo</th>
                          <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Acción</th>
                        </tr>
                    </thead>
        
                    <!-- <tbody>
                    </tbody>   -->  
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="tab-pane" id="modelos" role="tabpanel" aria-labelledby="modelos-tab">
      <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0 d-flex justify-content-end">
              <div class="d-flex">
                <button class="btn btn-success" data-bs-target="#modalNuevoModelo" data-bs-toggle="modal"><i class="fa fa-plus"></i> Agregar Modelo</button>
              </div>
            </div>

            <div class="card-body px-0 pt-0 pb-2 min-vh-25">
              <div class="table-responsive px-4">
                <table id="datatableModelos" class="table align-items-center mb-0 tablaModelo display">
                  <thead>
                    <tr class="tabla-datos">
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">#</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Modelo de dispositivo</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Acción</th>
                    </tr>
                  </thead>
      
                  <!-- <tbody>
                  </tbody>  -->   
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>

<?php
  /* Modal para registrar un nuevo administrador */
  include "vistas/modulos/administradores/nuevoAdministrador.php";

  /* Modal para modificar información de administrador */
  include "vistas/modulos/administradores/modificarAdministrador.php";

  /* Modal para registrar una nueva sede, tipo de dispositivo, marca de dispositivo y modelo de dispositivo */
  include "vistas/modulos/administradores/sedes.php";
?>
