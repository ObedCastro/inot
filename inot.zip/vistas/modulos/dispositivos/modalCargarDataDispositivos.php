<!-- Modal -->
<div class="modal fade" id="modalCargarData" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h5 class="modal-title text-white" id="exampleModalLabel">Cargar datos de dispositivos desde un CSV</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="cargarDataDispositivos" enctype="multipart/form-data">
            <div class="mb-3 text-center">
                <label for="file" class="form-label">Buscar en un directorio</label>
                <input class="form-control" type="file" id="file" name="file" accept=".csv">
            </div>

            <div class="text-center">
              <button type="button" class="btn btn-secondary btn_refresh" data-bs-dismiss="modal">Cancelar</button>
              <button type="submit" class="btn btn-primary">Cargar datos</button>
            </div>
        </form>

        <div class="text-center">
          <button type="submit" id="btnFormatoDispositivos" class="btn btn-link text-black mb-0">Descargar Formato CSV <br> <i class="fa fa-file-csv text-success fs-5"></i>
          </button><br>
          <small class="mt-0"><strong>NOTA: </strong>Eliminar el registro de ejemplo en el formato, antes de subir el archivo.</small>
        </div>

      </div>
    </div>
  </div>
</div>


