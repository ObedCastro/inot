<!-- MODAL DE DISPOSITIVOS -->
<div class="modal fade" id="modalVerDetalleDispositivo" data-bs-backdrop="static" tabindex="-1" aria-labelledby="modalVerDetalleDispositivoLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill cursor-pointer btn-cerrar-modal" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-remove text-white"></i></span>
        <h1 class="modal-title fs-5 text-white" id="modalDispositivosLabel"><i class="fa fa-info"></i> Información del dispositivo</h1>
        <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
      </div>
      <div class="modal-body">
        <div class="container">   
          <div class="">
            <div class="-body pt-4 p-3">
              <ul class="list-group">
                <div class="row d-flex justify-content-center">
                    <button class="btn btn-success col-4" id="reimprimirHoja"><i class="fa fa-print px-2 text-lg"></i> Reimprimir hoja de asignación
                      <input type="hidden" name="idReimprimir" id="idReimprimir">
                    </button>
                </div>
                <div class="row mb-3">
                  <div class="col-md-6">
                    <li class="list-group-item border-0 d-flex p-4 mb-1 bg-gray-100 border-radius-lg">
                      <div class="d-flex flex-column">
                        <p class="mb-3 text-lg font-weight-bold">DETALLES</p>
                        <span class="mb-1 text-xs">Tipo de dispositivo: <span id="mostrarTipoDispositivo" class="text-dark font-weight-bold ms-sm-2"></span></span>
                        <span class="mb-1 text-xs">Marca: <span id="mostrarMarcaDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                        <span class="mb-1 text-xs">Modelo: <span id="mostrarModeloDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                        <span class="mb-1 text-xs">IMEI: <span id="mostrarImeiDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                        <span class="mb-1 text-xs">Serie: <span id="mostrarSerieDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                        <span class="mb-1 text-xs">Número de inventario: <span id="mostrarInventarioDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                        <span class="mb-1 text-xs">Hostname: <span id="mostrarHostnameDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                        <span class="mb-1 text-xs">Teléfono: <span id="mostrarTelefonoDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                      </div>
                    </li> 

                    <li class="list-group-item border-0 d-flex p-4 mb-1 bg-gray-100 border-radius-lg">
                      <div class="d-flex flex-column">
                        <span class="mb-1 text-xs">Fecha de registro: <span id="fechaRegistro" class="text-dark font-weight-bold ms-sm-2"></span></span>
                        <span class="mb-1 text-xs">Fecha de última modificación: <span id="fechaModificacion" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                      </div>
                    </li>
                  </div>

                  <div class="col-md-6">
                    <li class="list-group-item border-0 d-flex p-4 mb-1 bg-gray-100 border-radius-lg">
                      <div class="d-flex flex-column contenedorAccesorios">
                        <p class="mb-3 text-lg font-weight-bold">Accesorios asignados al usuario</p>
                        <span class="mb-1 text-xs sin-accesorios"></span>
                        <span class="mb-1 text-xs"><i class="fa fa-check"></i> Cubo de carga <span id="checkCubo" class="text-dark font-weight-bold ms-sm-2"></span></span>
                        <span class="mb-1 text-xs"><i class="fa fa-check"></i> Cable de cargador <span id="checkCable" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                        <span class="mb-1 text-xs"><i class="fa fa-check"></i> Lápiz óptico <span id="checkLapiz" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                        <span class="mb-1 text-xs"><i class="fa fa-check"></i> Funda <span id="checkFunda" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                        <span class="mb-1 text-xs"><i class="fa fa-check"></i> Powerbank <span id="checkPowerbank"   class="text-dark ms-sm-2 font-weight-bold"></span></span>
                        <span class="mb-1 text-xs"><i class="fa fa-check"></i> Cargador <span id="checkCargadorLaptop" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                        <span class="mb-1 text-xs"><i class="fa fa-check"></i> Maletín <span id="checkMaletin" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                        <span class="mb-1 text-xs"><i class="fa fa-check"></i> Mouse <span id="checkMouse" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                        <span class="mb-1 text-xs"><i class="fa fa-check"></i> Mousepad <span id="checkMousepad" class="text-dark ms-sm-2 font-weight-bold"></span></span>
                      </div>
                    </li>
                    <li class="list-group-item border-0">
                          <div class="form-floating">
                            <textarea readonly class="form-control" placeholder="Leave a comment here" id="mostrarComentarioDispositivo" style="height: 100px"></textarea>
                            <label for="mostrarComentarioDispositivo">Comentario</label>
                          </div>                       
                    </li>
                  </div>

                  <div class="col-md-12" id="mostrarMovimientos">
                    <div class="">
                      <div class="pb-0 px-3 d-flex">
                        <h6 class="mb-0 ">Registro de este dispositivo</h6>
                      </div>           
          
                      <div class="-body p-3">
                        <div class="timeline timeline-one-side timelineHistorial">
                          <!-- Recibe elementos de JQuery -->
                        </div>
                      </div>
          
                      </div>

                  </div>
                </div>
      
              </ul>

            </div>
          </div>  
          
        </div>
      </div>

      
    </div>
  </div>
</div>



