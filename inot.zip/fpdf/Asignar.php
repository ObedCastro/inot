<?php

session_start();

include('fechaes.php');

require "../modelos/conexion.php";
require_once "../controladores/dispositivos.controlador.php";
require_once "../controladores/consultores.controlador.php";
require_once "../controladores/sedes.controlador.php";
require_once "../modelos/dispositivos.modelo.php";
require_once "../modelos/consultores.modelo.php";
require_once "../modelos/sedes.modelo.php";

require('fpdf.php');
class PDF extends FPDF
{

   //Pie de página
   function Footer()
   {
    //Posición: a 1,5 cm del final
    $this->SetY(-15);
    //Arial italic 8
    $this->SetFont('Arial','I',8);
    //Número de página
    $this->Cell(0,10,'Documento Confidencial - Pagina'.$this->PageNo().'/{nb}',0,0,'C');
   }
}


if(isset($_GET["idDispositivoAsignar"]) && isset($_GET["responsableDispositivo"])){
    $id = $_GET["idDispositivoAsignar"];
    $res = $_GET["responsableDispositivo"];
    $fecha = $_GET["fechaAsignacion"];

    date_default_timezone_set('America/El_Salvador');
    $fecha_datetime = DateTime::createFromFormat("Y-m-d", $fecha);

    $datos = array(
        "Cubo"=>isset($_GET["checkCubo"]) == "on" ? "1" : "0",
        "Cable"=>isset($_GET["checkCable"]) == "on" ? "1" : "0",
        "Funda"=>isset($_GET["checkFunda"]) == "on" ? "1" : "0",
        "Lapiz"=>isset($_GET["checkLapiz"]) == "on" ? "1" : "0",
        "Powerbank"=>isset($_GET["checkPowerbank"]) == "on" ? "1" : "0",
        "Maletin"=>isset($_GET["checkMaletin"]) == "on" ? "1" : "0",
        "Cargador"=>isset($_GET["checkCargador"]) == "on" ? "1" : "0",
        "Mouse"=>isset($_GET["checkMouse"]) == "on" ? "1" : "0",
        "Mousepad"=>isset($_GET["checkMousepad"]) == "on" ? "1" : "0"
    );

    $accesorios = json_encode($datos);

    $respuesta = ControladorDispositivos::ctrAsignarDispositivo($id, $res, $accesorios, $fecha_datetime->format('Y-m-d h:i:s'));
    $accesorios = json_decode($respuesta[0]["accesorios"]);

    $responsable = ControladorConsultores::ctrMostrarConsultores("idconsultor", $respuesta[0]["responsabledispositivo"]);
    $sede = ControladorSedes::ctrMostrarSedes("idsede", $responsable["sedeconsultor"]);

    try {

        $pdf=new PDF('P','mm',array(216,279));
        $pdf->SetMargins(28, 25, 28);
        $pdf->AliasNbPages();
        //Primera página
        $pdf->AddPage();
        //$pdf->AddFontMuseoSans();
        $pdf->AddFont('MuseoSans300','','MuseoSans-300.php');
        $pdf->SetFont('MuseoSans300','',13);
        $pdf->Image('img/MARCA DE WATER.png',0, 0, 216);
        $pdf->Image('img/logo_BCR.png',85,15,38);
        $pdf->Ln(15);
        $pdf->SetFont('MuseoSans300','',13);
        $pdf->Cell(0,10,mb_convert_encoding('ASIGNACIÓN DE DISPOSITIVO MÓVIL','ISO-8859-1', 'UTF-8'),0,0,'C');
        $pdf->Ln(15);
        $pdf->SetFont('MuseoSans300','',10);
        $pdf->MultiCell(0, 5, mb_convert_encoding('En este acto se hace entrega a: '.strtoupper($responsable["nombreconsultor"]).', con el cargo de: '.strtoupper($responsable["cargoconsultor"]).' destacado en la sede: '.strtoupper($sede["nombresede"]." ".$sede["departamentosede"]).' del dispositivo que a continuación se describe:', 'ISO-8859-1', 'UTF-8'), 0, 1);
        $pdf->Ln(8);
        //TABLA CABEX
        $pdf->SetFont('MuseoSans300','',11);
        //Cabecera
        $pdf->setTextColor(255, 255, 255);
        $pdf->SetFillColor(29,80,153);
        $pdf->SetLineWidth(.3);
        $pdf->SetFont('MuseoSans300','',11);
        $pdf->Cell(30,6,mb_convert_encoding('DESCRIPCIÓN','ISO-8859-1', 'UTF-8'),1,0,'C',1);
        $pdf->Cell(30,6,'MARCA',1,0,'C',1);
        $pdf->Cell(36,6,'MODELO',1,0,'C',1);
        $pdf->Cell(36,6,'IMEI/SERIE',1,0,'C',1);
        $pdf->Cell(25,6,mb_convert_encoding('TELÉFONO','ISO-8859-1', 'UTF-8'),1,0,'C',1);
        $pdf->Ln();
        //Datos
        $pdf->SetFillColor(224,235,255);
        $pdf->SetTextColor(0);
        $pdf->SetFont('');

        foreach ($respuesta as $fila) {
        $pdf->Cell(30,6,mb_convert_encoding($fila['tipodispositivo'],'ISO-8859-1', 'UTF-8'),'LR',0,'C');
        $pdf->Cell(30,6,$fila['marcadispositivo'],'LR',0,'C');
        $pdf->Cell(36,6,$fila['modelodispositivo'],'LR',0,'C');
        if($fila['imeidispositivo'] != ''){
            $imei_serie = $fila['imeidispositivo'];
            $pdf->Cell(36,6,$fila['imeidispositivo'],'LR',0,'C');
        } else{
            $imei_serie = $fila['seriedispositivo'];
            $pdf->Cell(36,6,$fila['seriedispositivo'],'LR',0,'C');
        }
        $pdf->Cell(25,6,$fila['telefonodispositivo'],'LR',0,'C');
        }

        /*$pdf->Cell(30,6,"MOVIL",'LR',0,'C');
        $pdf->Cell(30,6,"SAMSUNG",'LR',0,'C');
        $pdf->Cell(36,6,"GALAXY A34",'LR',0,'C');
        $pdf->Cell(36,6,"351326801779574",'LR',0,'C');
        $pdf->Cell(25,6,"72877196",'LR',0,'C');*/
        $pdf->Ln();
        $pdf->Cell(157,0,'','T');

        $pdf->Ln(10);
        $pdf->SetFont('MuseoSans300','',11);
        $pdf->Cell(0,5,'Con los siguientes accesorios:',0,0,'C');
        $pdf->Ln(10);

        if($respuesta[0]["tipodispositivo"] == "Teléfono"){

            $bandera1 = "";
            $bandera2 = "";
            $bandera3 = "";
            $bandera5 = "";

            if($accesorios->Cubo == "1"){ $bandera1 = "X"; }
            if($accesorios->Cable == "1"){ $bandera2 = "X"; }
            if($accesorios->Funda == "1"){ $bandera3 = "X";  }
            if($accesorios->Powerbank == "1"){ $bandera5 = "X"; }

            $pdf->Cell(0,5,mb_convert_encoding(' *  Cubo de carga               '.$bandera1, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 110, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Cable USB tipo C          '.$bandera2, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 115, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Funda del Dispositivo    '.$bandera3, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 120, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Powerbank                     '.$bandera5, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 125, 8, 4, 'D');


        } else if($respuesta[0]["tipodispositivo"] == "Tablet"){
            $bandera1 = "";
            $bandera2 = "";
            $bandera3 = "";
            $bandera4 = "";
            $bandera5 = "";

            if($accesorios->Cubo == "1"){ $bandera1 = "X"; }
            if($accesorios->Cable == "1"){ $bandera2 = "X"; }
            if($accesorios->Funda == "1"){ $bandera3 = "X";  }
            if($accesorios->Lapiz == "1"){ $bandera4 = "X"; }
            if($accesorios->Powerbank == "1"){ $bandera5 = "X"; }

            $pdf->Cell(0,5,mb_convert_encoding(' *  Cubo de carga               '.$bandera1, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 110, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Cable USB tipo C          '.$bandera2, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 115, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Funda del Dispositivo    '.$bandera3, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 120, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Lapiz                              '.$bandera4, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 125, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Powerbank                     '.$bandera5, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 130, 8, 4, 'D');

        }else if($respuesta[0]["tipodispositivo"] == "Laptop"){
          $bandera6 = "";
          $bandera7 = "";
          $bandera8 = "";
          $bandera9 = "";

            if($accesorios->Maletin == "1"){ $bandera6 = "X"; }
            if($accesorios->Cargador == "1"){ $bandera7 = "X"; }
            if($accesorios->Mouse == "1"){ $bandera8 = "X"; }
            if($accesorios->Mousepad == "1"){ $bandera9 = "X"; }

            $pdf->Cell(0,5,mb_convert_encoding(' *  Maletin                           '.$bandera6, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 110, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Cargador                        '.$bandera7, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 115, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Mouse                            '.$bandera8, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 120, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Mousepad                      '.$bandera9, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, 125, 8, 4, 'D');

        }else{

        }

        $pdf->Ln(5);
        $pdf->SetFont('MuseoSans300','',10);
        $pdf->MultiCell(0, 5, mb_convert_encoding('Haciendo constar que la presente asignación es para uso exclusivo de las funciones encomendadas como consultor en el Programa de Modernización del Sistema Estadístico de El Salvador, no pudiendo dar un uso diferente ni permitir su uso a persona distinta, además tiene la obligación de conservarlo en buenas condiciones y devolverlo al finalizar la consultoría o al momento que le sea requerido.', 'ISO-8859-1', 'UTF-8'), 0, 1);
        $pdf->Ln(5);
        $pdf->SetFont('MuseoSans300','',11);
        $pdf->Cell(0,20,'Entrega:',0,0,'L',0);
        $pdf->Cell(0,20,'Recibe:                                       ',0,0,'R',0);
        $pdf->Ln();
        $pdf->Cell(0,10,'F:________________________',0,0,'L',0);
        $pdf->Cell(0,10,'F:________________________',0,0,'R',0);
        $pdf->Ln();
        $pdf->SetFont('MuseoSans300','',10);
        $pdf->Cell(0,5,mb_convert_encoding('Nombre: '.$_SESSION["nombre"], 'ISO-8859-1', 'UTF-8'),0,0,'L',0);
        $pdf->Cell(0,5,mb_convert_encoding('Nombre: '.$responsable["nombreconsultor"], 'ISO-8859-1', 'UTF-8'),0,0,'R',0);
        $pdf->Ln();
        $pdf->SetFont('MuseoSans300','',10);
        $pdf->Cell(0,5,mb_convert_encoding('Cargo: '.$_SESSION["cargo"], 'ISO-8859-1', 'UTF-8'),0,0,'L',0);
        $pdf->Cell(0,5,mb_convert_encoding('Cargo: '.$responsable["cargoconsultor"], 'ISO-8859-1', 'UTF-8'),0,0,'R',0);
        $pdf->Ln();
        $pdf->SetFont('MuseoSans300','',10);
        $pdf->Cell(0,5,mb_convert_encoding('Consultor', 'ISO-8859-1', 'UTF-8'),0,0,'L',0);
        $pdf->Cell(0,5,mb_convert_encoding('Consultor                   ', 'ISO-8859-1', 'UTF-8'),0,0,'R',0);
        $pdf->Ln(20);
        $pdf->SetFont('MuseoSans300','',10);

        setlocale(LC_TIME, "spanish");

        $pdf->Cell(0,5,mb_convert_encoding($sede["departamentosede"].', '.fechaEs($fecha), 'ISO-8859-1', 'UTF-8'),0,1,'R');
        $pdf->SetFont('MuseoSans300','',10);
        $pdf->Cell(0,5,mb_convert_encoding('Lugar                             Fecha                   ', 'ISO-8859-1', 'UTF-8'),0,1,'R');

        $pdf->Ln(5);
        $pdf->SetFont('MuseoSans300','',10);
        $pdf->Cell(0,5,mb_convert_encoding('Nota: - Cualquier perdida/robo/extravío notificarlo a su jefe inmediato.', 'ISO-8859-1', 'UTF-8'),0,1);
        $pdf->Cell(0,5,mb_convert_encoding('          - Será responsable de llevar cargado al 100% el equipo al inicio de la jornada.', 'ISO-8859-1', 'UTF-8'),0,1);


        // Generar el PDF y enviarlo al navegador
        $pdfContent = $pdf->Output('', 'S'); // Captura el contenido en una variable

        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename='.'A - '.$responsable["nombreconsultor"].' - '.$imei_serie);
        header('Content-Length: ' . strlen($pdfContent));

        echo $pdfContent;
        exit;

    } catch(Exception $e){
        header("HTTP/1.1 500 Internal Server Error");
        echo "Error al generar el PDF: " . $e->getMessage();
    }
}
?>
