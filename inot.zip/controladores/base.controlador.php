<?php

class ControladorBase{

    public function base(){
        include "vistas/base.php";
    }

}