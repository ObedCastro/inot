<?php

const RUTA = "http://localhost/inot/";

class ControladorAdministradores{

    static public function ctrCambiarFotoPerfil($nombreImagen, $idUsuario){
        $tabla = "administradores";
        $respuesta = ModeloAdministradores::mdlCambiarFoto($tabla, $nombreImagen, $idUsuario);

        if($respuesta == "ok"){
            return array("mensaje" => "Su foto de perfil ha sido cambiada con éxito.", "icono" => "success", "titulo" => "Éxito");
        } else{
            return array("mensaje" => "No fue posible cargar el archivo.", "icono" => "error", "titulo" => "Algo salió mal");
        }
    }

    public function ctrIngresarAdministradores(){
        //$expresionUsuario = '/^[^0-9][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[@][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,4}$/';
        $expresionPassword = '/^[a-zA-Z0-9]+$/';

        if(isset($_POST['ingUsuario'])){
            if($_POST['ingUsuario'] && preg_match($expresionPassword, $_POST['ingPassword'])){
                $tabla = "administradores";
                $item = "usuario";
                $valor = $_POST['ingUsuario'];
                $passInput = md5($_POST["ingPassword"]);
                
                $respuesta = ModeloAdministradores::mdlIngresarAdministradores($tabla, $item, $valor);

                if(is_array($respuesta) && $respuesta["usuario"] == $_POST["ingUsuario"] && $respuesta["password"] == $passInput){
                    $_SESSION["validarSesion"] = "ok";
                    $_SESSION["id"] = $respuesta["id"];
                    $_SESSION["nombre"] = $respuesta["nombre"];
                    $_SESSION["email"] = $respuesta["email"];
                    $_SESSION["foto"] = $respuesta["foto"];
                    $_SESSION["usuario"] = $respuesta["usuario"];
                    $_SESSION["cargo"] = $respuesta["cargo"];
                    $_SESSION["password"] = $respuesta["password"];
                    $_SESSION["perfil"] = $respuesta["perfil"];                    

                    header("Location: ".RUTA."inicio");

                }else{                    
                    echo '<br><div class="text-danger text-bold">
                            Error: Ingrese datos válidos.
                        </div>';
                } 
            }
        } 
    }

    static public function ctrMostrarAdministradores($item, $valor){
        $tabla = "administradores";
        $datos = ModeloAdministradores::mdlMostrarAdministradores($tabla, $item, $valor);

        return $datos;
    }

    static public function ctrNuevoAdmin($datos){
      $tabla = "administradores";
      $datos = ModeloAdministradores::mdlNuevoAdmin($tabla, $datos);

      if($datos == "ok"){
        return array("mensaje" => "Usuario registrado satisfactoriamente.");
      } else{
        return array("mensaje" => "No fue posible registrar el usuario con los datos ingresados.");
      }
    }

    //PARA CAMBIAR CONTRASEÑA
    static public function ctrCambiarPassword($item, $valor, $pass){
        $tabla = "administradores";
        $respuesta = ModeloAdministradores::mdlCambiarPassword($tabla, $item, $valor, $pass);

        if($respuesta == "ok"){
            return array("mensaje" => "Contraseña cambiada satisfactoriamente.");
        } else{
            return array("mensaje" => $respuesta);
        }
    }

    //PARA MODIFICAR LA INFORMACIÓN DE UN ADMINISTRADOR
    static public function ctrModificarAdministrador($item, $valor, $datos){
        $tabla = "administradores";
        $respuesta = ModeloAdministradores::mdlModificarAdministrador($tabla, $item, $valor, $datos);
        
        if($respuesta == "ok"){
            return array("mensaje" => "Información modificada satisfactoriamente.");
        } else{
            return array("mensaje" => $respuesta);
        }
    }


    //---------------------------------------------------------------------------------------------------


    //PARA MOSTRAR SEDES
    static public function ctrMostrarSedes($item, $valor){
        $tabla = "sedes";

        $sedes = ModeloAdministradores::mdlMostrarSedes($tabla, $item, $valor);
        return $sedes;
    }

    //PARA MOSTRAR TIPOS DE DISPOSITIVOS
    static public function ctrMostrarTipos($item, $valor){
        $tabla = "tipodispositivo";

        $tipos = ModeloAdministradores::mdlMostrarSedes($tabla, $item, $valor);
        return $tipos;
    }

    //PARA MOSTRAR MARCAS DE DISPOSITIVOS
    static public function ctrMostrarMarcas($item, $valor){
        $tabla = "marcadispositivo";

        $marcas = ModeloAdministradores::mdlMostrarSedes($tabla, $item, $valor);
        return $marcas;
    }

    //PARA MOSTRAR MODELOS DE DISPOSITIVOS
    static public function ctrMostrarModelos($item, $valor){
        $tabla = "modelodispositivo";

        $modelos = ModeloAdministradores::mdlMostrarSedes($tabla, $item, $valor);
        return $modelos;
    }

    //CREAR NUEVA SEDE
    static public function ctrNuevaSede($datos){

        if(array_key_exists("nombresede", $datos)){
            $tabla = "sedes";
            $datos = ModeloAdministradores::mdlNuevaSede($tabla, $datos);
        } else if(array_key_exists("nombretipo", $datos)){
            $tabla = "tipodispositivo";
            $datos = ModeloAdministradores::mdlNuevoTipo($tabla, $datos);
        } else if(array_key_exists("nombremarca", $datos)){
            $tabla = "marcadispositivo";
            $datos = ModeloAdministradores::mdlNuevaMarca($tabla, $datos);
        } else if(array_key_exists("nombremodelo", $datos)){
            $tabla = "modelodispositivo";
            $datos = ModeloAdministradores::mdlNuevoModelo($tabla, $datos); 
        }

  
        if($datos == "ok"){
          return array("mensaje" => "Registro realizado satisfactoriamente.");
        } else{
          return array("mensaje" => "No fue posible realizar el registro con los datos proporcionados.");
        }
      }


      //ELIMINAR DATO
    static public function ctrEliminarDato($tabla, $item, $valor){

        $respuesta = ModeloAdministradores::mdlEliminarDato($tabla, $item, $valor);

        if($respuesta == "ok"){
            return array("titulo" => "Éxito", "mensaje" => "Registro eliminado satisfactoriamente.", "icono" => "success");
        }else{
            return array("titulo" => "Error", "mensaje" => "No ha sido posible eliminar el registro", "icono" => "error");
        }

    }

}
