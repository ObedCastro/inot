<?php

session_start();

require_once "../controladores/faltantes.controlador.php";
require_once "../modelos/faltantes.modelo.php";

class TablaFaltantes{

    public function mostrarTablaFaltantes(){
        $item = null;
        $valor = null;

        $faltantes = ControladorFaltantes::ctrMostrarFaltantes($item, $valor);
        $perfilUsuario = $_SESSION["perfil"];

        echo json_encode(array("data"=> $faltantes, "perfilUsuario"=>$perfilUsuario));
    }

}


$activar = new TablaFaltantes();
$activar->mostrarTablaFaltantes();