<?php
session_start();

require_once "../controladores/administradores.controlador.php";
require_once "../modelos/administradores.modelo.php";

class AjaxAdministradores{

  //PARA CREAR UN NUEVO USUARIO
  public function ajaxNuevoAdmin(){

    if(isset($_POST["nombreAdmin"]) && !empty($_POST["nombreAdmin"]) && 
      isset($_POST["emailAdmin"]) && !empty($_POST["emailAdmin"]) && 
      isset($_POST["usuarioAdmin"]) && !empty($_POST["usuarioAdmin"]) && 
      isset($_POST["passwordAdmin"]) && !empty($_POST["passwordAdmin"]) && 
      isset($_POST["perfilAdmin"]) && !empty($_POST["perfilAdmin"]) && 
      isset($_POST["cargoAdmin"]) && !empty($_POST["cargoAdmin"])){

      $password = md5($_POST["passwordAdmin"]);

      $datos = array(
        'nombre' => $_POST["nombreAdmin"],
        'email' => $_POST["emailAdmin"],
        'cargo' => $_POST["cargoAdmin"],
        'usuario' => $_POST["usuarioAdmin"],
        'password' => $password,
        'perfil' => $_POST["perfilAdmin"]
      );

      $respuesta = ControladorAdministradores::ctrNuevoAdmin($datos);
      echo json_encode($respuesta);
    }

  }

  //PARA CAMBIAR CONTRASEÑA DE USUARIO
  public function ajaxCambiarPassword(){
    $item = "id";
    $valor = $_POST["idAdmin"];

    $anteriorPassword = $_POST["anteriorPassword"];
    $nuevaPassword = $_POST["nuevaPassword"];

    $passwordActual = ControladorAdministradores::ctrMostrarAdministradores($item, $valor);

    if($passwordActual["password"] == md5($anteriorPassword)){
      $pass = md5($nuevaPassword); 

      $actualizar = ControladorAdministradores::ctrCambiarPassword($item, $valor, $pass);

      echo json_encode($actualizar);

    } else{
      echo json_encode(array("mensaje" => "Contraseña anterior no válida", "error" => "Contraseña anterior no válida"));
    }
  }

  //PARA MOSTRAR LA INFORMACIÓN DE UN ADMINISTRADOR
  public $idAdmin;
  public function ajaxMostrarInfoAdmin(){
    $item = "id";
    $valor = $this->idAdmin;

    $respuesta = ControladorAdministradores::ctrMostrarAdministradores($item, $valor);
    echo json_encode($respuesta);
  }

  //PARA MODIFICAR LA INFORMACIÓN DE UN ADMINISTRADOR
  public $idEditarAdmin;
  public function ajaxModificarAdministrador(){
    $item = "id";
    $valor = $this->idEditarAdmin;

    $datos = array(
      'nombre' => $_POST["editarNombreAdmin"],
      'email' => $_POST["editarEmailAdmin"],
      'usuario' => $_POST["editarUsuarioAdmin"],
      'password' => $_POST["editarPasswordAdmin"],
      'perfil' => $_POST["editarPerfilAdmin"],
      'cargo' => $_POST["editarCargoAdmin"]
    );

    $respuesta = ControladorAdministradores::ctrModificarAdministrador($item, $valor, $datos);
    echo json_encode($respuesta);
  }



  //------------------------------------------------------------------------------------------

  //REGISTRAR UNA SEDE NUEVA
  public function ajaxNuevaSede(){
    if(isset($_POST["nombresede"]) && !empty($_POST["nombresede"]) && 
      isset($_POST["departamento"]) && !empty($_POST["departamento"])){

      $datos = array(
        'nombresede' => $_POST["nombresede"],
        'departamentosede' => $_POST["departamento"]
      );

      $respuesta = ControladorAdministradores::ctrNuevaSede($datos);
      echo json_encode($respuesta);
    }
  }

  //REGISTRAR UN NUEVO TIPO DE DISPOSITIVO
  public function ajaxNuevoTipo(){
    if(isset($_POST["nombretipo"]) && !empty($_POST["nombretipo"])){

      $datos = array(
        'nombretipo' => $_POST["nombretipo"]
      );

      $respuesta = ControladorAdministradores::ctrNuevaSede($datos);
      echo json_encode($respuesta);
    }
  }

  //REGISTRAR UNA NUEVA MARCA DE DISPOSITIVO
  public function ajaxNuevaMarca(){
    if(isset($_POST["nombremarca"]) && !empty($_POST["nombremarca"])){

      $datos = array(
        'nombremarca' => $_POST["nombremarca"]
      );

      $respuesta = ControladorAdministradores::ctrNuevaSede($datos);
      echo json_encode($respuesta);
    }
  }

  //REGISTRAR UN NUEVO MODELO DE DISPOSITIVO
  public function ajaxNuevoModelo(){
    if(isset($_POST["nombremodelo"]) && !empty($_POST["nombremodelo"])){

      $datos = array(
        'nombremodelo' => $_POST["nombremodelo"]
      );

      $respuesta = ControladorAdministradores::ctrNuevaSede($datos);
      echo json_encode($respuesta);
    }
  }

  //ELIMINAR
    public $eliminarDato, $tabla, $item;
    public function eliminarDato(){
      $tabla = $this->tabla;
      $item = $this->item;
      $valor = $this->eliminarDato;

        $respuesta = ControladorAdministradores::ctrEliminarDato($tabla, $item, $valor);

        echo json_encode($respuesta);
    }

    public function ajaxCambiarFoto(){
      $usuario = $_SESSION["usuario"];
      $ruta = $_SERVER['DOCUMENT_ROOT'] ."/inot/vistas/assets/img/";
      if(isset($_FILES["imagenPerfil"]["name"])){
        $imageName = $_FILES['imagenPerfil']['name'];
        $tmpName = $_FILES['imagenPerfil']['tmp_name'];        
        $extension = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));

        $nombreGuardar = $usuario;
        $target_file = $ruta.$nombreGuardar.".".$extension;
        $idUsuario = $_SESSION["id"];

        if (file_exists($target_file)) {
          unlink($target_file);  // Elimina el archivo existente
        }

        if (move_uploaded_file($tmpName, $target_file)) {
          $respuesta = ControladorAdministradores::ctrCambiarFotoPerfil($nombreGuardar, $idUsuario);
          echo json_encode($respuesta);
        }

      }else {
        echo json_encode($respuesta);
      }
    }

}

//Para realizar un nuevo registro
if(isset($_POST["nuevo"])){
  $nuevo = new AjaxAdministradores();
  $nuevo->ajaxNuevoAdmin();
}

//Para cambio de contraseña
if(isset($_POST["nuevaPassword"])){
  $cambiarPassword = new AjaxAdministradores();
  $cambiarPassword->ajaxCambiarPassword();
}

//Para mostrar información de un administrador
if(isset($_POST["idEditarAdmin_"])){
  $mostrarInfoAdmin = new AjaxAdministradores();
  $mostrarInfoAdmin->idAdmin = $_POST["idEditarAdmin_"];
  $mostrarInfoAdmin->ajaxMostrarInfoAdmin();
}

//Para modificar la información de un administrador
if(isset($_POST["idEditarAdmin"])){
  $modificarAdmin = new AjaxAdministradores();
  $modificarAdmin->idEditarAdmin = $_POST["idEditarAdmin"];
  $modificarAdmin->ajaxModificarAdministrador();
}


//Para realizar un nuevo registro de SEDE
if(isset($_POST["nuevasede"])){
  $nuevo = new AjaxAdministradores();
  $nuevo->ajaxNuevaSede();
}

//Para realizar un nuevo registro de TIPO DE DISPOSITIVO
if(isset($_POST["nuevotipo"])){
  $nuevo = new AjaxAdministradores();
  $nuevo->ajaxNuevoTipo();
}

//Para realizar un nuevo registro de MARCA DE DISPOSITIVO
if(isset($_POST["nuevamarca"])){
  $nuevo = new AjaxAdministradores();
  $nuevo->ajaxNuevaMarca();
}

//Para realizar un nuevo registro de MODELO DE DISPOSITIVO
if(isset($_POST["nuevomodelo"])){
  $nuevo = new AjaxAdministradores();
  $nuevo->ajaxNuevoModelo();
}





//ELIMINAR DATO
if(isset($_POST["idEliminarSede"])){
  $eliminar = new AjaxAdministradores();
  $eliminar->eliminarDato = $_POST["idEliminarSede"];
  $eliminar->tabla = "sedes";
  $eliminar->item = "idsede";
  $eliminar->eliminarDato();
}

if(isset($_POST["idEliminarTipo"])){
  $eliminar = new AjaxAdministradores();
  $eliminar->eliminarDato = $_POST["idEliminarTipo"];
  $eliminar->tabla = "tipodispositivo";
  $eliminar->item = "idtipo";
  $eliminar->eliminarDato();
}

if(isset($_POST["idEliminarMarca"])){
  $eliminar = new AjaxAdministradores();
  $eliminar->eliminarDato = $_POST["idEliminarMarca"];
  $eliminar->tabla = "marcadispositivo";
  $eliminar->item = "idmarca";
  $eliminar->eliminarDato();
}

if(isset($_POST["idEliminarModelo"])){
  $eliminar = new AjaxAdministradores();
  $eliminar->eliminarDato = $_POST["idEliminarModelo"];
  $eliminar->tabla = "modelodispositivo";
  $eliminar->item = "idmodelo";
  $eliminar->eliminarDato();
}






if(isset($_FILES['imagenPerfil'])){
  $nuevo = new AjaxAdministradores();
  $nuevo->ajaxCambiarFoto();
}