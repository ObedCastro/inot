<?php

require_once "../modelos/conexion.php";

class CargarDataDispositivos{

    public function cargarData(){

        if(isset($_FILES["file"]) && $_FILES["file"]["error"] == 0){ 
            $csvFile = $_FILES["file"]["tmp_name"];

            $totalLineas = count(file($csvFile));
            $insertados = 0;

            $sql = "INSERT IGNORE INTO dispositivos (tipodispositivo, marcadispositivo, modelodispositivo, imeidispositivo, seriedispositivo, telefonodispositivo, sededispositivo, estadodispositivo) VALUES (?,?,?,?,?,?,?,?)";

            $stmt = Conexion::conectar()->prepare($sql);

            if(($handle = fopen($csvFile, "r")) !== false){

                while(($data = fgetcsv($handle, 1000, ";")) !== false){

                    if(strlen($data[3]) != 15){
                        continue;
                    }

                    $stmt->bindValue(1, $data[0], PDO::PARAM_STR);
                    $stmt->bindValue(2, $data[1], PDO::PARAM_STR);
                    $stmt->bindValue(3, $data[2], PDO::PARAM_STR);
                    $stmt->bindValue(4, $data[3], PDO::PARAM_STR);
                    $stmt->bindValue(5, $data[4], PDO::PARAM_STR);
                    $stmt->bindValue(6, $data[5], PDO::PARAM_STR);
                    $stmt->bindValue(7, $data[6], PDO::PARAM_STR);
                    $stmt->bindValue(8, $data[7], PDO::PARAM_STR);
    
                    if($stmt->execute()){
                        if($stmt->rowCount() > 0){
                            $insertados ++;
                        }
                    } else{
                        echo json_encode(array("mensaje" => "Error de archivo"));
                    }

                }


                fclose($handle);

                if($insertados < 1){
                    echo json_encode(array("cantidad" => $insertados, "total" => $totalLineas, "icono" => "info", "titulo" => "Atención", "mensaje" => "No fue posible registrar ningún dispositivo, por favor revise el formato del archivo o bien los dispositivos que desea registrar, ya se encuentran en la base de datos."));
                } else{
                    echo json_encode(array("cantidad" => $insertados, "total" => $totalLineas, "icono" => "success", "titulo" => "Éxito", "mensaje" => "Registros agregados o modificados con éxito."));
                }
            } else{
                echo json_encode(array("icono" => "info", "titulo" => "Atención", "mensaje" => "El archivo no tiene el formato esperado. Por favor verificar y volver a subir."));
            }
        } else{
            echo "Error al subir el archivo.";
        }        

    }

}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $cargar = new CargarDataDispositivos();
    $cargar->cargarData();
}