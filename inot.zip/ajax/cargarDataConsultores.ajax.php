<?php

require_once "../modelos/conexion.php";

class CargarDataConsultores{

    public function cargarDataConsultores(){

        if(isset($_FILES["file"]) && $_FILES["file"]["error"] == 0){
            $csvFile = $_FILES["file"]["tmp_name"];
            $csvName = $_FILES["file"]["name"];
            $extension = pathinfo($csvName, PATHINFO_EXTENSION);

            if ($extension !== 'csv') {
                echo "El archivo debe ser de tipo .csv";
                exit;
            }

            $totalLineas = count(file($csvFile))-1;
            $insertados = 0;
            $noInsertados = [];

            $sql = "INSERT IGNORE INTO consultores (nombreconsultor, duiconsultor, cargoconsultor, contactoconsultor, dispositivo_id, sedeconsultor, estatusconsultor, fecharegistroconsultor) VALUES (?,?,?,?,null,?,?,?)";

            $stmt = Conexion::conectar()->prepare($sql);

            if(($handle = fopen($csvFile, "r")) !== false){

                $header = fgetcsv($handle, 1000, ";");

                $lineNumber = 2;
                while(($data = fgetcsv($handle, 1000, ";")) !== false){

                    if (count($data) < 7) {
                        $lineNumber++;
                        continue;
                    }

                    if(empty($data[0]) || empty($data[1]) || empty($data[2]) || empty($data[3]) || empty($data[4]) || empty($data[5])){
                        continue;
                    }

                    $stmt_check = Conexion::conectar()->prepare("SELECT COUNT(*) FROM consultores WHERE duiconsultor = ?");
                    $stmt_check->execute([$data[1]]);
                    $existe = $stmt_check->fetchColumn() > 0;

                    if ($existe) {
                        $noInsertados[] = 'DUI: '.$data[1].', Linea: '.$lineNumber.' del .CSV';
                        $lineNumber++;
                        continue;
                    }

                    $stmt->bindValue(1, $data[0], PDO::PARAM_STR);    
                    $stmt->bindValue(2, $data[1], PDO::PARAM_STR); 
                    $stmt->bindValue(3, $data[2], PDO::PARAM_STR); 
                    $stmt->bindValue(4, $data[3], PDO::PARAM_STR); 
                    $stmt->bindValue(5, $data[4], PDO::PARAM_STR);     
                    $stmt->bindValue(6, $data[5], PDO::PARAM_STR); 
                    $stmt->bindValue(7, $fecha_actual = date('Y-m-d'), PDO::PARAM_STR);         

                    if($stmt->execute()){
                        if ($stmt->rowCount() > 0) {
                            $insertados++;
                        }
                    }  else{
                        /* echo "Error al insertar registros: ".$stmt->error."<br>"; */
                        $noInsertados[] = 'DUI: '.$data[1].', Linea: '.$lineNumber.' del .CSV';
                    }

                    $lineNumber++;

                }

                fclose($handle);
                
                if($insertados < 1){
                    echo json_encode(array(
                        "cantidad" => $insertados,
                        "total" => $totalLineas,
                        "icono" => "info",
                        "titulo" => "Atención",
                        "noinsertados" => implode("<br>",$noInsertados),
                        "mensaje" => "No fue posible registrar ningún consultor, por favor verificar que el formato coincida con el solicitado, o bien los DUI que intenta registrar ya se encuentran en la base de datos.",
                        ));
                } else{
                    echo json_encode(array(
                        "cantidad" => $insertados,
                        "total" => $totalLineas,
                        "icono" => "success",
                        "titulo" => "Éxito",
                        "noinsertados" => implode("<br>",$noInsertados),
                        "mensaje" => "Registros agregados o modificados con éxito:",
                        ));
                }
            } else{
                echo "No se pudo abrir el archivo CSV.";
            }
        } else{
            echo "Error al subir el archivo.";
        }        

    }

}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $cargar = new cargarDataConsultores();
    $cargar->cargarDataConsultores();
}