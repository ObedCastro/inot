<?php

require_once "../modelos/conexion.php";

class CargarDataConsultores{

    public function cargarDataConsultores(){

        if(isset($_FILES["file"]) && $_FILES["file"]["error"] == 0){
            $csvFile = $_FILES["file"]["tmp_name"];

            $totalLineas = count(file($csvFile));
            $insertados = 0;

            $sql = "INSERT IGNORE INTO consultores (nombreconsultor, duiconsultor, cargoconsultor, contactoconsultor, sedeconsultor) VALUES (?,?,?,?,?)";

            $stmt = Conexion::conectar()->prepare($sql);

            if(($handle = fopen($csvFile, "r")) !== false){

                while(($data = fgetcsv($handle, 1000, ";")) !== false){

                    if(strlen($data[1] != 10)){
                        continue;
                    }

                    $stmt->bindValue(1, $data[0], PDO::PARAM_STR);    
                    $stmt->bindValue(2, $data[1], PDO::PARAM_STR); 
                    $stmt->bindValue(3, $data[2], PDO::PARAM_STR); 
                    $stmt->bindValue(4, $data[3], PDO::PARAM_STR); 
                    $stmt->bindValue(5, $data[4], PDO::PARAM_STR);              

                    if($stmt->execute()){
                        if ($stmt->rowCount() > 0) {
                            $insertados++;
                        }
                    }  else{
                        echo "Error al insertar registros: ".$stmt->error."<br>";
                    }

                }

                fclose($handle);
                
                if($insertados < 1){
                    echo json_encode(array("cantidad" => $insertados, "total" => $totalLineas, "icono" => "info", "titulo" => "Atención", "mensaje" => "No fue posible registrar ningún consultor, por favor verificar que el formato coincida con el solicitado, o bien los DUI que intenta registrar ya se encuentran en la base de datos."));
                } else{
                    echo json_encode(array("cantidad" => $insertados, "total" => $totalLineas, "icono" => "success", "titulo" => "Éxito", "mensaje" => "Registros agregados o modificados con éxito:"));
                }
            } else{
                echo "No se pudo abrir el archivo CSV.";
            }
        } else{
            echo "Error al subir el archivo.";
        }        

    }

}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $cargar = new cargarDataConsultores();
    $cargar->cargarDataConsultores();
}