<?php

require_once "conexion.php";

class ModeloAdministradores{

  static public function mdlCambiarFoto($tabla, $nombreImagen, $idUsuario){
    try{
      $sql = "UPDATE $tabla SET usuario=:usuario WHERE id = :id";
      $stmt = Conexion::conectar()->prepare($sql);
      $stmt->bindParam(":usuario", $nombreImagen, PDO::PARAM_STR);
      $stmt->bindParam(":id", $idUsuario, PDO::PARAM_STR);
      
      if($stmt->execute()){
        return "ok";
      }

    } catch(PDOException $e){
      return $e->getMessage();
    }
  }

    static public function mdlIngresarAdministradores($tabla, $item, $valor){
        $sql = "SELECT * FROM $tabla WHERE $item = :$item";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetch();

        $stmt->close();
        $stmt = null;

    }

    static public function mdlMostrarAdministradores($tabla, $item, $valor){
      if($item != null){
        $sql = "SELECT * FROM $tabla WHERE $item = :$item";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetch();

      } else{
        $sql = "SELECT id, nombre, email, cargo, foto, usuario, password, perfil FROM $tabla";
        $stmt = Conexion::conectar()->prepare($sql);

        if($stmt->execute()){
          return $stmt->fetchAll();
        } else{
            return array("Error" => "No ha sido posible obtener la información");
        }
      }
    }

    static public function mdlNuevoAdmin($tabla, $datos){
      $foto = "vistas/assets/img";
      try{
        $sql = "INSERT INTO $tabla (nombre, email, cargo, foto, usuario, password, perfil) values (:nombre, :email, :cargo, :foto, :usuario, :password, :perfil)";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":nombre", $datos["nombre"], PDO::PARAM_STR);
        $stmt->bindParam(":email", $datos["email"], PDO::PARAM_STR);
        $stmt->bindParam(":cargo", $datos["cargo"], PDO::PARAM_STR);
        $stmt->bindParam(":foto", $foto, PDO::PARAM_STR);
        $stmt->bindParam(":usuario", $datos["usuario"], PDO::PARAM_STR);
        $stmt->bindParam(":password", $datos["password"], PDO::PARAM_STR);
        $stmt->bindParam(":perfil", $datos["perfil"], PDO::PARAM_STR);

        if($stmt->execute()){
          return "ok";
        }
      } catch(PDOException $e){
        return "error";
      }

    }

    //PARA CAMBIAR LA CONTRASEÑA DE USUARIO
    static public function mdlCambiarPassword($tabla, $item, $valor, $pass){
      try{
        $sql = "UPDATE $tabla SET password = :password WHERE $item = :$item";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":password", $pass, PDO::PARAM_STR);
        $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        
        if($stmt->execute()){
          return "ok";
        }

      } catch(PDOException $e){
        return $e->getMessage();
      }
    }

    //PARA MODIFICAR LA INFORMACIÓN DE UN ADMINISTRADOR
    static public function mdlModificarAdministrador($tabla, $item, $valor, $datos){
      try{
        if($datos["password"] == "" || $datos["password"] == null){
          $sql = "UPDATE $tabla SET nombre = :nombre, email = :email, usuario = :usuario, perfil = :perfil, cargo = :cargo WHERE $item = :$item";
          $stmt = Conexion::conectar()->prepare($sql);
          $stmt->bindParam(":nombre", $datos["nombre"], PDO::PARAM_STR);
          $stmt->bindParam(":email", $datos["email"], PDO::PARAM_STR);
          $stmt->bindParam(":usuario", $datos["usuario"], PDO::PARAM_STR);
          $stmt->bindParam(":perfil", $datos["perfil"], PDO::PARAM_STR);
          $stmt->bindParam(":cargo", $datos["cargo"], PDO::PARAM_STR);
          $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);

        } else{
          $password = md5($datos["password"]);
          $sql = "UPDATE $tabla SET nombre = :nombre, email = :email, usuario = :usuario, password = :password, perfil = :perfil, cargo = :cargo WHERE $item = :$item";
          $stmt = Conexion::conectar()->prepare($sql);
          $stmt->bindParam(":nombre", $datos["nombre"], PDO::PARAM_STR);
          $stmt->bindParam(":email", $datos["email"], PDO::PARAM_STR);
          $stmt->bindParam(":usuario", $datos["usuario"], PDO::PARAM_STR);
          $stmt->bindParam(":password", $password, PDO::PARAM_STR);
          $stmt->bindParam(":perfil", $datos["perfil"], PDO::PARAM_STR);
          $stmt->bindParam(":cargo", $datos["cargo"], PDO::PARAM_STR);
          $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
        }
        
        
        if($stmt->execute()){
          return "ok";
        }

      } catch(PDOException $e){
        return $e->getMessage();
      }
    }


    //-------------------------------------------------------------------------------------------------

    //PARA MOSTRAR DATA DE MANTENIMIENTO
    //PARA LA DATA DE LA TABLA SEDES, TIPOS DE DIPOSITIVOS Y MARCAS DE DISPOSITIVOS
    static public function mdlMostrarSedes($tabla, $item, $valor){
      $sql = "SELECT * FROM $tabla";

      $stmt = Conexion::conectar()->prepare($sql);
      
      if($stmt->execute()){
          return $stmt->fetchAll();
      } else{
          return array("Error" => "No ha sido posible obtener la información");
      }
    }

    //REGISTRAR NUEVA SEDE
    static public function mdlNuevaSede($tabla, $datos){

      try{
        $sql = "INSERT INTO $tabla (nombresede, departamentosede) values (:nombresede, :departamentosede)";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":nombresede", $datos["nombresede"], PDO::PARAM_STR);
        $stmt->bindParam(":departamentosede", $datos["departamentosede"], PDO::PARAM_STR);

        if($stmt->execute()){
          return "ok";
        }
      } catch(PDOException $e){
        return "error";
      }
    }

    //REGISTRAR NUEVO TIPO DE DISPOSITIVO
    static public function mdlNuevoTipo($tabla, $datos){
      try{
        $sql = "INSERT INTO $tabla (nombretipo) values (:nombretipo)";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":nombretipo", $datos["nombretipo"], PDO::PARAM_STR);

        if($stmt->execute()){
          return "ok";
        }
      } catch(PDOException $e){
        return "error";
      }
    }

    //REGISTRAR NUEVA MARCA DE DISPOSITIVO
    static public function mdlNuevaMarca($tabla, $datos){
      try{
        $sql = "INSERT INTO $tabla (nombremarca) values (:nombremarca)";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":nombremarca", $datos["nombremarca"], PDO::PARAM_STR);

        if($stmt->execute()){
          return "ok";
        }
      } catch(PDOException $e){
        return "error";
      }
    }

    //REGISTRAR NUEVO MODELO DE DISPOSITIVO
    static public function mdlNuevoModelo($tabla, $datos){
      try{
        $sql = "INSERT INTO $tabla (nombremodelo) values (:nombremodelo)";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(":nombremodelo", $datos["nombremodelo"], PDO::PARAM_STR);

        if($stmt->execute()){
          return "ok";
        }
      } catch(PDOException $e){
        return "error";
      }
    }

    //ELIMINAR DATO
    static public function mdlEliminarDato($tabla, $item, $valor){
      try{
          $sql = "DELETE FROM $tabla WHERE $item = :$item";
          $stmt = Conexion::conectar()->prepare($sql);
          $stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
  
          if($stmt->execute()){
              return "ok";
          }
      } catch(PDOException $e){
          return "error";
      }
  }

}
