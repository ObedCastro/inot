<?php

require_once "conexion.php";

class ModeloHistorial{

  static public function mdlMostrarHistorial($tabla, $imei, $serie, $inventario){

      $sqldispositivo = "SELECT * FROM dispositivos WHERE imeidispositivo = $imei";
    
      $sql = "SELECT r.*, c.nombreconsultor, c.cargoconsultor, c.estatusconsultor, CONCAT(s.nombresede,', ',s.departamentosede) as sede FROM $tabla r 
      INNER JOIN dispositivos d ON r.dispositivo_id = d.iddispositivo 
      INNER JOIN consultores c ON r.usuario_campo_id = c.idconsultor
      INNER JOIN sedes s ON c.sedeconsultor = s.idsede
      WHERE 1=1";

      if(!empty($imei)){
        $sql .= " AND d.imeidispositivo = $imei";
      }

      if(!empty($serie)){
        $sql .= " AND d.seriedispositivo = $serie";
      }

      if(!empty($inventario)){
        $sql .= " AND d.inventariodispositivo = $inventario";
      }

      $sql .= " ORDER BY r.fecha_asignacion DESC";

      $stmtdispositivo = Conexion::conectar()->prepare($sqldispositivo);
      $stmt = Conexion::conectar()->prepare($sql);

      $stmtdispositivo->execute();
      $stmt->execute();

      return array($stmtdispositivo->fetch(), $stmt->fetchAll());
  }

}
