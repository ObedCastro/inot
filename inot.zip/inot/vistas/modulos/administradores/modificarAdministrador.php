<div class="modal fade" id="modalEditarAdmin" tabindex="-1" aria-labelledby="modalEditarAdminLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-primary">
      <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill cursor-pointer btn-cerrar-modal" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-remove text-white"></i></span>
        <h1 class="modal-title fs-5 text-white" id="modalEditarAdminLabel"><i class="fa fa-edit"></i> Modificar información del administrador</h1>
        <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
      </div>
      <div class="modal-body">

        <form method="POST" id="formularioEditarAdmin">
          <input type="hidden" name="idEditarAdmin" id="idEditarAdmin">
          <div class="row">
            <div class="mb-3 col-md-6">
              <label for="editarNombreAdmin" class="form-label">Nombre</label>
              <input type="text" class="form-control" id="editarNombreAdmin" name="editarNombreAdmin" onkeypress="return ((event.charCode >= 65 && event.charCode <= 90) || (event.charCode >= 97 && event.charCode <= 122) || event.charCode == 32 || event.charCode == 225 || event.charCode == 233 || event.charCode == 237 || event.charCode == 243 || event.charCode == 250 || event.charCode == 193 || event.charCode == 201 || event.charCode == 205 || event.charCode == 211 || event.charCode == 218)"
              required>
            </div>
            <div class="mb-3 col-md-6">
              <label for="editarEmailAdmin" class="form-label">Email</label>
              <input type="email" class="form-control" id="editarEmailAdmin" name="editarEmailAdmin" required>
            </div>
          </div>

          <div class="row">
            <div class="mb-3 col-md-4">
              <label for="editarUsuarioAdmin" class="form-label">Usuario</label>
              <input type="text" class="form-control" id="editarUsuarioAdmin" name="editarUsuarioAdmin" aria-describedby="emailHelp" required>
            </div>
            <div class="mb-3 col-md-4">
              <label for="editarPasswordAdmin" class="form-label">Contraseña</label>
              <input type="password" class="form-control" id="editarPasswordAdmin" name="editarPasswordAdmin" aria-describedby="emailHelp">
            </div>
            <div class="mb-3 col-md-4">
              <label for="editarPerfilAdmin" class="form-label">Perfil</label>
              <select id="editarPerfilAdmin" name="editarPerfilAdmin" class="form-select" aria-label="Default select example" required>
                <option value=""></option>
                <option value="1">Administrador</option>
                <option value="2">Usuario</option>
                <option value="3">Solo ver</option>
              </select>
            </div>
          </div>

          <div class="row">
            <div class="mb-3 col-6">
              <label for="editarCargoAdmin" class="form-label">Cargo</label>
              <input type="text" class="form-control" id="editarCargoAdmin" name="editarCargoAdmin" onkeypress="return ((event.charCode >= 65 && event.charCode <= 90) || (event.charCode >= 97 && event.charCode <= 122) || event.charCode == 32 || event.charCode == 225 || event.charCode == 233 || event.charCode == 237 || event.charCode == 243 || event.charCode == 250 || event.charCode == 193 || event.charCode == 201 || event.charCode == 205 || event.charCode == 211 || event.charCode == 218)"
              required>
            </div>

            <div class="mb-3 col-6">
              <label for="editarSedeAdmin" class="form-label">Sede asignada</label>
              <select id="editarSedeAdmin" name="editarSedeAdmin" class="form-select" aria-label="Default select example" required>
                <?php 
                  $sedes = ControladorSedes::ctrMostrarSedes(null, null);
                  foreach ($sedes as $key => $sede) {
                    echo '<option value="'.$sede['idsede'].'">'.$sede['nombresede'].' '.$sede['departamentosede'].'</option>';
                  }
                ?>
              </select>
            </div>
  
            <div class="mb-5">
              <label for="editarTipoContrato" class="form-label">Tipo de contrato</label>
              <!-- <input type="text" class="form-control" id="editarTipoContrato" name="editarTipoContrato" required> -->
              <select class="form-select" aria-label="Default select example" id="editarTipoContrato" name="editarTipoContrato" required>
                <option value=""></option>
                <option value="Consultor BID">Consultor BID</option>
                <option value="Banco Central de Reserva">Banco Central de Reserva</option>
                <option value="ONEC">ONEC</option>
                <option value="Consultor">Consultor</option>
              </select>
            </div>
          </div>

          <div class="mt-1 text-end modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary" name="opcionE">Modificar</button>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>