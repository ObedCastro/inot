/* la variable "localhost" está definida en el archivo base */

//Resetear formularios de modal, en cuanto el modal se oculte
$("#modalDispositivos").on("hidden.bs.modal", function () {
    $(this).find('form')[0].reset();
  });
 
//Traducir datatable
var table = $('#datatable').DataTable({
    "ajax": localhost + "ajax/tablaDispositivos.ajax.php",
    "ordering": false,
    "deferRender": true,
    "retrieve": true,
    "processing": true,
    language: {
        "decimal": "",
        "emptyTable": "No hay información",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
        "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
        "infoFiltered": "(Filtrado de _MAX_ total entradas)",
        "infoPostFix": "",
        "thousands": ",",
        "lengthMenu": "Mostrar _MENU_ Entradas",
        "loadingRecords": "Cargando...",
        "processing": "Procesando...",
        "search": "Buscar:",
        "zeroRecords": "Sin resultados encontrados",
        "paginate": {
            "first": "Primero",
            "last": "Ultimo",
            "next": "Siguiente",
            "previous": "Anterior"
        }
    },
    dom: 'Bfrtip',
    buttons: [
        {
            extend: 'pdfHtml5',
            className: 'btnDt btn-app export pdf',
            text: '<i class="fa fa-file-pdf-o" aria-hidden="true" data-bs-toggle="tooltip" data-bs-placement="top" title="Exportar a PDF"></i>',
            download: 'open',
            orientation: 'landscape',
            exportOptions: {
                columns: [0,1,2,3,4,5,6,7,8,9]
            },
            title: "Listado de dispositivos",
            customize: function(doc) {
                doc.content[1].margin = [ 10, 0, 10, 0 ] //left, top, right, bottom
            }
        },
        {
            extend: 'excelHtml5',
            className: 'btnDt btn-app export excel',
            text: '<i class="fa fa-file-excel-o" aria-hidden="true" data-bs-toggle="tooltip" data-bs-placement="top" title="Exportar a Excel"></i>',
            autoFilter: true,
            sheetName: 'Exported data'
        }
    ]
    });

//__________________________________________________________________________________________

//Creamos una fila en el head de la tabla y lo clonamos para cada columna
$('#datatable thead tr').clone(true).appendTo( '#datatable thead' );
$('#datatable thead tr:eq(1) th').each( function (i) {
    $(this).html( '<input style="width: 100%;" type="text" placeholder="Buscar..." />' );
    $( 'input', this ).on( 'keyup change', function () {
        if ( table.column(i).search() !== this.value ) {
            table
                .column(i)
                .search( this.value )
                .draw();
        }
    });
});

// --------------------------------------------------------------------------------------------
// VALIDANDO EL TIPO DE DISPOSITIVO Y OCULTAR CAMPOS EN EL FOMRULARIO DE NUEVO DISPOSITIVO
$(".btnNuevoDispositivo").on("click", function(){
    $("#inventarioDispositivo").parent().hide();
    $("#hostnameDispositivo").parent().hide();
    $("#imeiDispositivo").parent().hide();
    $("#telefonoDispositivo").parent().hide();
    

    $("#tipoDispositivo").on("change", function(){
        if($("#tipoDispositivo").val() == "Laptop"){
            $("#imeiDispositivo").parent().hide();
            $("#imeiDispositivo").removeAttr("required");
            $("#telefonoDispositivo").parent().hide();
            $("#telefonoDispositivo").removeAttr("required");
            $("#inventarioDispositivo").parent().show();
            $("#hostnameDispositivo").parent().show();
        } else if($("#tipoDispositivo").val() == "Teléfono" || $("#tipoDispositivo").val() == "Tablet"){
            $("#imeiDispositivo").parent().show();
            $("#imeiDispositivo").prop("required", true);
            $("#telefonoDispositivo").parent().show();
            $("#telefonoDispositivo").prop("required", true);
            $("#inventarioDispositivo").parent().hide();
            $("#hostnameDispositivo").parent().hide();
        } else{
            $("#imeiDispositivo").parent().hide();
            $("#telefonoDispositivo").parent().hide();
            $("#hostnameDispositivo").parent().hide();
            $("#inventarioDispositivo").parent().show();
        }
    })
})
// ---------------------------------------------------------------------------------------------

//PARA ASIGNAR DISPOSITIVO
$("#formularioAsignacion").on("click", ".btnNuevaAsignacion", function(event){
    event.preventDefault();

    $("#selectConsultores").on("change", function(){
        $(".invalid-feedback").hide();
    })

    if($("#selectConsultores").val() == ""){
        Swal.fire({
            icon: "warning",
            title: "Por favor seleccione un consultor",
            showConfirmButton: true,
            confirmButtonText: "Cerrar"
        }).then(function(result){
            //window.location = "dispositivos";
        });
    } else{
        
        let datosAsignar = $("#formularioAsignacion").serialize();
        var url = 'fpdf/Asignar.php?' + datosAsignar;

        window.open(url, '_blank');
        $("#modalAsignarDispositivo").hide();
        location.reload();

    }

});

//PARA RECUPERAR DISPOSITIVO ---------------------------------------------------------------------------------
$("#formularioRecuperar").on("click", ".btnRecuperar", function(event){
//$("#formularioAsignacion" ).on( "submit", function( event ) {
    event.preventDefault();
    let datosRecuperar = $("#formularioRecuperar").serialize();
    var url = 'fpdf/Recuperar.php?' + datosRecuperar;

    window.open(url, '_blank');
    $("#modalRecuperarDispositivo").hide();
    location.reload();

});


//Mostrar información de un solo dispositivo
$(".tablaDispositivos").on("click", ".btnMostrarDispositivos", function(){

    /* Resuelve problema de modal fijo */
    $('#modalVerDetalleDispositivo').on('shown.bs.modal', function () {
        $('#modalVerDetalleDispositivo').modal('handleUpdate');
        $('#modalVerDetalleDispositivo').scrollTop(1);
    });

    //Limpiar el elemnto para mostrar el historial, si es que lo tiene
    $(".timelineHistorial").empty();

    var idDispositivo = $(this).attr("idDispositivo");

    var datos = new FormData();
    datos.append("idDispositivo", idDispositivo);

    $.ajax({
        url: localhost + "ajax/dispositivos.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta){
            $("#mostrarTipoDispositivo").text(respuesta[0].tipodispositivo);
            $("#mostrarMarcaDispositivo").text(respuesta[0].marcadispositivo);
            $("#mostrarModeloDispositivo").text(respuesta[0].modelodispositivo);
            $("#mostrarSerieDispositivo").text(respuesta[0].seriedispositivo);
            $("#fechaRegistro").text(respuesta[0].fecharegistro);
            $("#fechaModificacion").text(respuesta[0].fechamodificacion);

            console.log(respuesta);

            if(respuesta[0].tipodispositivo == "Teléfono" || respuesta[0].tipodispositivo == "Tablet"){
                $("#mostrarImeiDispositivo").parent().show();
                $("#mostrarImeiDispositivo").text(respuesta[0].imeidispositivo);
                $("#mostrarTelefonoDispositivo").parent().show();
                $("#mostrarTelefonoDispositivo").text(respuesta[0].telefonodispositivo);
                $("#mostrarInventarioDispositivo").parent().hide();
                $("#mostrarHostnameDispositivo").parent().hide();
            } else if(respuesta[0].tipodispositivo == "Laptop"){
                $("#mostrarImeiDispositivo").parent().hide();
                $("#mostrarTelefonoDispositivo").parent().hide();
                $("#mostrarInventarioDispositivo").parent().show();
                $("#mostrarInventarioDispositivo").text(respuesta[0].inventariodispositivo);
                $("#mostrarHostnameDispositivo").parent().show();
                $("#mostrarHostnameDispositivo").text(respuesta[0].hostnamedispositivo);
            } else{
                $("#mostrarHostnameDispositivo").parent().hide();
                $("#mostrarInventarioDispositivo").parent().show();
                $("#mostrarInventarioDispositivo").text(respuesta[0].inventariodispositivo);
                $("#mostrarImeiDispositivo").parent().hide();
                $("#mostrarTelefonoDispositivo").parent().hide();
            }

            if(respuesta[0].comentariodispositivo != ""){
                $("#mostrarComentarioDispositivo").parent().show();
                $("#mostrarComentarioDispositivo").text(respuesta[0].comentariodispositivo);
            } else{
                $("#mostrarComentarioDispositivo").parent().hide();
            }

            if(respuesta[0].estadodispositivo != "2"){
                $(".sin-accesorios").html("<span class='badge text-bg-primary'>Sin accesorios asignados actualmente</span>");
                $("#checkCubo").parent().hide();
                $("#checkCable").parent().hide();
                $("#checkLapiz").parent().hide();
                $("#checkPowerbank").parent().hide();
                $("#checkFunda").parent().hide();
                $("#checkCargadorLaptop").parent().hide();
                $("#checkMaletin").parent().hide();
                $("#checkMouse").parent().hide();
                $("#checkMousepad").parent().hide();

            } else{
                if(respuesta[0].accesorios != "" || respuesta[0] != null){
                    $(".sin-accesorios").text("");
                    const datos = JSON.parse(respuesta[0].accesorios);
                    if(datos.Cubo == "1"){$("#checkCubo").parent().show();}else{$("#checkCubo").parent().hide();}
                    if(datos.Cable == "1"){$("#checkCable").parent().show();}else{$("#checkCable").parent().hide();}
                    if(datos.Lapiz == "1"){$("#checkLapiz").parent().show();}else{$("#checkLapiz").parent().hide();}
                    if(datos.Powerbank == "1"){$("#checkPowerbank").parent().show();}else{$("#checkPowerbank").parent().hide();}
                    if(datos.Funda == "1"){$("#checkFunda").parent().show();}else{$("#checkFunda").parent().hide();}
                    if(datos.Cargador == "1"){$("#checkCargadorLaptop").parent().show();}else{$("#checkCargadorLaptop").parent().hide();}
                    if(datos.Maletin == "1"){$("#checkMaletin").parent().show();}else{$("#checkMaletin").parent().hide();}
                    if(datos.Mouse == "1"){$("#checkMouse").parent().show();}else{$("#checkMouse").parent().hide();}
                    if(datos.Mousepad == "1"){$("#checkMousepad").parent().show();}else{$("#checkMousepad").parent().hide();}
                } else{
                    console.log("Sin accesorios");
                }

            }
 
            if(respuesta[1] != ""){
                $("#mostrarMovimientos").show();

                //Para mostrar ícono
                var icono_historial;
                switch(respuesta[0].tipodispositivo){
                    case "Laptop": icono_historial = "ni-laptop"; break;
                    case "Tablet": icono_historial = "ni-tablet-button"; break;
                    case "Teléfono": icono_historial = "ni-mobile-button"; break;
                    case "Proyector": icono_historial = "ni-button-play"; break;
                    default: icono_historial = "ni-fat-delete";
                }

                respuesta[1].forEach(datos => {
                    if(datos.fecha_asignacion != ""){
                        
                        if(datos.fecha_recepcion != null){
                            $(".timelineHistorial").append(
                                '<div class=" mb-3">'+
                                    '<span class="timeline-step"><i class="ni '+icono_historial+' text-danger text-gradient"></i></span>'+
                                    '<div class="timeline-content">'+
                                        '<h6 class="text-dark text-sm font-weight-bold mb-0">Recepción</h6>'+
                                        '<p class="text-muted text-xs mt-1 mb-0 d-inline-flex"><span style="margin-right:5px;">'+datos.nombre_receptor+'</span> Ha recuperado el dispositivo de<span class="font-weight-bold mx-2">'+datos.consultor+'</span> en fecha <span class="font-weight-bold" style="margin-left:5px;">'+datos.fecha_recepcion+'</span></p>'+
                                    '</div>'+
                                '</div>'
                            );
    
                        }
    
                        $(".timelineHistorial").append(
                            '<div class=" mb-3">'+
                                '<span class="timeline-step"><i class="ni '+icono_historial+' text-success text-gradient"></i></span>'+
                                '<div class="timeline-content">'+
                                    '<h6 class="text-dark text-sm font-weight-bold mb-0">Asignación</h6>'+
                                    '<p class="text-muted text-xs mt-1 mb-0 d-inline-flex"><span style="margin-right:5px;">'+datos.nombre_asignador+'</span>Ha asignado el dispositivo a <span class="font-weight-bold mx-2">'+datos.consultor+'</span> en fecha <span class="font-weight-bold" style="margin-left:5px;">'+datos.fecha_asignacion+'</span></p>'+
                                '</div>'+
                            '</div>'
                        );
    
                    }
                });

            } else{
                $("#mostrarMovimientos").hide();
            }

            //Datos para reimprimir hoja de asignación            
            if(respuesta[0].responsabledispositivo != null){
                $("#reimprimirHoja").show();
                var acc = JSON.parse(respuesta[0].accesorios);
                const fecha = new Date(respuesta[0].fechaasignacion).toLocaleDateString('en-CA');
                const a = Object.keys(acc)
                    .filter(clave => acc[clave] === "1")
                    .map(clave => `&check${clave}=on`)
                    .join('');
    
                var datosParaReimprimirHoja = "idDispositivoAsignar="+idDispositivo+"&responsableDispositivo="+respuesta[0].responsabledispositivo+a+"&fechaAsignacion="+fecha+"&reimprimir=ok";
                $("#idReimprimir").val(datosParaReimprimirHoja);
            } else{
                $("#reimprimirHoja").hide();
            }

            /* Actualizar el scroll del modal */
            actualizarScrollDispositivos();

        }
    });
});
 
//Convertir a mayúsculas a medida se va escribiendo
function mayus(e) {
    e.value = e.value.toUpperCase();
}

//REGISTRAR NUEVO DISPOSITIVO
$("#formNuevoDispositivo").on("submit", function(e){
    e.preventDefault();

    if($("#tipoDispositivo").val() != "" && $("#marcaDispositivo").val() != "" && $("#modeloDispositivo").val() != "" && $("#serieDispositivo").val() != "" && $("#sedeDispositivo").val() != ""){

        /* if(($("#tipoDispositivo").val() != "Laptop" && $("#imeiDispositivo").val().length == 15) || $("#tipoDispositivo").val() == "Laptop"){ */
            var nuevo = $("#formNuevoDispositivo").serialize();
            console.log(nuevo);
            
            $.ajax({
                url: localhost + "ajax/dispositivos.ajax.php",
                method: "POST",
                data: nuevo,
                dataType: "json",
                success: function(respuesta){
                    Swal.fire({
                        position: "center",
                        icon: respuesta.icono,
                        title: respuesta.titulo,
                        text: respuesta.mensaje,
                        showConfirmButton: true
                      });
        
                    $("#modalDispositivos").modal('hide');
                    table.ajax.reload();
                },
                error: function(res){
                    Swal.fire({
                        position: "center",
                        icon: "error",
                        title: res,
                        showConfirmButton: true
                      });
        
                    $("#modalDispositivos").hide();
                    table.ajax.reload();
                }
            })
        /* } */
    }
})


//RELLENAR CAMPOS PARA EDITAR DISPOSITIVO
$(".tablaDispositivos").on("click", ".btnEditarDispositivo", function(){
    var idEditarDispositivo = $(this).attr("idEditarDispositivo");

    var datos2 = new FormData();
    datos2.append("idEditarDispositivo", idEditarDispositivo);

    $.ajax({
        url: localhost + "ajax/dispositivos.ajax.php",
        method: "POST",
        data: datos2,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta){
            console.log(respuesta);
            if(respuesta['tipodispositivo'] == "Tablet" || respuesta['tipodispositivo'] == "Teléfono"){
                $("#modalEditarDispositivos #editarInventarioDispositivo").parent().hide();
                $("#modalEditarDispositivos #editarHostnameDispositivo").parent().hide();
                $("#modalEditarDispositivos #editarImeiDispositivo").parent().show();
                $("#modalEditarDispositivos #editarTelefonoDispositivo").parent().show();
                $("#modalEditarDispositivos #editarImeiDispositivo").val(respuesta['imeidispositivo']);
                $("#modalEditarDispositivos #editarTelefonoDispositivo").val(respuesta['telefonodispositivo']);
            } else if(respuesta['tipodispositivo'] == "Laptop"){
                $("#modalEditarDispositivos #editarImeiDispositivo").parent().hide();
                $("#modalEditarDispositivos #editarTelefonoDispositivo").parent().hide();
                $("#modalEditarDispositivos #editarInventarioDispositivo").parent().show();
                $("#modalEditarDispositivos #editarHostnameDispositivo").parent().show();
                $("#modalEditarDispositivos #editarInventarioDispositivo").val(respuesta["inventariodispositivo"]);
                $("#modalEditarDispositivos #editarHostnameDispositivo").val(respuesta["hostnamedispositivo"]);
            } else{
                $("#modalEditarDispositivos #editarImeiDispositivo").parent().hide();
                $("#modalEditarDispositivos #editarTelefonoDispositivo").parent().hide();
                $("#modalEditarDispositivos #editarHostnameDispositivo").parent().hide();
                $("#modalEditarDispositivos #editarInventarioDispositivo").parent().show();
                $("#modalEditarDispositivos #editarInventarioDispositivo").val(respuesta["inventariodispositivo"]);
            }

            $("#modalEditarDispositivos #idEditarDispositivo_").val(respuesta['iddispositivo']);
            $("#modalEditarDispositivos #editarTipoDispositivo").val(respuesta['tipodispositivo']);
            $("#modalEditarDispositivos #editarMarcaDispositivo").val(respuesta['marcadispositivo']);
            $("#modalEditarDispositivos #editarModeloDispositivo").val(respuesta['modelodispositivo']);
            $("#modalEditarDispositivos #editarSerieDispositivo").val(respuesta['seriedispositivo']);
            $("#modalEditarDispositivos #editarSedeDispositivo").val(respuesta['sededispositivo']);

            if(!respuesta['responsabledispositivo']){
                $("#modalEditarDispositivos #editarSedeDispositivo").show();
                $(".sede-dispositivo-asignado").html("");
                $(".sede-dispositivo-asignado").hide();
            } else{
                $("#modalEditarDispositivos #editarSedeDispositivo").hide();
                $(".sede-dispositivo-asignado").show();
                $(".sede-dispositivo-asignado").html("<br><span class='badge text-bg-primary'>"+respuesta['sede']+"</span>");
            }

            $("#modalEditarDispositivos #comentarioDispositivo").val(respuesta['comentariodispositivo']);
        }
    })
});

//MODIFICAR LA INFORMACIÓN DEL DISPOSITIVO
$("#formModificarDispositivo").on("submit", function(e){
    e.preventDefault();

    if($("#editarSerieDispositivo").val().length > 8){
        var infoModificar = $("#formModificarDispositivo").serialize();
        //console.log(infoModificar);
        
        $.ajax({
            url: localhost + "ajax/dispositivos.ajax.php",
            method: "POST",
            data: infoModificar,
            dataType: "json",
            success: function(respuesta){
                Swal.fire({
                    position: "center",
                    icon: respuesta.icono,
                    title: respuesta.titulo,
                    text: respuesta.mensaje,
                    showConfirmButton: true
                    });
    
                    table.ajax.reload();
                    $("#modalEditarDispositivos").modal("hide");
            },
            error: function(){
                Swal.fire({
                    position: "center",
                    icon: "error",
                    title: "Error",
                    html: "No fue posible realizar la modificación. <br><span class='text-danger'>Por favor verifique que los datos estén correctos e intente nuevamente.</span>",
                    showConfirmButton: true
                });
    
                table.ajax.reload();
                $("#modalEditarDispositivos").modal("hide");
            }
        });
    }
    
});



//----------------------------------------------------------------------------------------------------------------------------------
//Mostrar información antes de ASIGNAR un dispositivo
$(document).ready(function(){
    $(".tablaDispositivos").on("click", ".btnAsignarDispositivo", function(){

        var idDispositivo = $(this).attr("idDispositivo")
        var datos3 = new FormData();
        datos3.append("idDispositivo", idDispositivo);

        $.ajax({
            url: localhost + "ajax/dispositivos.ajax.php",
            method: "POST",
            data: datos3,
            cache: false,
            contentType: false,
            processData: false,
            dataType: "json",
            success: function(resultado){

                console.log(resultado);

                var respuesta = resultado[0];
                //Mostrar solo los accesorios que corresponen al tipo de dispositivo
                if(respuesta["tipodispositivo"] == "Teléfono"){
                    $(".accesoriosMovil").parent().show();
                    $(".accesoriosLaptop").hide();
                    $(".accesorioLapiz").hide();
                } else if(respuesta["tipodispositivo"] == "Tablet"){
                    $(".accesoriosMovil").parent().show();
                    $(".accesorioLapiz").show();
                    $(".accesoriosLaptop").hide();
                } else if(respuesta["tipodispositivo"] == "Laptop"){
                    $(".accesoriosMovil").parent().hide();
                    $(".accesorioLapiz").hide();
                    $(".accesoriosLaptop").show();
                } else{
                    $(".accesoriosMovil").parent().hide();
                    $(".accesorioLapiz").hide();
                    $(".accesoriosLaptop").hide();
                }
 
                //Mostrar información en la ventana de asignar el dispositivo
                $("#modalAsignarDispositivo .idDispositivoAsignar").val(respuesta['iddispositivo']);
                $("#modalAsignarDispositivo .detalleAsignarTipo").text(respuesta['tipodispositivo']);
                $("#modalAsignarDispositivo .detalleAsignarMarca").text(respuesta['marcadispositivo']);
                $("#modalAsignarDispositivo .detalleAsignarModelo").text(respuesta['modelodispositivo']);

                if(respuesta["imeidispositivo"]){
                    $("#modalAsignarDispositivo .detalleAsignarIMEI").parent().show();
                    $("#modalAsignarDispositivo .detalleAsignarIMEI").text(respuesta['imeidispositivo']);
                    $("#modalAsignarDispositivo .detalleAsignarInventario").parent().hide();
                    $("#modalAsignarDispositivo .detalleAsignarHostname").parent().hide();                    
                } else if(respuesta["hostnamedispositivo"]){
                    $("#modalAsignarDispositivo .detalleAsignarIMEI").parent().hide();
                    $("#modalAsignarDispositivo .detalleAsignarInventario").parent().show();
                    $("#modalAsignarDispositivo .detalleAsignarInventario").text(respuesta['inventariodispositivo']);
                    $("#modalAsignarDispositivo .detalleAsignarHostname").parent().show();
                    $("#modalAsignarDispositivo .detalleAsignarHostname").text(respuesta['hostnamedispositivo']);
                }
                else{
                    $("#modalAsignarDispositivo .detalleAsignarIMEI").parent().hide();
                    $("#modalAsignarDispositivo .detalleAsignarInventario").parent().show();
                    $("#modalAsignarDispositivo .detalleAsignarInventario").text(respuesta['inventariodispositivo']);
                    $("#modalAsignarDispositivo .detalleAsignarHostname").parent().hide();
                }

                if(respuesta["respuesta['telefonodispositivo']"]){
                    $("#modalAsignarDispositivo .detalleAsignarTelefono").parent().show();
                    $("#modalAsignarDispositivo .detalleAsignarTelefono").text(respuesta['telefonodispositivo']);
                }else{
                    $("#modalAsignarDispositivo .detalleAsignarTelefono").parent().hide();
                }

                $("#modalAsignarDispositivo .detalleAsignarSerie").text(respuesta['seriedispositivo']);
                $("#modalAsignarDispositivo .detalleAsignarSede").text(respuesta['sede']);
                $("#modalAsignarDispositivo .detalleAsignarFecha").text(respuesta['fecharegistro']);

                var sededispositivo = respuesta['sededispositivo'];
                var sede = new FormData();
                sede.append("sedeDispositivo", sededispositivo);

                $.ajax({
                    url: localhost + "ajax/consultores.ajax.php",
                    method: "POST",
                    data: sede,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: "json",
                    success: function(res){
                        //var s= document.getElementById('selectConsultores');
                        //s.options[s.options.length]= new Option('Texto', "1");

                        var selectoption = [];
                        function rellenarSelect(){
                            res.forEach(e => {
                                selectoption.push('<option value="'+e['idconsultor']+'">'+e['nombreconsultor']+'</option>');
                            });

                            return selectoption;
                        }

                        $('#modalAsignarDispositivo .mostrarSelect').html(
                            '<select class="form-control choices-single form-select is-invalid" id="selectConsultores" name="responsableDispositivo" required>'+
                                '<option value=""></option>'+
                                rellenarSelect() + 
                            '</select>'
                        );

                        //Aplicar el formato con buscador del select de asignación de dispositivo
                        new Choices(document.querySelector(".choices-single"));
                        
                    }
                })

            }
        })
    })
})

//__________________________________________________________________________________________
//Mostrar información antes de RECUPERAR un dispositivo
$(".tablaDispositivos").on("click", ".btnRecuperarDispositivo", function(){
    var idDispositivoRecuperar = $(this).attr("idDispositivo");
    var consultorResposable = $(this).attr("consultor");
    var datos4 = new FormData();
    datos4.append("idDispositivoRecuperar", idDispositivoRecuperar);
    datos4.append("consultorResposable", consultorResposable);

    $.ajax({
        url: localhost + "ajax/dispositivos.ajax.php",
        method: "POST",
        data: datos4,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(resultado){
            console.log(resultado);
            var respuesta = resultado[0];
            var accesorios = JSON.parse(respuesta["accesorios"]);

            //Mostrar solo los accesorios que corresponen al tipo de dispositivo
            if(respuesta["tipodispositivo"] == "Teléfono"){
                $(".accesorios-devueltos").show();
                $(".recuperarAccesoriosMovil").show();
                $(".recuperarAccesoriosLaptop").hide();
                $(".accesorioLapizR").hide();

                if(accesorios.Cubo == "1"){$("#modalRecuperarDispositivo #checkCubo").parent().show();} else{$(" #modalRecuperarDispositivo #checkCubo").parent().hide();}
                if(accesorios.Cable == "1"){$("#modalRecuperarDispositivo #checkCable").parent().show();} else{$(" #modalRecuperarDispositivo #checkCable").parent().hide();}
                if(accesorios.Funda == "1"){$("#modalRecuperarDispositivo #checkFunda").parent().show();} else{$(" #modalRecuperarDispositivo #checkFunda").parent().hide();}
                if(accesorios.Powerbank == "1"){$("#modalRecuperarDispositivo #checkPowerbank").parent().show();} else{$(" #modalRecuperarDispositivo #checkPowerbank").parent().hide();}

            } else if(respuesta["tipodispositivo"] == "Tablet"){
                $(".accesorios-devueltos").show();
                $(".recuperarAccesoriosMovil").show();
                $(".accesorioLapizR").show();
                $(".recuperarAccesoriosLaptop").hide();

                if(accesorios.Cubo == "1"){$("#modalRecuperarDispositivo #checkCubo").parent().show();} else{$(" #modalRecuperarDispositivo #checkCubo").parent().hide();}
                if(accesorios.Cable == "1"){$("#modalRecuperarDispositivo #checkCable").parent().show();} else{$(" #modalRecuperarDispositivo #checkCable").parent().hide();}
                if(accesorios.Funda == "1"){$("#modalRecuperarDispositivo #checkFunda").parent().show();} else{$(" #modalRecuperarDispositivo #checkFunda").parent().hide();}
                if(accesorios.Lapiz == "1"){$("#modalRecuperarDispositivo #checkLapiz").parent().show();} else{$(" #modalRecuperarDispositivo #checkLapiz").parent().hide();}
                if(accesorios.Powerbank == "1"){$("#modalRecuperarDispositivo #checkPowerbank").parent().show();} else{$(" #modalRecuperarDispositivo #checkPowerbank").parent().hide();}


            } else if(respuesta["tipodispositivo"] == "Laptop"){
                $(".accesorios-devueltos").show();
                $(".recuperarAccesoriosMovil").hide();
                $(".accesorioLapizR").hide();
                $(".recuperarAccesoriosLaptop").show();

                if(accesorios.Maletin == "1"){$("#modalRecuperarDispositivo #checkMaletin").parent().show();} else{$(" #modalRecuperarDispositivo #checkMaletin").parent().hide();}
                if(accesorios.Cargador == "1"){$("#modalRecuperarDispositivo #checkCargador").parent().show();} else{$(" #modalRecuperarDispositivo #checkCargador").parent().hide();}
                if(accesorios.Mouse == "1"){$("#modalRecuperarDispositivo #checkMouse").parent().show();} else{$(" #modalRecuperarDispositivo #checkMouse").parent().hide();}
                if(accesorios.Mousepad == "1"){$("#modalRecuperarDispositivo #checkMousepad").parent().show();} else{$(" #modalRecuperarDispositivo #checkMousepad").parent().hide();}

            } else{
                $(".accesorios-devueltos").hide();
                $(".recuperarAccesoriosMovil").hide();
                $(".accesorioLapizR").hide();
                $(".recuperarAccesoriosLaptop").hide();
            }
            
            
            //Mostrar información en la ventana de Recuperar el dispositivo
            $("#responsableRecuperar").text(resultado[1]["nombreconsultor"]);
            $("#responsableActual").val(resultado[1]["idconsultor"]);

            $("#modalRecuperarDispositivo .idDispositivoRecuperar").val(respuesta['iddispositivo']);
            $("#modalRecuperarDispositivo .detalleRecuperarTipo").text(respuesta['tipodispositivo']);
            $("#modalRecuperarDispositivo .detalleRecuperarMarca").text(respuesta['marcadispositivo']);
            $("#modalRecuperarDispositivo .detalleRecuperarModelo").text(respuesta['modelodispositivo']);

            if(respuesta["imeidispositivo"]){
                $("#modalRecuperarDispositivo .detalleRecuperarIMEI").parent().show();
                $("#modalRecuperarDispositivo .detalleRecuperarIMEI").text(respuesta['imeidispositivo']);
                $("#modalRecuperarDispositivo .detalleRecuperarInventario").parent().hide();
                $("#modalRecuperarDispositivo .detalleRecuperarHostname").parent().hide();  
            }else if(respuesta["hostnamedispositivo"]){
                $("#modalRecuperarDispositivo .detalleRecuperarIMEI").parent().hide();
                $("#modalRecuperarDispositivo .detalleRecuperarHostname").parent().show(); 
                $("#modalRecuperarDispositivo .detalleRecuperarHostname").text(respuesta['inventariodispositivo']); 
                $("#modalRecuperarDispositivo .detalleRecuperarInventario").parent().show();
                $("#modalRecuperarDispositivo .detalleRecuperarInventario").text('hostnamedispositivo');
            } else{
                $("#modalRecuperarDispositivo .detalleRecuperarIMEI").parent().hide();
                $("#modalRecuperarDispositivo .detalleRecuperarInventario").parent().show();
                $("#modalRecuperarDispositivo .detalleRecuperarInventario").text(respuesta['inventariodispositivo']);
                $("#modalRecuperarDispositivo .detalleRecuperarHostname").parent().hide();
            }

            if(respuesta["respuesta['telefonodispositivo']"]){
                $("#modalRecuperarDispositivo .detalleRecuperarTelefono").parent().show();
                $("#modalRecuperarDispositivo .detalleRecuperarTelefono").text(respuesta['telefonodispositivo']);
            }else{
                $("#modalRecuperarDispositivo .detalleRecuperarTelefono").parent().hide();
            }
 
            $("#modalRecuperarDispositivo .detalleRecuperarSerie").text(respuesta['seriedispositivo']);
            $("#modalRecuperarDispositivo .detalleRecuperarSede").text(respuesta['sede']);
            $("#modalRecuperarDispositivo .detalleRecuperarFecha").text(respuesta['fecharegistro']);

        }
    })
    
})


//__________________________________________________________________________________________
//Eliminar dispositivo 
$(".tablaDispositivos").on("click", ".btnEliminarDispositivo", function(){
    Swal.fire({
        title: "Eliminar dispositivo",
        text: "¿Está seguro que desea eliminar este dispositivo?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Sí, eliminar",
        cancelButtonText: "Cancelar",
      }).then((result) => {
        if (result.isConfirmed) {
            var idEliminarDispositivo = $(this).attr("idEliminarDispositivo");

            var datos = new FormData();
            datos.append("idEliminarDispositivo", idEliminarDispositivo);

            $.ajax({
                url: localhost + "ajax/dispositivos.ajax.php",
                method: "POST",
                data: datos,
                cache: false,
                contentType: false,
                processData: false,
                dataType: "json",
                success: function(respuesta){
                    Swal.fire({
                        title: respuesta.titulo,
                        text: respuesta.mensaje,
                        icon: respuesta.icono,
                        showConfirmButton: true
                      });

                      table.ajax.reload();
                }
            })
        }
      });

});

//__________________________________________________________________________________________
// VALIDACIÓN DE CAMPOS PARA NUEVO REGISTRO
(function () {
    'use strict'

        //Resetear formularios de modal, en cuanto el modal se oculte
        $("#modalDispositivos").on("hidden.bs.modal", function () {
            $(this).find('form')[0].reset();
        });

        //Limpiar modal cuando se oculte
        $("#modalAsignarDispositivo").on("hidden.bs.modal", function () {
            $(this).find('form')[0].reset();
        });

    var forms = document.querySelectorAll('.needs-validation')

    Array.prototype.slice.call(forms).forEach(function (form) {
      function handleButtonClick(event) {
        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
          }
          form.classList.add('was-validated');
        }

        form.addEventListener('submit', handleButtonClick);

        function handleModalClose(){
          form.classList.remove('was-validated');
        }

        document.getElementById('modalDispositivos').addEventListener('hidden.bs.modal', handleModalClose);
      })
  })();

//-----------------------------------------------------------------------------------------------------------
/* Actualizar Scroll */
function actualizarScrollDispositivos(){
    $('#modalVerDetalleDispositivo').modal('handleUpdate');
    $('#modalVerDetalleDispositivo').scrollTop(1);

    $('#modalVerDetalleDispositivo').scroll(function() {
        var scrollPosition = $(this).scrollTop();
        /* console.log("Posición del scroll: " + scrollPosition); */

        if(scrollPosition < 1){
            $('#modalVerDetalleDispositivo').scrollTop(1);
        }
    });
}


//-------------------------------------------------------------------------------------------------------------
//CARGAR DATOS DE DISPOSITIVOS DESDE CSV

    $('#cargarDataDispositivos').on('submit', function(e){
        e.preventDefault();
        var formData = new FormData(this);

        $.ajax({
            url: localhost + 'ajax/cargarDataDispositivos.ajax.php',
            type: 'POST',
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            dataType: "json",
            success: function(respuesta){
                var noinsertados = respuesta.noinsertados != "" ? '<span class="badge text-bg-warning">Hubo un problema con los siguientes registros: </span><br>'+respuesta.noinsertados : "";

                Swal.fire({
                    title: respuesta.titulo,
                    html: '<p>'+respuesta.mensaje + " " + respuesta.cantidad+"/"+respuesta.total+'</p><br>'+noinsertados,
                    icon: respuesta.icono,
                    confirmButtonText: "Ok"
                  }).then((result) => {
                    if(result.isConfirmed){
                        parent.window.location.reload();
                    }
                  });
                  
                $("#modalCargarData").empty();
                $("#modalCargarData").hide();
                table.ajax.reload();
            },
            error: function(){
                Swal.fire({
                    title: "Atención",
                    text: "Error, el archivo seleccionado no contiene el formato esperado.",
                    icon: "error",
                    confirmButtonText: "Ok"
                  });
            }
        });
    });

//-------------------------------------------------------------------------------------------------------------
//Refrescar página.
$(".btn_refresh").click(function(){
    parent.window.location.reload();
});

//--------------------------------------------------------------------------------------------------------------
//DESCARGAR FORMATO EN CSV DE DISPOSITIVOS
$("#btnFormatoDispositivos").click(function(){
    let contenidoCSV = "data:text/csv;charset=utf-8,\uFEFF";
    contenidoCSV += "TIPO DE DISPOSITIVO;MARCA;MODELO;IMEI;SERIE;TELÉFONO;INVENTARIO;HOSTNAME;SEDE;ESTADO/CONDICIÓN\n";
    contenidoCSV += "Teléfono;Samsung;Galaxy A34;123451234512345;ASDFG12345AS;78727382;1234-1234;Hostname01;1;1\n";

    const encodedUri = encodeURI(contenidoCSV);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "formato_dispositivos.csv");

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
});



// REIMPRIMIR HOJA DE ASIGNACIÓN -------------------------------------------------

$("#reimprimirHoja").click(function(){
    let datosReimprimir = $("#idReimprimir").val();
    var url = 'fpdf/Asignar.php?' + datosReimprimir;

    window.open(url, '_blank');
    location.reload();
})