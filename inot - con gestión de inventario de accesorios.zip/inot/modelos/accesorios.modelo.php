<?php 
 
require_once "conexion.php";

class ModeloAccesorios{

    /* MOSTRAR LISTA DE ACCESORIOS */
    public static function mdlMostrarListaAccesorios($tabla){
        $sql = "SELECT * FROM $tabla";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    /* OBTENER CANTIDAD DE ACCESORIOS */
    public static function mdlMostrarCantidadAccesorios($tabla, $datos){
        $sql = "SELECT COUNT(*) as cantidad FROM $tabla WHERE accesorio_id = :accesorio_id AND sede_id = :sede";
        $stmt = Conexion::conectar()->prepare($sql);
        $stmt->bindParam(':accesorio_id', $dato["accesorio"], PDO::PARAM_INT);
        $stmt->bindParam(':sede', $dato["sede"], PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetch();
    }

    /* MOSTRAR REGISTROS DE ACCESORIOS */
    public static function mdlMostrarRegistrosAccesorios($tabla, $item, $valor){
        if($item != null){
            

        } else{
            $sql = "SELECT ra.*, a.nombreaccesorio as accesorio, s.nombresede as sede FROM $tabla ra INNER JOIN accesorios a ON a.idaccesorio = ra.accesorio_id INNER JOIN sedes s ON s.idsede = ra.sede_id ORDER BY ra.fecha DESC";
            $stmt = Conexion::conectar()->prepare($sql);
            $stmt->execute();

            return $stmt->fetchAll();
            
        }
    }

    public static function mdlRegistrarMovimiento($tabla, $datos){
        try {
            /* Obtener la cantidad existente */
            $sql = "SELECT inventarioactual FROM registros_accesorios WHERE accesorio_id = :acc_id AND sede_id = :sede_acc ORDER BY fecha DESC LIMIT 1";

            $stmt = Conexion::conectar()->prepare($sql);
            $stmt->bindValue(':acc_id', $datos["accesorio_id"], PDO::PARAM_INT);
            $stmt->bindValue(':sede_acc', $datos["sede_id"], PDO::PARAM_INT);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

            $tm = $datos["tipo_movimiento"];
            if($resultado != null){
                $total_actual = (int)$resultado['inventarioactual'];
                $cantidad = (int)$datos["cantidadaccesorio"];

                if ($tm == "Inventario inicial" || $tm == "Nuevo lote" || $tm == "Recepción") {
                    $nueva_cantidad = $cantidad + $total_actual;
                } else if($tm == "Salida por ajuste" || $tm == "Extravío" || $tm == "Dañado" || $tm == "Asignación"){
                    $nueva_cantidad = $total_actual - $cantidad;
                }

            } else{
                $cantidad = (int)$datos["cantidadaccesorio"];
                if ($tm == "Inventario inicial" || $tm == "Nuevo lote" || $tm == "Recepción") {
                    $nueva_cantidad = $cantidad;
                } else if($tm == "Salida por ajuste" || $tm == "Extravío" || $tm == "Dañado" || $tm == "Asignación"){
                    $nueva_cantidad = (int)$cantidad*(-1);
                }
            }


            $sql = "INSERT INTO $tabla (accesorio_id, cantidadaccesorio, inventarioactual, sede_id, tipo_movimiento, comentarioaccesorio, fecha) VALUES (:acc_id, :cantidad, :inventarioactual, :sede_acc, :movimiento, :comentario, :fecha_registro)";

            $reg_movimiento = Conexion::conectar()->prepare($sql);
            $reg_movimiento->bindValue(':acc_id', $datos["accesorio_id"], PDO::PARAM_INT);
            $reg_movimiento->bindValue(':cantidad', $datos["cantidadaccesorio"], PDO::PARAM_INT);
            $reg_movimiento->bindValue(':inventarioactual', $nueva_cantidad, PDO::PARAM_INT);
            $reg_movimiento->bindValue(':sede_acc', $datos["sede_id"], PDO::PARAM_INT);
            $reg_movimiento->bindValue(':movimiento', $datos["tipo_movimiento"], PDO::PARAM_STR);
            $reg_movimiento->bindValue(':comentario', $datos["comentarioaccesorio"], PDO::PARAM_STR);
            $reg_movimiento->bindValue(':fecha_registro', $datos["fecha"], PDO::PARAM_STR);
                
            if($reg_movimiento->execute()){
                $reg_movimiento = null;
                return "ok";
            }

        } catch (\Throwable $th) {
            return $th->getMessage();
        }
    }

}