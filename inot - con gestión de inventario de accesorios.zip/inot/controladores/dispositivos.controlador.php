<?php

class ControladorDispositivos{

    static public function ctrMostrarDispositivos($item, $valor){
        $tabla = "dispositivos";
        $datos = ModeloDispositivos::mdlMostrarDispositivos($tabla, $item, $valor);

        return $datos;
    }
    
    //METODO PARA MOSTRAR INFORMACION DE DISPOSITIVO A RECUPERAR _______________________________________________________
    static public function ctrMostrarDispositivoRecuperar($item, $valor, $consultor){
        $tabla = "dispositivos";
        $datos = ModeloDispositivos::mdlMostrarDispositivoRecuperar($tabla, $item, $valor, $consultor);

        return $datos;
    }

    //REGISTRAR NUEVO DISPOSITIVOS ____________________________________________________________________________________
    static public function ctrRegistrarDispositivo($datos, $accesorios){
        $tabla = "dispositivos";
        $respuesta = ModeloDispositivos::mdlRegistrarDispositivo($tabla, $datos, $accesorios);

        if($respuesta == "ok"){
            return array("titulo" => "Éxito", "mensaje" => "Registro realizado exitosamente.", "icono" => "success");
        }else{
            return array("titulo" => "Error", "mensaje" => $respuesta, "icono" => "error");
        }
    }


    //MODIFICAR DISPOSITIVO __________________________________________________________________________________________
    static public function ctrModificarDispositivo($item, $valor, $datos){
        $tabla = "dispositivos";
        $respuesta = ModeloDispositivos::mdlModificarDispositivo($tabla, $item, $valor, $datos);

        if($respuesta == "ok"){
            return array("mensaje" => "Información del dispositivo modificada correctamente.", "icono" => "success", "titulo" => "Éxito");
        }else{
            return array("mensaje" => "No ha sido posible modificar la información del dispositivo", "icono" => "error", "titulo" => "Algo salió mal");
        }

    }

    //CAMBIAR ESTADO DE DISPOSITIVO AL RECUPERARLO ____________________________________________________________________
    static public function ctrCambiarEstadoDispositivo($item, $valor, $accesorios, $receptor, $estado, $comentario, $fecha){
        $tabla = "dispositivos";
        $respuesta = ModeloDispositivos::mdlCambiarEstadoDispositivo($tabla, $item, $valor, $accesorios, $receptor, $estado, $comentario, $fecha);

        if($respuesta == "ok"){
            return array("mensaje" => "Dispositivo recuperado satisfactoriamente.", "icono" => "success", "titulo" => "Éxito");
        }else{
            return array("mensaje" => "No ha sido posible recuperar el dispositivo", "icono" => "error", "titulo" => "Algo salió mal");
        }
    }


    //ASIGNAR DISPOSITIVO _____________________________________________________________________________________________
    static public function ctrAsignarDispositivo($id, $res, $accesorios, $asignador, $fecha){
       $tabla = "dispositivos";

       $respuesta = ModeloDispositivos::mdlAsignarDispositivo($tabla, $id, $res, $accesorios, $asignador, $fecha);

       if($respuesta == "ok"){
           $item = "iddispositivo";
           return array("mensaje" => "Dispositivo asignado satisfactoriamente.", "icono" => "success", "titulo" => "Éxito");

           /* Esto es para imprimir el acta */
           /* $infodispositivo = ModeloDispositivos::mdlMostrarDispositivoAsignado($tabla, $item, $id);
           return $infodispositivo; */
           
       } else{
            return array("mensaje" => "No ha sido posible modificar la información del dispositivo", "icono" => "error", "titulo" => "Algo salió mal");

        /* Esto es para imprimir el acta */
            /* return $respuesta; */
       }
   }

   //RECUPERAR DISPOSITIVO
   /*static public function ctrRecuperarDispositivo($id, $accesorios){
    $tabla = "dispositivos";
    $item = "iddispositivo";
    $infodispositivo = ModeloDispositivos::mdlMostrarDispositivoAsignado($tabla, $id, $accesorios);
    return $infodispositivo;

   }*/

   /* CAMBIAR ESTADO DE DISPOSITIVO (ACTIVO - INACTIVO) */
   static public function ctrCambiarEstadoDispositivoAI($dato, $description, $rutaguardar, $item, $valor){
        $tabla = "dispositivos";

        $respuesta = ModeloDispositivos::mdlCambiarEstadoDispositivoAI($tabla, $dato, $description, $rutaguardar, $item, $valor);

        if($respuesta == "ok"){
            return array("titulo" => "Éxito", "mensaje" => "Se cambió el estado del dispositivo de manera exitosa.", "icono" => "success");
        } else{
            return array("titulo" => "Error", "mensaje" => "No ha sido posible cambiar el estado del dispositivo", "icono" => "error");
        }
   }

    //ELIMINAR DISPOSITIVO
    static public function ctrEliminarDispositivo($item, $valor){
        $tabla = "dispositivos";

        $respuesta = ModeloDispositivos::mdlEliminarDispositivos($tabla, $item, $valor);

        if($respuesta == "ok"){
            return array("titulo" => "Éxito", "mensaje" => "Dispositivo eliminado satisfactoriamente.", "icono" => "success");
        }else{
            return array("titulo" => "Error", "mensaje" => "No ha sido posible eliminar el dispositivo", "icono" => "error");
        }

    }

}
