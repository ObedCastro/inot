<?php

class ControladorAccesorios{

    static public function ctrMostrarListaAccesorios(){
        $tabla = "accesorios";

        $listaAccesorios = ModeloAccesorios::mdlMostrarListaAccesorios($tabla);
        return $listaAccesorios;
    }
    
    static public function ctrMostrarCantidadAccesorios($dato){
        $tabla = "registros_accesorios";

        $cantidadAccesorios = ModeloAccesorios::mdlMostrarCantidadAccesorios($tabla, $dato);
        return $cantidadAccesorios;
    }

    /*  */
    static public function ctrMostrarRegistrosAccesorios($item, $valor){
        $tabla = "registros_accesorios";

        $registros_accesorios = ModeloAccesorios::mdlMostrarRegistrosAccesorios($tabla, $item, $valor);
        return $registros_accesorios;
    }

    static public function ctrRegistrarMovimiento($datos){
        $tabla = "registros_accesorios";

        $movimiento_accesorio = ModeloAccesorios::mdlRegistrarMovimiento($tabla, $datos);
        
        if($movimiento_accesorio == "ok"){
            return array("icono" => "success", "titulo" => "Éxito", "mensaje" => "Registro realizado exisosamente.");
        } else{
            return array("icono" => "error", "titulo" => "Error", "mensaje" => "No ha sido posible realizar este registro \nPor favor compruebe la información.");
        }
    }

}