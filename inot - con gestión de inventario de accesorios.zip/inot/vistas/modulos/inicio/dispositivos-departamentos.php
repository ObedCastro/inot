
<div class="col-lg-12 mb-lg-0 mb-4">
  <div class="card z-index-2">
    <div class="card-body p-3">

      <!-- Muestra totales por departamento -->
      <h6 class="mt-2 mb-0 tituloInicio"> Dispositivos por departamentos </h6>
      <div class="container border-radius-lg">
        <div class="row justify-content-center">
          
          <?php
            $dispositivosDepartamento = ControladorInicio::ctrMostrarDispositivosDepartamento();
            $colorIcon = array("bg-gradient-primary", "bg-gradient-success", "bg-gradient-warning", "bg-gradient-danger", "bg-gradient-dark", "bg-gradient-secondary", "bg-gradient-primary", "bg-gradient-success", "bg-gradient-warning", "bg-gradient-danger", "bg-gradient-dark", "bg-gradient-secondary");

            $dispositivosRegion = ControladorInicio::ctrMostrarDispositivosRegion();  
            $total = 0;   
            
            foreach ($dispositivosDepartamento as $item) {
              if (isset($item['total'])) {
                  $total += $item['total'];
              }
            }

            foreach ($dispositivosDepartamento as $key => $value) {
              $departamento = $value["departamento"];
              $totalDepartamento = $value["total"];

              $detalleRegiones = "";

              foreach ($dispositivosRegion as $region) {
                if($region["departamento"] == $departamento){
                  $detalleRegiones .= "<p class='my-1 d-flex justify-content-left'>".$region["region"]." &#8594;  <span class='badge bg-success'> Total: ".$region["total"]."</span></p>";
                }
              }

              echo '<br>';

              echo '<div class="col-md-1 col-sm-6 py-3 infoRegiones" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-html="true" title="'.$detalleRegiones.'">
                <div class="d-flex mb-2">
                  <div class="icon icon-shape icon-s shadow border-radius-sm '.$colorIcon[$key].' text-center me-2 d-flex align-items-center justify-content-center">
                  <svg width="25px" height="25px" viewBox="0 0 42 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> <title></title> <g id="Basic-Elements" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Rounded-Icons" transform="translate(-1869.000000, -293.000000)" fill="#FFFFFF" fill-rule="nonzero"> <g id="Icons-with-opacity" transform="translate(1716.000000, 291.000000)"> <g id="office" transform="translate(153.000000, 2.000000)"> <path class="color-background" d="M12.25,17.5 L8.75,17.5 L8.75,1.75 C8.75,0.78225 9.53225,0 10.5,0 L31.5,0 C32.46775,0 33.25,0.78225 33.25,1.75 L33.25,12.25 L29.75,12.25 L29.75,3.5 L12.25,3.5 L12.25,17.5 Z" id="Path" opacity="0.6"></path> <path class="color-background" d="M40.25,14 L24.5,14 C23.53225,14 22.75,14.78225 22.75,15.75 L22.75,38.5 L19.25,38.5 L19.25,22.75 C19.25,21.78225 18.46775,21 17.5,21 L1.75,21 C0.78225,21 0,21.78225 0,22.75 L0,40.25 C0,41.21775 0.78225,42 1.75,42 L40.25,42 C41.21775,42 42,41.21775 42,40.25 L42,15.75 C42,14.78225 41.21775,14 40.25,14 Z M12.25,36.75 L7,36.75 L7,33.25 L12.25,33.25 L12.25,36.75 Z M12.25,29.75 L7,29.75 L7,26.25 L12.25,26.25 L12.25,29.75 Z M35,36.75 L29.75,36.75 L29.75,33.25 L35,33.25 L35,36.75 Z M35,29.75 L29.75,29.75 L29.75,26.25 L35,26.25 L35,29.75 Z M35,22.75 L29.75,22.75 L29.75,19.25 L35,19.25 L35,22.75 Z"></path> </g> </g> </g> </g> </svg>
                  </div>
    
                </div>
                <p class="text-s mt-1 mb-0 font-weight-bold">'.$value["departamento"].'</p>
                <p class="font-weight-bolder display-6">'.$value["total"].'</p>
                <div class="progress w-75">
                  <div class="progress-bar bg-dark" role="progressbar" style="width: '.round(($value["total"]/$total)*100,0).'%" aria-valuenow="'.round(($value["total"]/$total)*100,0).'" aria-valuemax="'.$total.'"></div>
                </div>
              </div>';
              
            }
          ?>
          
        </div>
      </div>
    </div>
  </div>
</div>