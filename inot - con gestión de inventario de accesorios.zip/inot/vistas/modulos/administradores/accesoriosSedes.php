<div class="modal fade" id="modalAccesoriosSedes" tabindex="-1" aria-labelledby="modalAccesoriosSedesLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill cursor-pointer btn-cerrar-modal" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-remove text-white"></i></span>
        <h1 class="modal-title fs-5 text-white" id="modalAccesoriosSedesLabel"><i class="fa fa-book"></i>Inventario de accesorios</h1>
        <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
      </div>
      <div class="modal-body">

        <form method="POST" id="formularioMovAccesorios" class="needs-validation" novalidate>
          <input type="hidden" name="mov" value="mov">

          <div class="row">
            <div class="mb-3 col-md-8">
              <label for="sedeAccesorios" class="form-label">Sede<span class="text-danger">*</span></label>
              <select id="sedeAccesorios" name="sedeAccesorios" class="form-select" required>
              <option value>Seleccionar</option>
                <?php 
                  $sedes = ControladorSedes::ctrMostrarSedes(null, null);
                  foreach ($sedes as $key => $sede) {
                    echo '<option value="'.$sede['idsede'].'">'.$sede['nombresede'].' '.$sede['departamentosede'].'</option>';
                  }
                ?>
              </select>
              <div class="invalid-feedback">Debe seleccionar la sede</div>
            </div>

            <div class="mb-3 col-md-4">
              <label for="movimientoAccesorio" class="form-label">Tipo de movimiento<span class="text-danger">*</span></label>
              <select id="movimientoAccesorio" name="movimientoAccesorio" class="form-select" required>
                <option value>Seleccionar</option>
                <option value="Inventario inicial">Inventario inicial</option>
                <option value="Nuevo lote">Nuevo lote</option>
                <option value="Salida por ajuste">Salida por ajuste</option>
                <option value="Extravío">Extravío</option>
                <option value="Dañado">Dañado</option>
              </select>
              <div class="invalid-feedback">Este campo es requerido</div>
            </div>
          </div>

          <div class="row mb-3 taComentarioAcc">
            <div class="col-md-12">
              <label for="comentarioAcc" class="form-label">Comentario<span class="text-danger"></span></label>
              <textarea type="text" class="form-control" id="comentarioAcc" name="comentarioAcc"></textarea>
            </div>
          </div>
 
          <div class="row">
            <div class="col-md-5">
              <label for="opcionAccesorio" class="form-label">Accesorio<span class="text-danger">*</span></label>
              <select id="opcionAccesorio" name="opcionAccesorio" class="form-select" required>
              <option value>Seleccionar</option>
                <?php
                  $lista_accesorios = ControladorAccesorios::ctrMostrarListaAccesorios();
                  foreach ($lista_accesorios as $key => $value) {
                    echo '<option value="'.$value["idaccesorio"].'">'.$value["nombreaccesorio"].'</option>';
                  }
                  
                ?>
              </select>
              <div class="invalid-feedback">Este campo es requerido</div>
            </div>

            <div class="col-md-2">
              <label for="cantAccesorio" class="form-label">Cantidad<span class="text-danger">*</span></label>
              <input type="number" class="form-control" id="cantAccesorio" name="cantAccesorio" required>
              <div class="invalid-feedback">Ingrese la cantidad</div>
            </div>

            <div class="col-md-3">
              <?php
                date_default_timezone_set('America/El_Salvador');
                $fechahoy = date("Y-m-d");
                echo '<label for="fecha_mov" class="form-label">Fecha<span class="text-danger">*</span></label>';
                echo '<input type="date" class="form-control" name="fecha_mov" id="fecha_mov" value="'.$fechahoy.'">';
              ?>
            </div>
            
            <div class="col-md-2" style="align-content: end; padding-bottom: 2px;">
              <button class="btn btn-primary mb-0" style="width:100%;">Guardar</button>
            </div>
          </div>
        </form>

        <div class="row px-3 mt-5">
          <span class="badge bg-secondary text-center mb-2">MOVIMIENTOS</span>
          <table class="table table-hover table-sm" id="datatableAccesorios">
            <thead>
              <tr>
                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-9 clicar">Sede</th>
                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-9 clicar">Accesorio</th>
                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-9 ps-2">Tipo de movimiento</th>
                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-9 ps-2">Cantidad</th>
                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-9 ps-2">Total actual</th>
                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-9 ps-2">Fecha</th>
              </tr>
            </thead>

            <!--<tbody>
            </tbody>-->
          </table>
        </div>

        <div class="text-end modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cerrar</button>
          <!-- <button type="submit" class="btn btn-primary" name="opcion">Guardar</button> -->
        </div>

      </div>
    </div>
  </div>
</div>