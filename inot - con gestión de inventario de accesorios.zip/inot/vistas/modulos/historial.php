<!-- MODAL DE DISPOSITIVOS -->

<div class="container">  
  <p class="text-bold">HISTORIAL DE DISPOSITIVOS</p>
  <div class="row">
    <form id="formBuscarhistorial" class="filtrar-historial">
      <input type="text" class="form-control" id="historialImei" name="historialImei" placeholder="Filtrar por IMEI">
      <input type="text" class="form-control" id="historialSerie" name="historialSerie" placeholder="Filtrar por Serie">
      <input type="text" class="form-control" id="historialInventario" name="historialInventario" placeholder="Filtrar por Inventario">
      <button type="submit" class="btn btn-primary btn-filtrar-historial">Buscar</button>
    </form>
  </div> 

  <div class="row detalles-dispositivos">
    <p class="mb-3 text-lg font-weight-bold">DETALLES</p>
        
    <div class="d-flex flex-column col-md-4 detalles-col1">
      <span class="mb-1 text-xs">Tipo de dispositivo: <span id="mostrarTipoDispositivo" class="text-dark font-weight-bold ms-sm-2"></span></span>
      <span class="mb-1 text-xs">Marca: <span id="mostrarMarcaDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
      <span class="mb-1 text-xs">Modelo: <span id="mostrarModeloDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
      <span class="mb-1 text-xs">IMEI: <span id="mostrarImeiDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
    </div>

    <div class="d-flex flex-column col-md-4 detalles-col2">
      <span class="mb-1 text-xs">Serie: <span id="mostrarSerieDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
      <span class="mb-1 text-xs">Número de inventario: <span id="mostrarInventarioDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
      <span class="mb-1 text-xs">Hostname: <span id="mostrarHostnameDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
    </div>

    <div class="d-flex flex-column col-md-4 detalles-col3">
      <span class="mb-1 text-xs">Teléfono: <span id="mostrarTelefonoDispositivo" class="text-dark ms-sm-2 font-weight-bold"></span></span>
      <span class="mb-1 text-xs">Fecha de registro: <span id="fechaRegistro" class="text-dark font-weight-bold ms-sm-2"></span></span>
      <span class="mb-1 text-xs">Fecha de última modificación: <span id="fechaModificacion" class="text-dark ms-sm-2 font-weight-bold"></span></span>
    </div>

  </div>  

  <div class="row mt-3">
    <p class="text-bold text-center">HISTORIAL DE DISPOSITIVOS <i class="fa fa-arrow-down"></i></p>
    <div class="col-md-12" id="mostrarMovimientos">
      
      <div class="timeline timeline-one-side historial-timeline">
        <!-- <div class="timeline-block mb-3">
          <span class="timeline-step">
            <i class="ni ni-bell-55 text-success text-gradient"></i>
          </span>
          <div class="timeline-content">
            <p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Recepción</p>
            <h6 class="text-dark text-sm font-weight-bold mb-0">Obed ha realizado la recepción de este dispositivo, del usuario Miguel Ángel Portillo Lozano (Consultor BID), destacado en la sede Concepción Batres, Usulután, con el cargo de Técnico Agroecuario y de Pesca.</h6>
            <p class="text-secondary font-weight-bold text-xs mt-1 mb-0">22 DEC 7:20 PM</p>
          </div>
        </div> -->
      </div>
    </div>
  </div>
  
</div>


