/* LIMPIAR SELECTS */
$("#modalAccesoriosSedes").on("hidden.bs.modal", function () {
    limpiarSelectsFormulario('modalAccesoriosSedes');
  });

// VALIDACIÓN DE CAMPOS
(function () {
    'use strict'
  
    var forms = document.querySelectorAll('.needs-validation')
  
    Array.prototype.slice.call(forms).forEach(function (form) {
      function handleButtonClick(event) {
        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
          }
          form.classList.add('was-validated');
        }
  
        form.addEventListener('submit', handleButtonClick);
  
        function handleModalClose(){
          form.classList.remove('was-validated');
        }
  
        document.getElementById('modalAccesoriosSedes').addEventListener('hidden.bs.modal', handleModalClose);
      })
  })();

//Datatabla + traducción
let tabla = new DataTable('#datatableAccesorios', {
    ajax: 'ajax/tablaAccesorios.ajax.php',
    ordering: false,
    columns: [
        { 
            data: 'sede',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'accesorio',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'tipo_movimiento',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'cantidadaccesorio',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'inventarioactual',
            render: function (data, type) {
                return '<span class="text-xs">'+data+'</span>';
            }
        },
        { 
            data: 'fecha',
            render: function (data, type) {                
                return '<span class="text-xs">'+data+'</span>';
            }
        }
    ],
    language: {
        "decimal": "",
        "emptyTable": "No hay información",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
        "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
        "infoFiltered": "(Filtrado de _MAX_ total entradas)",
        "infoPostFix": "",
        "thousands": ",",
        "lengthMenu": "Mostrar _MENU_ Entradas",
        "loadingRecords": "Cargando...",
        "processing": "Procesando...",
        "search": "Buscar:",
        "zeroRecords": "Sin resultados encontrados",
        "paginate": {
            "first": "Primero",
            "last": "Ultimo",
            "next": "Siguiente",
            "previous": "Anterior"
        }
    },
    dom: 'Bfrtip',
          buttons: [
              {
                extend: 'pdfHtml5',
                className: 'btnDt btn-app export pdf',
                titleAttr: 'PDF',
                text: '<i class="fa fa-file-pdf-o" aria-hidden="true" data-bs-toggle="tooltip" data-bs-placement="top" title="Exportar a PDF"></i>',
                download: 'open',
                exportOptions: {
                    columns: [0,1,2,3]
                },
                title: "Listado de dispositivos",
                customize: function(doc) {
                    doc.content[1].margin = [ 10, 0, 10, 0 ] //left, top, right, bottom
                }
              },
              {
                extend: 'excelHtml5',
                className: 'btnDt btn-app export excel',
                text: '<i class="fa fa-file-excel-o" aria-hidden="true" data-bs-toggle="tooltip" data-bs-placement="top" title="Exportar a Excel"></i>',
                autoFilter: true,
                sheetName: 'Exported data'
              }
          ]
});

/* Mostrar u ocultar input para comentario */
$(".taComentarioAcc").hide();
$("#movimientoAccesorio").change(function(){
    let tipo = $("#movimientoAccesorio").val();

    if(tipo == "Salida por ajuste"){
        $(".taComentarioAcc").show();
    } else{
        $(".taComentarioAcc").hide();
    }
});


/* PARA REGISTRAR NUEVO MOVIMIENTO DE ACCESORIOS */
$("#formularioMovAccesorios").on("submit", function(e){

    e.preventDefault();
    var datos = $("#formularioMovAccesorios").serialize();

    $.ajax({
        url: localhost + "ajax/administradores.ajax.php",
        method: "POST",
        data: datos,
        dataType: "json",
        success: function(respuesta){
            /* console.log(respuesta); */

            Swal.fire({
                position: "center",
                icon: respuesta.icono,
                title: respuesta.titulo,
                text: respuesta.mensaje,
                showConfirmButton: true
              });

              tabla.ajax.reload();
            
            },
            error: function(error){
                /* console.log(error); */
            }
        });

});
