/* la variable "localhost" está definida en el archivo base */

/* dselect(document.querySelectorAll('select'), {search: true}); */
 
 //$(document).ready(function(){ 
  
    let tablaAdmin = new DataTable('#datatableAdmin', {
        ajax: 'ajax/tablaAdmin.ajax.php',
        ordering: true, 
        order: [[0, 'asc']],
        columns: [
          {
            data: 'nombre',
            render: function (data) {
              return '<span class="text-secondary text-xs font-weight-bold">'+data+'</span>';
            }
          },
          {
            data: 'email',
            render: function (data) {
              return '<span class="text-secondary text-xs font-weight-bold">'+data+'</span>';
            }
          },
          {
            data: 'usuario',
            render: function (data) {
              return '<span class="text-secondary text-xs font-weight-bold">'+data+'</span>';
            }
          },
          {
            data: 'cargo',
            render: function (data) {
              return '<span class="text-secondary text-xs font-weight-bold">'+data+'</span>';
            }
          },
          {
            data: 'sede',
            render: function (data) {
              return '<span class="text-secondary text-xs font-weight-bold">'+data+'</span>';
            }
          },
          {
            data: 'perfil',
            render: function (data) {
              switch(data){
                case "1": var perfil = "Administrador"; break;
                case "2": var perfil = "Usuario"; break;
                case "3": var perfil = "Solo ver"; break;
                default: var perfil = "";
              }
              return '<span class="text-secondary text-xs font-weight-bold">'+perfil+'</span>';
            }
          },
          {
            data: 'estatus',
            render: function (data) {
              return '<span class="text-secondary text-xs font-weight-bold">'+data+'</span>';
            }
          },
          {
            data: 'id',
            render: function (data) {
              return '<ul class="navbar-nav justify-content-end">'+
                        '<li class="nav-item dropdown pe-2 d-flex align-items-center">'+
                          '<div class="nav-link text-body p-0">'+
                          '<a idEditarAdmin_="' + data + '" class="p-1 btn-lg mb-0 text-secondary btnEditarAdmin" data-bs-toggle="modal" data-bs-target="#modalEditarAdmin" style="cursor:pointer;"><i class="fa fa-pencil fs-6 p-1" data-bs-toggle="tooltip" title="Modificar información de este administrador"></i></a>'+
                          '</div>'+
                        '</li>'+
                      '</ul>';
            }
          },
        ],
        language: {
            "decimal": "",
            "emptyTable": "No hay información",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
            "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
            "infoFiltered": "(Filtrado de _MAX_ total entradas)",
            "infoPostFix": "",
            "thousands": ",",
            "lengthMenu": "Mostrar _MENU_ Entradas",
            "loadingRecords": "Cargando...",
            "processing": "Procesando...",
            "search": "Buscar:",
            "zeroRecords": "Sin resultados encontrados",
            "paginate": {
                "first": "Primero",
                "last": "Ultimo",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        },
    });

    //--------------------------------------------------------------------------------------------------------------
 
    $("#btnNuevoUsuario").on("click", function(){
      new MultiSelect(document.getElementById('sedesAdminNuevo'), {
        placeholder: 'Seleccione una o más opciones',
        search: true,
        selectAll: true
      });
    })

    //REGISTRAR NUEVO ADMIN
    $("#formularioNuevoAdmin").on( "submit", function( event ) {
      event.preventDefault();
      let datos = $("#formularioNuevoAdmin").serialize();

      /* console.log(datos); */

      $.ajax({
        url: localhost + 'ajax/administradores.ajax.php',
        method: "POST",
        dataType: "json",
        data: datos,
        success: function(respuesta){
          document.activeElement.blur();
          $("#modalNuevoAdmin").modal('hide');
          Swal.fire({
            position: "center",
            icon: respuesta.icono,
            title: respuesta.titulo,
            text: respuesta.mensaje,
            showConfirmButton: true
          });

          tablaAdmin.ajax.reload();
        }
      })
    })

  //})

  //--------------------------------------------------------------------------------------------------------
  //MOSTRAR INFORMACIÓN ANTES DE MODIFICAR 
  $("#datatableAdmin").on("click", ".btnEditarAdmin", function(){
    var idEditarAdmin_ = $(this).attr("idEditarAdmin_");

    var dato = new FormData();
    dato.append("idEditarAdmin_", idEditarAdmin_);

    $.ajax({
      url: localhost + 'ajax/administradores.ajax.php',
      method: "POST",
      dataType: "json",
      cache: false,
      contentType: false,
      processData: false,
      data: dato,
      success: function(respuesta){

        let admin = respuesta[0];
        let sedes = respuesta[1];
        let adminSedes = JSON.parse(respuesta[0].sedesadmin);

        /* console.log(sedes[0].idsede.toString()); */
        /* console.log(adminSedes); */

        $("#idEditarAdmin").val(admin.id);
        $("#editarNombreAdmin").val(admin.nombre);
        $("#editarEmailAdmin").val(admin.email);
        $("#editarUsuarioAdmin").val(admin.usuario);
        /* $("#editarPerfilAdmin").val(admin.perfil); */
        setValorSelect('editarPerfilAdmin', admin.perfil);
        $("#editarCargoAdmin").val(admin.cargo);
        /* $("#editarTipoContrato").val(admin.estatus); */
        /* $("#editarSedeAdmin").val(admin.sedeasignada); */
        setValorSelect('editarTipoContrato', admin.estatus);
        setValorSelect('editarSedeAdmin', admin.sedeasignada);

        $("#sedesAdmin").val("");
        
        /* if(adminSedes != ""){
          $.each(sedes, function(index, sede) {
            let selected = adminSedes.includes(sede.idsede.toString()) ? 'selected' : '';
            $('#sedesAdmin').append(`<option value="${sede.idsede}" ${selected}>${sede.nombresede} ${sede.departamentosede}</option>`);
          });
        } else{
          $.each(sedes, function(index, sede) {
            $('#sedesAdmin').append(`<option value="${sede.idsede}">${sede.nombresede} ${sede.departamentosede}</option>`);
          });
        } */

          $.each(sedes, function(index, sede) {
            if(adminSedes == "" || adminSedes == null){
              $('#sedesAdmin').append(`<option value="${sede.idsede}">${sede.nombresede} ${sede.departamentosede}</option>`);
            } else{
              let selected = adminSedes.includes(sede.idsede.toString()) ? 'selected' : '';
              $('#sedesAdmin').append(`<option value="${sede.idsede}" ${selected}>${sede.nombresede} ${sede.departamentosede}</option>`);
            }
          });
        
        new MultiSelect(document.getElementById('sedesAdmin'), {
          placeholder: 'Seleccione una o más opciones',
          search: true,
          selectAll: true
        });

        /* new MultiSelect(document.getElementById('sedesAdmin'), {
          placeholder: 'Seleccione una o más opciones',
          search: true,
          selectAll: true
        }); */

      }
    });

  });


  //------------------------------------------------------------------------------------------------
  //Modifica la información
  $("#formularioEditarAdmin").on("submit", function(e){
    e.preventDefault();

    var datos = $("#formularioEditarAdmin").serialize();
    /* console.log(datos); */

    $.ajax({
      url: localhost + 'ajax/administradores.ajax.php',
      method: "POST",
      dataType: "json",
      data: datos,
      success: function(respuesta){
        document.activeElement.blur();
        $("#modalEditarAdmin").modal('hide');
        Swal.fire({
          position: "center",
          icon: respuesta.icono,
          title: respuesta.titulo,
          text: respuesta.mensaje,
          showConfirmButton: true
        });

        tablaAdmin.ajax.reload();
      }
    })

  })

  //--------------------------------------------------------------------------------------------------------

  //Resetear formularios de modal, en cuanto el modal se oculte
  $(document).on("hidden.bs.modal", ".modal", function () {
    const form = $(this).find('form')[0];

    if (form) {
      form.reset();
    }
  
    const formId = $(this).find('form').attr('id');
    if (formId) {
      limpiarSelectsFormulario(formId);
    }
  });

 /*  $("#modalNuevoAdmin").on("hidden.bs.modal", function () {
    $(this).find('form')[0].reset();
    limpiarSelectsFormulario('formularioEditarAdmin');
  });

  $("#modalEditarAdmin").on("hidden.bs.modal", function () {
    $(this).find('form')[0].reset();
  });
  
  $("#modalNuevaSede").on("hidden.bs.modal", function () {
    $(this).find('form')[0].reset();
  });
  
  $("#modalEditarSede").on("hidden.bs.modal", function () {
    $(this).find('form')[0].reset();
  }); */




// VALIDACIÓN DE CAMPOS PARA REGISTRAR NUEVO ADMIN
(function () {
  'use strict'

    //Resetear formularios de modal, en cuanto el modal se oculte
    /* $("#modalNuevoAdmin").on("hidden.bs.modal", function () {
      $(this).find('form')[0].reset();
    }); */

  var forms = document.querySelectorAll('.needs-validation')

  Array.prototype.slice.call(forms).forEach(function (form) {
    function handleButtonClick(event) {
      if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }

      form.addEventListener('submit', handleButtonClick);

      function handleModalClose(){
        form.classList.remove('was-validated');
      }

      document.getElementById('modalNuevoAdmin').addEventListener('hidden.bs.modal', handleModalClose);
    })
})();

//-------------------------------------------------------------------------------------------------------------

/* RELLENAR SELECT DE REGIÓN,SEGÚN LA SEDE */
$("#formularioNuevaSede #departamento").on("change", function(){
  let region = $("#departamento").val();
  $("#opciones").empty();
  $.ajax({
    url: localhost + 'ajax/tablaSedes.ajax.php',
    method: "POST",
    dataType: "json",
    success: function(respuesta){
      let regionesUnicas = new Set();

      $.each(respuesta.data, function(index, opcion) {
       /*  if(respuesta.data[index].departamentosede == region){
          $('#opciones').append('<option value="' + opcion.regionsede + '">' + opcion.regionsede + '</option>');
        } */

          if(opcion.departamentosede == region && !regionesUnicas.has(opcion.regionsede)){
            $('#opciones').append('<option value="' + opcion.regionsede + '">' + opcion.regionsede + '</option>');
            regionesUnicas.add(opcion.regionsede);
          }
      });
    },
    error: function(error){
      /* console.log("Error: "+error) */
    }
  })
})

 /* REGISTRAR NUEVA SEDE */
$("#formularioNuevaSede").on( "submit", function( event ) {
  event.preventDefault();
  let datos = $("#formularioNuevaSede").serialize();
  /* console.log(datos); */

  $.ajax({
    url: localhost + 'ajax/administradores.ajax.php',
    method: "POST",
    dataType: "json",
    data: datos,
    success: function(respuesta){
      $("#modalNuevaSede").modal('hide');
      Swal.fire({
        position: "center",
        icon: respuesta.icono,
        title: respuesta.titulo,
        text: respuesta.mensaje,
        showConfirmButton: true
      }).then(() => {
        tablaSedes.ajax.reload();
      });
    },
    error: function(error){
      /* console.log("Error: "+error) */
    }
  })
});

 /* MOSTRAR INFORMACIÓN ANTES DE MODIFICAR SEDE */
$(".tablaSede").on("click", ".btnEditarSede", function(){
  var idEditarSede_ = $(this).attr("idEditarSede_");

  var datos = new FormData();
  datos.append("idEditarSede_", idEditarSede_);

  $.ajax({
    url: localhost + 'ajax/administradores.ajax.php',
    method: "POST",
    dataType: "json",
    data: datos,
    cache: false,
    contentType: false,
    processData: false,
    success: function(respuesta){

      /* console.log(respuesta); */
      $("#idEditarSede").val(respuesta.idsede);
      $("#editarNombreSede").val(respuesta.nombresede);
      $("#editarDepartamento").val(respuesta.departamentosede);
      $("#editarRegion").val(respuesta.regionsede);

      const selectConfig = {
        search: false
      }
      dselect(document.querySelector('#editarDepartamento'), selectConfig);
      
    },
    error: function(error){
     /* console.log(error); */
    }
  })

});

/* RELLENAR SELECT DE REGIÓN,SEGÚN LA SEDE AL MODIFICAR INFORMACIÓN DE SEDE */
$("#formularioEditarSede #editarDepartamento").on("change", function (){
  $("#editarOpciones").empty();
  $("#editarRegion").val("");
})

$("#formularioEditarSede #editarRegion").keyup(function () {
  $("#editarOpciones").empty();
  let region = $("#editarDepartamento").val();

    $.ajax({
      url: localhost + 'ajax/tablaSedes.ajax.php',
      method: "POST",
      dataType: "json",
      success: function(respuesta){
        let regionesUnicas = new Set();

        $.each(respuesta.data, function(index, opcion) {
          if(opcion.departamentosede == region && !regionesUnicas.has(opcion.regionsede)){
              $('#editarOpciones').append('<option value="' + opcion.regionsede + '">' + opcion.regionsede + '</option>');
              regionesUnicas.add(opcion.regionsede);
            }
          });
      },
      error: function(error){
        /* console.log("Error: "+error) */
      }
    })
})

/* MODIFICAR INFORMACIÓN DE SEDE */
$("#formularioEditarSede").on( "submit", function( event ) {
  event.preventDefault();
  let datos = $("#formularioEditarSede").serialize();

  /* console.log(datos); */

  $.ajax({
    url: localhost + 'ajax/administradores.ajax.php',
    method: "POST",
    dataType: "json",
    data: datos,
    success: function(respuesta){
      document.activeElement.blur();
      $("#modalEditarSede").modal('hide');
      Swal.fire({
        position: "center",
        icon: respuesta.icono,
        title: respuesta.titulo,
        text: respuesta.mensaje,
        showConfirmButton: true
      }).then(() => {
        tablaSedes.ajax.reload();
      });
    },
    error: function(error){
      /* console.log(error); */
    }
  })
});


//REALIZAR NUEVO REGISTRO DE TIPOS DE DISPOSITIVO
$("#formularioNuevoTipo").on( "submit", function( event ) {
  event.preventDefault();
  let datos = $("#formularioNuevoTipo").serialize();

  $.ajax({
    url: localhost + 'ajax/administradores.ajax.php',
    method: "POST",
    dataType: "json",
    data: datos,
    success: function(respuesta){
      document.activeElement.blur();
      $("#modalNuevoTipo").modal('hide');
      Swal.fire({
        position: "center",
        icon: respuesta.icono,
        title: respuesta.titulo,
        text: respuesta.mensaje,
        showConfirmButton: true
      }).then(() => {
        tablaTipos.ajax.reload();
      });
    },
    error: function(error){
      /* console.log("Error: "+error) */
    }
  })
})

//REALIZAR NUEVO REGISTRO DE MARCAS DE DISPOSITIVO
$("#formularioNuevaMarca").on( "submit", function( event ) {
  event.preventDefault();
  let datos = $("#formularioNuevaMarca").serialize();

  $.ajax({
    url: localhost + 'ajax/administradores.ajax.php',
    method: "POST",
    dataType: "json",
    data: datos,
    success: function(respuesta){
      document.activeElement.blur();
      $("#modalNuevaMarca").modal('hide');
      Swal.fire({
        position: "center",
        icon: respuesta.icono,
        title: respuesta.titulo,
        text: respuesta.mensaje,
        showConfirmButton: true
      }).then(() => {
        tablaMarcas.ajax.reload();
      });
    },
    error: function(error){
      /* console.log("Error: "+error) */
    }
  });
});

//REALIZAR NUEVO REGISTRO DE MODELOS DE DISPOSITIVO
$("#formularioNuevoModelo").on( "submit", function( event ) {
  event.preventDefault();
  let datos = $("#formularioNuevoModelo").serialize();

  $.ajax({
    url: localhost + 'ajax/administradores.ajax.php',
    method: "POST",
    dataType: "json",
    data: datos,
    success: function(respuesta){
      document.activeElement.blur();
      $("#modalNuevoModelo").modal('hide');
      Swal.fire({
        position: "center",
        icon: respuesta.icono,
        title: respuesta.titulo,
        text: respuesta.mensaje,
        showConfirmButton: true
      }).then(() => {
        tablaModelos.ajax.reload();
      });
    },
    error: function(error){
      /* console.log("Error: "+error) */
    }
  });
});

//--------------------------------------------------------------------------------------------------
//Eliminar sede 
$(".tablaSede").on("click", ".btnEliminarSede", function(){
  Swal.fire({
      title: "Eliminar sede",
      text: "¿Está seguro que desea eliminar esta sede?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    }).then((result) => {
      if (result.isConfirmed) {
          var idEliminarSede = $(this).attr("idEliminarSede");

          var datos = new FormData();
          datos.append("idEliminarSede", idEliminarSede);

          $.ajax({
              url: localhost + "ajax/administradores.ajax.php",
              method: "POST",
              data: datos,
              cache: false,
              contentType: false,
              processData: false,
              dataType: "json",
              success: function(respuesta){
                  Swal.fire({
                      title: respuesta.titulo,
                      text: respuesta.mensaje,
                      icon: respuesta.icono,
                      showConfirmButton: true
                    }).then(() => {
                      tablaSedes.ajax.reload();
                    });
              }
          })
      }
    });

});

//Eliminar tipo de dispositivo 
$(".tablaTipo").on("click", ".btnEliminarTipo", function(){
  Swal.fire({
      title: "Eliminar tipo de dispositivo",
      text: "¿Está seguro que desea eliminar este tipo de dispositivo?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    }).then((result) => {
      if (result.isConfirmed) {
          var idEliminarTipo = $(this).attr("idEliminarTipo");

          var datos = new FormData();
          datos.append("idEliminarTipo", idEliminarTipo);

          $.ajax({
              url: localhost + "ajax/administradores.ajax.php",
              method: "POST",
              data: datos,
              cache: false,
              contentType: false,
              processData: false,
              dataType: "json",
              success: function(respuesta){
                  Swal.fire({
                      title: respuesta.titulo,
                      text: respuesta.mensaje,
                      icon: respuesta.icono,
                      showConfirmButton: true
                    }).then(() => {
                      tablaTipos.ajax.reload();
                    });
              }
          })
      }
    });

});

//Eliminar marca de dispositivo 
$(".tablaMarca").on("click", ".btnEliminarMarca", function(){
  Swal.fire({
      title: "Eliminar marca de dispositivo",
      text: "¿Está seguro que desea eliminar esta marca de dispositivo?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    }).then((result) => {
      if (result.isConfirmed) {
          var idEliminarMarca = $(this).attr("idEliminarMarca");

          var datos = new FormData();
          datos.append("idEliminarMarca", idEliminarMarca);

          $.ajax({
              url: localhost + "ajax/administradores.ajax.php",
              method: "POST",
              data: datos,
              cache: false,
              contentType: false,
              processData: false,
              dataType: "json",
              success: function(respuesta){
                  Swal.fire({
                      title: respuesta.titulo,
                      text: respuesta.mensaje,
                      icon: respuesta.icono,
                      showConfirmButton: true
                    }).then(() => {
                      tablaMarcas.ajax.reload();
                    });
              }
          })
      }
    });

});

$(".tablaModelo").on("click", ".btnEliminarmodelo", function(){
  Swal.fire({
    title: "Eliminar modelo de dispositivo",
    text: "¿Está seguro que desea eliminar esta modelo de dispositivo?",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar",
  }).then((result) => {
    if (result.isConfirmed) {
        var idEliminarModelo = $(this).attr("idEliminarModelo");

        var datos = new FormData();
        datos.append("idEliminarModelo", idEliminarModelo);

        $.ajax({
            url: localhost + "ajax/administradores.ajax.php",
            method: "POST",
            data: datos,
            cache: false,
            contentType: false,
            processData: false,
            dataType: "json",
            success: function(respuesta){
                Swal.fire({
                    title: respuesta.titulo,
                    text: respuesta.mensaje,
                    icon: respuesta.icono,
                    showConfirmButton: true
                  }).then(() => {
                    tablaModelos.ajax.reload();
                  });
            }
        });
    }
  });
})