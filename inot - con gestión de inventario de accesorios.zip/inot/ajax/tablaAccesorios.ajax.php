<?php

session_start();

require_once "../controladores/accesorios.controlador.php";
require_once "../modelos/accesorios.modelo.php";

class TablaAccesorios{

    public function mostrarRegistrosAccesorios(){
        $item = null;
        $valor = null;

        $accesorios_registros = ControladorAccesorios::ctrMostrarRegistrosAccesorios($item, $valor);

        echo json_encode(array("data"=>$accesorios_registros));
    }

}

$accesorios = new TablaAccesorios();
$accesorios->mostrarRegistrosAccesorios();