<?php

require_once "../modelos/conexion.php";

class CargarDataDispositivos{

    public function cargarData(){

        if(isset($_FILES["fileCD"]) && $_FILES["fileCD"]["error"] == 0){ 
            $csvFile = $_FILES["fileCD"]["tmp_name"];
            $csvName = $_FILES["fileCD"]["name"];
            $extension = pathinfo($csvName, PATHINFO_EXTENSION);

            if ($extension !== 'csv') {
                echo "El archivo debe ser de tipo .csv";
                exit;
            }

            $totalLineas = count(file($csvFile))-1;
            $insertados = 0;
            $noInsertados = [];

            $sql = "INSERT IGNORE INTO dispositivos (tipodispositivo, marcadispositivo, modelodispositivo, imeidispositivo, seriedispositivo, telefonodispositivo, inventariodispositivo, hostnamedispositivo, cajadispositivo, correlativodispositivo, sededispositivo, estadodispositivo, fecharegistro) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
 
            $stmt = Conexion::conectar()->prepare($sql);

            if(($handle = fopen($csvFile, "r")) !== false){

                $header = fgetcsv($handle, 1000, ";");

                /* if (count($header) !== 10) {
                    echo json_encode(array(
                        "icono" => "info",
                        "titulo" => "Atención",
                        "cantidad" => "",
                        "total" => "",
                        "noinsertados" => "",
                        "mensaje" => "El archivo CSV debe tener exactamente 10 columnas."
                    ));
                    fclose($handle);
                    exit;
                } */

                $lineNumber = 2; 
                while(($data = fgetcsv($handle, 1000, ";")) !== false){

                    /* if (empty($data[4])) {
                        $lineNumber++;
                        continue;
                    } */

                    if(empty($data[0]) || empty($data[1]) || empty($data[2]) || empty($data[4])){
                        $lineNumber++;
                        continue;
                    }

                    $imeidispositivo = empty($data[3]) ? null : $data[3];
                    /* $seriedispositivo = empty($data[4]) ? null : $data[4]; */
                    $inventariodispositivo = empty($data[6]) ? null : $data[6];
                    $hostnamedispositivo = empty($data[7]) ? null : $data[7];

                    //Comprobar si ya existe la serie que se está intentando registrar y omitir si es así
                    $stmt_check = Conexion::conectar()->prepare("SELECT COUNT(*) FROM dispositivos WHERE imeidispositivo = ? OR seriedispositivo = ? OR inventariodispositivo = ? OR hostnamedispositivo = ?");
                    $stmt_check->execute([$imeidispositivo, $data[4], $inventariodispositivo, $hostnamedispositivo]);
                    $existe = $stmt_check->fetchColumn() > 0;

                    if ($existe) {
                        $noInsertados[] = 'Serie: '.$data[4].', Linea: '.$lineNumber.' del .CSV';
                        $lineNumber++;
                        continue;
                    }

                    $stmt->bindValue(1, $data[0], PDO::PARAM_STR);
                    $stmt->bindValue(2, $data[1], PDO::PARAM_STR);
                    $stmt->bindValue(3, $data[2], PDO::PARAM_STR);
                    $stmt->bindValue(4, $imeidispositivo, PDO::PARAM_STR);
                    $stmt->bindValue(5, $data[4], PDO::PARAM_STR);
                    $stmt->bindValue(6, $data[5], PDO::PARAM_STR);
                    $stmt->bindValue(7, $inventariodispositivo, PDO::PARAM_STR);
                    $stmt->bindValue(8, $hostnamedispositivo, PDO::PARAM_STR);
                    $stmt->bindValue(9, $data[8], PDO::PARAM_STR);
                    $stmt->bindValue(10, $data[9], PDO::PARAM_STR);
                    $stmt->bindValue(11, $data[10], PDO::PARAM_STR);
                    $stmt->bindValue(12, $data[11], PDO::PARAM_STR);
                    $stmt->bindValue(13, $fecha_actual = date('Y-m-d'), PDO::PARAM_STR);
    
                    if($stmt->execute()){
                        if($stmt->rowCount() > 0){
                            $insertados ++;
                        }
                    } else{
                        /* echo json_encode(array("mensaje" => "Error de archivo", "error" => $stmt->errorInfo())); */
                        $noInsertados[] = 'Serie: '.$data[4].', Linea: '.$lineNumber.' del .CSV';
                    }

                    $lineNumber++;

                }


                fclose($handle);

                if($insertados < 1){
                    echo json_encode(array(
                        "cantidad" => $insertados,
                        "total" => $totalLineas,
                        "icono" => "info",
                        "titulo" => "Atención",
                        "noinsertados" => implode("<br>",$noInsertados),
                        "mensaje" => "No fue posible registrar ningún dispositivo, por favor revise el formato del archivo o bien los dispositivos que desea registrar, ya se encuentran en la base de datos."
                    ));
                } else{
                    echo json_encode(array(
                        "cantidad" => $insertados,
                        "total" => $totalLineas,
                        "icono" => "success",
                        "titulo" => "Éxito",
                        "noinsertados" => implode("<br>",$noInsertados),
                        "mensaje" => "Registros agregados o modificados con éxito."));
                }
            } else{
                echo json_encode(array(
                    "icono" => "info",
                    "titulo" => "Atención",
                    "mensaje" => "El archivo no tiene el formato esperado. Por favor verificar y volver a subir."));
            }
        } else{
            echo "No se ha subido ningún archivo o existe un error en el archivo.";
        }        

    }

}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $cargar = new CargarDataDispositivos();
    $cargar->cargarData();
}