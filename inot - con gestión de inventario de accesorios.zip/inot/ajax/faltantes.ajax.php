<?php

require_once "../controladores/faltantes.controlador.php";
require_once "../modelos/faltantes.modelo.php";

class AjaxFaltantes{

    public $idRegistro;
    public function ajaxAccesoriosMostrarFaltantes(){
        $item = "id";
        $valor = $this->idRegistro;
        $respuesta = ControladorFaltantes::ctrMostrarAccesoriosFaltantes($item, $valor);

        echo json_encode($respuesta);
    }

    public function ajaxRecuperarAccesorios(){
        $item = "id";
        $valor = $_POST["idAccRecuperar"];
        
        $accesorios = array(
            "Cubo" => isset($_POST["checkCubo"]) && $_POST["checkCubo"] == "on" ? "1" : "0",
            "Cable" => isset($_POST["checkCable"]) && $_POST["checkCable"] == "on" ? "1" : "0",
            "Funda" => isset($_POST["checkFunda"]) && $_POST["checkFunda"] == "on" ? "1" : "0",
            "Lapiz" => isset($_POST["checkLapiz"]) && $_POST["checkLapiz"] == "on" ? "1" : "0",
            "Powerbank" => isset($_POST["checkPowerbank"]) && $_POST["checkPowerbank"] == "on" ? "1" : "0",
            "Maletin" => isset($_POST["checkMaletin"]) && $_POST["checkMaletin"] == "on" ? "1" : "0",
            "Cargador" => isset($_POST["checkCargador"]) && $_POST["checkCargador"] == "on" ? "1" : "0",
            "Mouse" => isset($_POST["checkMouse"]) && $_POST["checkMouse"] == "on" ? "1" : "0",
            "Mousepad" => isset($_POST["checkMousepad"]) && $_POST["checkMousepad"] == "on" ? "1" : "0"
        );

        $respuesta = ControladorFaltantes::ctrRecuperarFaltantes($item, $valor, $accesorios);
        
        echo json_encode($respuesta);
    }

}

if(isset($_POST["idregistro"])){
    $mostrar = new AjaxFaltantes();
    $mostrar->idRegistro = $_POST["idregistro"];
    $mostrar->ajaxAccesoriosMostrarFaltantes();
}

if(isset($_POST["recuperar"])){
    $recuperar = new AjaxFaltantes();
    $recuperar->ajaxRecuperarAccesorios();
}