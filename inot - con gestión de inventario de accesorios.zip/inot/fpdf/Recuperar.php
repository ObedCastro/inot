<?php

session_start();

include('fechaes.php');

require "../modelos/conexion.php";
require_once "../controladores/dispositivos.controlador.php";
require_once "../controladores/consultores.controlador.php";
require_once "../controladores/sedes.controlador.php";
require_once "../modelos/dispositivos.modelo.php";
require_once "../modelos/consultores.modelo.php";
require_once "../modelos/sedes.modelo.php";

require('fpdf.php');

class PDF extends FPDF{

   //Pie de página
   function Footer()
   {
    //Posición: a 1,5 cm del final
    $this->SetY(-15);
    //Arial italic 8
    $this->SetFont('Arial','I',8);
    //Número de página
    $this->Cell(0,10,'Documento Confidencial - Pagina'.$this->PageNo().'/{nb}',0,0,'C');
   }

}


if(isset($_GET["idDispositivoRecuperar"]) && isset($_GET["responsableActual"])){
    
    $item = "iddispositivo";
    $valor = $_GET["idDispositivoRecuperar"];
    $resActual = $_GET["responsableActual"];
    $comentario = $_GET["comentarioRecuperar"];
    $fecha = $_GET["fechaRecepcion"];

    date_default_timezone_set('America/El_Salvador');
    $fecha_datetime = DateTime::createFromFormat("Y-m-d", $fecha);

    if($_GET["condicionDispositivo"] == "option1"){
        $estado = "1";
    } else if($_GET["condicionDispositivo"] == "option2"){
        $estado = "3";
    } else if($_GET["condicionDispositivo"] == "option3"){
        $estado = "4";
    }

    $datos = array(
        "Cubo"=>isset($_GET["checkCubo"]) == "on" ? "1" : "0",
        "Cable"=>isset($_GET["checkCable"]) == "on" ? "1" : "0",
        "Funda"=>isset($_GET["checkFunda"]) == "on" ? "1" : "0",
        "Lapiz"=>isset($_GET["checkLapiz"]) == "on" ? "1" : "0",
        "Powerbank"=>isset($_GET["checkPowerbank"]) == "on" ? "1" : "0",
        "Maletin"=>isset($_GET["checkMaletin"]) == "on" ? "1" : "0",
        "Cargador"=>isset($_GET["checkCargador"]) == "on" ? "1" : "0",
        "Mouse"=>isset($_GET["checkMouse"]) == "on" ? "1" : "0",
        "Mousepad"=>isset($_GET["checkMousepad"]) == "on" ? "1" : "0" 
    );
 
    $responsable = ControladorConsultores::ctrMostrarConsultores("idconsultor", $resActual);
    $sede = ControladorSedes::ctrMostrarSedes("idsede", $responsable["sedeconsultor"]);
    
    $accesorios = json_encode($datos);
    $resultado = ControladorDispositivos::ctrMostrarDispositivoRecuperar($item, $valor, $resActual);
    $respuesta = $resultado[0];
    //$respuesta = ControladorDispositivos::ctrAsignarDispositivo($id, $resActual, $accesorios, $comentario);

    ControladorDispositivos::ctrCambiarEstadoDispositivo("iddispositivo", $valor, $accesorios, $estado, $comentario, $fecha_datetime->format('Y-m-d h:i:s'));

    $arreglo = (array) $respuesta;



    /* GUARDAR REGISTRO DE ACCESORIO RECUPERADO */
    $fecha_registro = $fecha_datetime->format('Y-m-d h:i:s');
    $sede_acc = $sede["idsede"];
    
    foreach ($datos as $key => $value) {
        if (isset($_GET["check".$key]) && $_GET["check".$key] == "on") {
            switch ($key) {
                case 'Cubo': $acc_id = '1'; break;
                case 'Cable': $acc_id = '2'; break;
                case 'Funda': $acc_id = '3'; break;
                case 'Lapiz': $acc_id = '4'; break;
                case 'Powerbank': $acc_id = '5'; break;
                case 'Maletin': $acc_id = '6'; break;
                case 'Cargador': $acc_id = '7'; break;
                case 'Mouse': $acc_id = '8'; break;
                case 'Mousepad': $acc_id = '9'; break;
                default: $acc_id = null; break;
            }
    
            if ($acc_id !== null) {
                try {
                    $reg_acc = "INSERT INTO registros_accesorios (accesorio_id, cantidadaccesorio, sede_id, tipo_movimiento, comentarioaccesorio, fecha) VALUES (:acc_id, 1, :sede_acc, 'Recepción', NULL, :fecha_registro)";
                    $ira = Conexion::conectar()->prepare($reg_acc);
                    $ira->bindParam(':acc_id', $acc_id, PDO::PARAM_INT);
                    $ira->bindParam(':sede_acc', $sede_acc, PDO::PARAM_INT);
                    $ira->bindParam(':fecha_registro', $fecha_registro, PDO::PARAM_STR);
                    $ira->execute();
                } catch (PDOException $e) {
                    error_log("Error al insertar accesorio: " . $e->getMessage());
                }
            }
        }
    }



    $tituloHoja = "RECEPCIÓN DE EQUIPO INFORMÁTICO";
    $inv_o_tel = "";
    $dato_inv_o_tel = "";
    if($arreglo["tipodispositivo"] == "Teléfono" || $arreglo["tipodispositivo"] == "Tablet"){
        $tituloHoja = "RECEPCIÓN DE DISPOSITIVO MÓVIL";
        $inv_o_tel = "TELÉFONO";
        $dato_inv_o_tel = $arreglo["telefonodispositivo"];
    } else if($arreglo["tipodispositivo"] == "Laptop"){
        $tituloHoja = "RECEPCIÓN DE LAPTOP";
        $inv_o_tel = "INVENTARIO";
        $dato_inv_o_tel = $arreglo["inventariodispositivo"];
    } else{
        $tituloHoja = "RECEPCIÓN DE EQUIPO INFORMÁTICO";
        $inv_o_tel = "INVENTARIO";
        $dato_inv_o_tel = $arreglo["inventariodispositivo"];
    }

    try {

        $pdf=new PDF('P','mm',array(216,279));
        $pdf->SetMargins(28, 25, 28);
        $pdf->AliasNbPages();

        //Primera página
        $pdf->AddPage();
        $pdf->AddFont('MuseoSans300','','MuseoSans-300.php');
        $pdf->SetFont('MuseoSans300','',13);
        $pdf->Image('img/MARCA DE WATER.png',0, 0, 216);
        $pdf->Image('img/logo_BCR.png',85,15,38);
        $pdf->Ln(15);
        $pdf->SetFont('MuseoSans300','',13);
        $pdf->Cell(0,10,mb_convert_encoding($tituloHoja, 'ISO-8859-1', 'UTF-8'),0,0,'C');
        $pdf->Ln(15);
        $pdf->SetFont('MuseoSans300','',10);
        $pdf->MultiCell(0, 5, mb_convert_encoding('En este acto se hace recepcion de: '.strtoupper($responsable["nombreconsultor"]).', con el cargo de: '.strtoupper($responsable["cargoconsultor"]).' destacado en la sede: '.strtoupper($sede["nombresede"]." ".$sede["departamentosede"]).' el dispositivo que a continuación se describe:','ISO-8859-1', 'UTF-8'), 0, 1);
        $pdf->Ln(8);

        //TABLA CABEX
        $pdf->SetFont('Arial','B',11);

        //Cabecera
        $pdf->setTextColor(255, 255, 255);
        $pdf->SetFillColor(29,80,153);
        $pdf->SetLineWidth(.3);
        $pdf->SetFont('MuseoSans300','',11);
        $pdf->Cell(30,6,mb_convert_encoding('DESCRIPCIÓN', 'ISO-8859-1', 'UTF-8'),1,0,'C',1);
        $pdf->Cell(30,6,'MARCA',1,0,'C',1);
        $pdf->Cell(36,6,'MODELO',1,0,'C',1);

        if($arreglo['tipodispositivo'] != 'Laptop'){
            $pdf->Cell(36,6,'IMEI',1,0,'C',1);
        }else{
            $pdf->Cell(36,6,'SERIE',1,0,'C',1);
        }

        $pdf->Cell(25,6,mb_convert_encoding($inv_o_tel, 'ISO-8859-1', 'UTF-8'),1,0,'C',1);
        $pdf->Ln();

        //Datos
        $pdf->SetFillColor(224,235,255);
        $pdf->SetTextColor(0);
        $pdf->SetFont('');

            $pdf->Cell(30,6,mb_convert_encoding($arreglo['tipodispositivo'], 'ISO-8859-1', 'UTF-8'),'LR',0,'C');
            $pdf->Cell(30,6,$arreglo['marcadispositivo'],'LR',0,'C');
            $pdf->Cell(36,6,$arreglo['modelodispositivo'],'LR',0,'C');

            if($arreglo['tipodispositivo'] != 'Laptop'){
                $imei_serie = $arreglo['imeidispositivo'];
                $pdf->Cell(36,6,$arreglo['imeidispositivo'],'LR',0,'C');
            } else{
                $imei_serie = $arreglo['seriedispositivo'];
                $pdf->Cell(36,6,$arreglo['seriedispositivo'],'LR',0,'C');
            }

            $pdf->Cell(25,6,$dato_inv_o_tel,'LR',0,'C');
        

        $pdf->Ln();
        $pdf->Cell(157,0,'','T');
        $pdf->Ln(10);
        $pdf->SetFont('MuseoSans300','',11);
        $pdf->Cell(0,5,'Con los siguientes accesorios:',0,0,'C');
        $pdf->Ln(10);


        if($arreglo["tipodispositivo"] == "Teléfono"){

            $bandera1 = "";
            $bandera2 = "";
            $bandera3 = "";
            $bandera5 = "";

            if($datos["Cubo"] == "1"){ $bandera1 = "X"; }
            if($datos["Cable"] == "1"){ $bandera2 = "X"; }
            if($datos["Funda"] == "1"){ $bandera3 = "X";  }
            if($datos["Powerbank"] == "1"){ $bandera5 = "X"; }

            $pdf->Cell(0,5,mb_convert_encoding(' *  Cubo de carga               '.$bandera1, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, $pdf->GetY() - 5, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Cable USB tipo C          '.$bandera2, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, $pdf->GetY() - 5, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Funda del Dispositivo    '.$bandera3, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, $pdf->GetY() - 5, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Powerbank                     '.$bandera5, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, $pdf->GetY() - 5, 8, 4, 'D');


        } else if($arreglo["tipodispositivo"] == "Tablet"){
            $bandera1 = "";
            $bandera2 = "";
            $bandera3 = "";
            $bandera4 = "";
            $bandera5 = "";

            if($datos["Cubo"] == "1"){ $bandera1 = "X"; }
            if($datos["Cable"] == "1"){ $bandera2 = "X"; }
            if($datos["Funda"] == "1"){ $bandera3 = "X";  }
            if($datos["Lapiz"] == "1"){ $bandera4 = "X"; }
            if($datos["Powerbank"] == "1"){ $bandera5 = "X"; }

            $pdf->Cell(0,5,mb_convert_encoding(' *  Cubo de carga               '.$bandera1, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, $pdf->GetY() - 5, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Cable USB tipo C          '.$bandera2, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, $pdf->GetY() - 5, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Funda del Dispositivo    '.$bandera3, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, $pdf->GetY() - 5, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Lapiz                              '.$bandera4, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, $pdf->GetY() - 5, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Powerbank                     '.$bandera5, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, $pdf->GetY() - 5, 8, 4, 'D');

        }else if($arreglo["tipodispositivo"] == "Laptop"){
          $bandera6 = "";
          $bandera7 = "";
          $bandera8 = "";
          $bandera9 = "";

            if($datos["Maletin"] == "1"){ $bandera6 = "X"; }
            if($datos["Cargador"] == "1"){ $bandera7 = "X"; }
            if($datos["Mouse"] == "1"){ $bandera8 = "X"; }
            if($datos["Mousepad"] == "1"){ $bandera9 = "X"; }

            $pdf->Cell(0,5,mb_convert_encoding(' *  Maletin                           '.$bandera6, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, $pdf->GetY() - 5, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Cargador                        '.$bandera7, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, $pdf->GetY() - 5, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Mouse                            '.$bandera8, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, $pdf->GetY() - 5, 8, 4, 'D');
            $pdf->Cell(0,5,mb_convert_encoding(' *  Mousepad                      '.$bandera9, 'ISO-8859-1', 'UTF-8'),0,1);
            $pdf->Rect(73, $pdf->GetY() - 5, 8, 4, 'D');

        }else{

        }

        $pdf->Ln(8);
        $pdf->SetFont('MuseoSans300','',11);
        $pdf->Cell(0,5,'Comentarios:',0,0,'L');
        $pdf->Ln(10);
        $pdf->MultiCell(0,5,mb_convert_encoding($comentario, 'ISO-8859-1', 'UTF-8'),0,1);
        $pdf->Rect(28, 143, 158, 40, 'D');
        $pdf->Ln(40);
        $pdf->SetFont('MuseoSans300','',11);
        $pdf->Cell(0,20,'Entrega:',0,0,'L',0);
        $pdf->Cell(0,20,'Recibe:                                       ',0,0,'R',0);
        $pdf->Ln();
        $pdf->Cell(0,8,'F:________________________',0,0,'L',0);
        $pdf->Cell(0,8,'F:________________________',0,0,'R',0);
        $pdf->Ln();
        $pdf->SetFont('MuseoSans300','',11);
        $pdf->Cell(0,5,mb_convert_encoding('Nombre: '.$responsable["nombreconsultor"],'ISO-8859-1', 'UTF-8'),0,0,'L',0);
        $pdf->Cell(0,5,mb_convert_encoding('Nombre: '.$_SESSION["nombre"],'ISO-8859-1', 'UTF-8'),0,0,'R',0);
        $pdf->Ln();
        $pdf->SetFont('MuseoSans300','',10);
        $pdf->Cell(0,5,mb_convert_encoding('Cargo: '.$responsable["cargoconsultor"],'ISO-8859-1', 'UTF-8'),0,0,'L',0);
        $pdf->Cell(0,5,mb_convert_encoding('Cargo: '.$_SESSION["cargo"],'ISO-8859-1', 'UTF-8'),0,0,'R',0);
        $pdf->Ln();
        $pdf->SetFont('MuseoSans300','',10);
        $pdf->Cell(0,5,mb_convert_encoding($_SESSION["estatus"], 'ISO-8859-1', 'UTF-8'),0,0,'L',0);

        $estatus = "";
        if($responsable["estatusconsultor"] != ""){
            if($responsable["estatusconsultor"] == "1"){$estatus = "Consultor BID";}
            else if($responsable["estatusconsultor"] == "2"){$estatus = "Banco Central de Reserva";}
            else if($responsable["estatusconsultor"] == "3"){$estatus = "ONEC";}
            else if($responsable["estatusconsultor"] == "4"){$estatus = "Consultor";}
        }

        $pdf->Cell(0,5,mb_convert_encoding($estatus, 'ISO-8859-1', 'UTF-8'),0,0,'R',0);
        $pdf->Ln(10);
        $pdf->SetFont('MuseoSans300','',10);

        setlocale(LC_TIME, "spanish");

        $pdf->Cell(0,5,mb_convert_encoding($sede["departamentosede"].', '.fechaEs($fecha), 'ISO-8859-1', 'UTF-8'),0,1,'R');
        $pdf->SetFont('MuseoSans300','',10);
        $pdf->Cell(0,5,mb_convert_encoding('Lugar                             Fecha                   ','ISO-8859-1', 'UTF-8'),0,1,'R');
        $pdf->Ln(5);

        $pdf->SetFont('Arial','',10);

        // Generar el PDF y enviarlo al navegador
        $pdfContent = $pdf->Output('', 'S'); // Captura el contenido en una variable

        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename='.'R - '.$responsable["nombreconsultor"].' - '.$imei_serie);
        header('Content-Length: ' . strlen($pdfContent));

        echo $pdfContent;
        exit;
    } catch(Exception $e){
        header("HTTP/1.1 500 Internal Server Error");
        echo "Error al generar el PDF: " . $e->getMessage();
    }
}
?>